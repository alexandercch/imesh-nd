// RGBImageElement.h: interface for the CPixel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RGBImageElement_H__DD92123B_0A7C_4806_8B75_F1FF13FB8C0B__INCLUDED_)
#define AFX_RGBImageElement_H__DD92123B_0A7C_4806_8B75_F1FF13FB8C0B__INCLUDED_

struct CRGBImageElement
{
typedef unsigned char	GPixel;
typedef GPixel			Pixel[3];
	CRGBImageElement(GPixel r = 0, GPixel g = 0, GPixel b = 0)
										{	m_RGB[0] = r; m_RGB[1] = g; m_RGB[2] = b;	}
//	operator color()					{	return color(m_RGB[0], m_RGB[1], m_RGB[2]); }
	inline GPixel& operator[](int i)	{	return m_RGB[i];							}
	inline CRGBImageElement& operator=(CRGBImageElement &ref) 
	{	m_RGB[0] = ref[0]; m_RGB[1] = ref[1]; m_RGB[2] = ref[2];
		return *this;										
	}
private:
	Pixel m_RGB;
};


#endif // !defined(AFX_RGBImageElement_H__DD92123B_0A7C_4806_8B75_F1FF13FB8C0B__INCLUDED_)
