// NullProjection_d.h: interface for the CNullProjection_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NullProjection_d_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)
#define AFX_NullProjection_d_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_

#include "IsoValueList_d.h"

template <class Tni>
class CNullProjection_d  
{
public:
typedef typename Tni::Img				Img;
typedef typename Tni::Tn				Tn;
typedef typename Tn::Point				Point;
typedef typename CIsoValueList_d<Tni>	Ivl;
public:
	void Init(Img*, Ivl*){};
	inline Point Project(Point& p){return p;};
};

#endif // !defined(AFX_NullProjection_d_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)
