// CloudPoint.h: interface for the CPointCloudProjection_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PointCloud_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)
#define AFX_PointCloud_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_

#define DIM 2
struct CCloudPoint
{
public :
	  
  //double coordenadas[3];  
  double coordenadas[DIM];  
  CCloudPoint(){}
  //CCloudPoint(double x, double y, double z){ coordenadas[0] = x; coordenadas[1] = y; coordenadas[2] = z;}  
   CCloudPoint(double x, double y){ coordenadas[0] = x; coordenadas[1] = y;}  
 inline void set_x(double x){coordenadas[0] = x;}
  inline void set_y(double y){coordenadas[1] = y;}
  //inline void set_z(double z){coordenadas[2] = z;}
  
  inline double get_x(){return coordenadas[0];}
  inline double get_y(){return coordenadas[1];}
  //inline double get_z(){return coordenadas[2];}

  inline double& x(){return coordenadas[0];}
  inline double& y(){return coordenadas[1];}

  double& operator[](int i){return coordenadas[i];}
  
  CCloudPoint operator+(double x);
  friend CCloudPoint operator+(double x,CCloudPoint arg);
  friend CCloudPoint operator-(double x,CCloudPoint arg);
  friend CCloudPoint operator*(double x,CCloudPoint arg);
  CCloudPoint operator-( double x);
  CCloudPoint operator*(double x);
  CCloudPoint operator+( CCloudPoint b);
  double operator*( CCloudPoint b);
  CCloudPoint operator-(CCloudPoint b);
};

///////////////////////////////////////////////////////////////////////////////////////////

CCloudPoint CCloudPoint::operator+(double x)
  {
  CCloudPoint temp;
	for(register unsigned int i = 0; i < DIM; i++)
  		temp.coordenadas[i] = x+coordenadas[i];
  return temp;
 }

 CCloudPoint operator+(double x,CCloudPoint arg)
 {
  CCloudPoint temp;
	for(register unsigned int i = 0; i < DIM; i++)
  		temp.coordenadas[i] = x+arg.coordenadas[i];
  return temp;
 }

CCloudPoint CCloudPoint::operator-(double x)
  {
  CCloudPoint temp;
	for(register unsigned int i = 0; i < DIM; i++)
  		temp.coordenadas[i] = x-coordenadas[i];
  return temp;
 }

 CCloudPoint operator-(double x,CCloudPoint arg)
 {
  CCloudPoint temp;
	for(register unsigned int i = 0; i < DIM; i++)
  		temp.coordenadas[i] = x-arg.coordenadas[i];
  return temp;
 } 
 


 CCloudPoint CCloudPoint::operator*(double x)
  {
  CCloudPoint temp;
	  for(register unsigned char ii = 0; ii < DIM; ii++)
  		temp.coordenadas[ii] = x*coordenadas[ii];
  return temp;
 }
 
  double CCloudPoint::operator*(CCloudPoint x)
  {  
  double summ=0.0;
  for(register unsigned char ii = 0; ii < DIM; ii++)
		summ+=x.coordenadas[ii]*coordenadas[ii] ;	  
  return summ;
 }

 CCloudPoint operator*(double x,CCloudPoint arg)
 {
  CCloudPoint temp;
	  for(register unsigned char ii = 0; ii < DIM; ii++)
		  temp.coordenadas[ii] = x*arg.coordenadas[ii];
  return temp;
 } 

CCloudPoint add(CCloudPoint a, CCloudPoint b)
{
  CCloudPoint sum;
  for(int i = 0; i < 2; i++)
        sum.coordenadas[i] = a.coordenadas[i] + b.coordenadas[i];
  return sum;
}
 
CCloudPoint CCloudPoint::operator+(CCloudPoint b)
{
  return add( *this, b);
}

CCloudPoint sub(CCloudPoint a, CCloudPoint b)
{
  CCloudPoint sum;
  for(int i = 0; i < 2; i++)
        sum.coordenadas[i] = a.coordenadas[i] - b.coordenadas[i];
  return sum;
}
 
CCloudPoint CCloudPoint::operator-( CCloudPoint b)
{
  return sub( *this, b);
}


#endif // !defined(AFX_PointCloud_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)



  