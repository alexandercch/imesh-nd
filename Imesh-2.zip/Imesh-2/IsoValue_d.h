// IsoValue_d.h: interface for the CIsoValue_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IsoValue_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
#define AFX_IsoValue_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_

#include "PointDetector_d.h"
#include "IsoValueList_d.h"

//----------------------------------------------------------------------------------------

template <class Tni>
class CIsoValuePrePoint_d : public Tni::Tn::Point
{
public:
typedef typename Tni::Img::Coord Coord;

	CIsoValuePrePoint_d()	
	{	
		m_Coord_a  = m_Coord_b  = Coord();	
		m_Scalar_a = m_Scalar_b = m_Scalar_iv = 0.0;
		m_bInit = 0.0; 
		m_Count = m_XCount++;
	}
	
	void Init(float sa, float sb, Coord pa, Coord pb, float siv)
	{
		m_Coord_a  = pa; m_Coord_b  = pb;
		m_Scalar_a = sa; m_Scalar_b = sb; m_Scalar_iv = siv;
		m_bInit = 1.0;
	}

	float m_bInit;
	Coord m_Coord_a, m_Coord_b;
	float m_Scalar_a, m_Scalar_b, m_Scalar_iv;
	static int m_XCount;
	int m_Count;
};

template <class Tni>
int CIsoValuePrePoint_d<Tni>::m_XCount = 0;

//----------------------------------------------------------------------------------------

template <class Err, class AIv, class Pro>
class CIsoValue_d  : public CPointDetector_d<Err::Tni, CIsoValuePrePoint_d<Err::Tni> >, 
					 public CIsoValueList_d<Err::Tni>
{
public:
typedef typename CIsoValue_d<Err,AIv,Pro>	Self;
typedef typename Err::Tni					Tni;
typedef typename CIsoValueList_d<Tni>		IvlParent;
typedef typename Tni::Tn					Tn;
typedef typename Tn::Geom_traits			Gt;
typedef typename Gt::FT						FT;
typedef typename Tn::Point					Point;
typedef typename Tni::Ch					Ch;
typedef typename Tni::Img					Img;
typedef typename Img::Coord					Coord;
typedef typename AIv						AutoIVScanner;		
typedef typename AIv::Op					AIOp;		
typedef typename CIsoValuePrePoint_d<Tni>	PrePoint;

public:
	CIsoValue_d();
	virtual ~CIsoValue_d();
	virtual void ReadParams();
	inline bool operator()(Coord c);
	inline bool PointError(Point c, FT& Error);
	inline Point FinalPoint(PrePoint& p);
protected:
	bool AutoIv();
private:
	Iv m_CurrSing, m_LastSing, m_CurrScalar, m_LastScalar, m_GreaterValue;
	Coord m_LastCoord;
	IvList m_ivl;
	Err m_Error;
	AutoIVScanner m_AutoIvScanner;
	AIOp m_AIOp;
	Pro m_Pro;
};

template <class Err,class AIv,class Pro>
CIsoValue_d<Err,AIv,Pro>::CIsoValue_d() {}
template <class Err,class AIv,class Pro>
CIsoValue_d<Err,AIv,Pro>::~CIsoValue_d() {}

template <class Err,class AIv,class Pro>
void CIsoValue_d<Err,AIv,Pro>::ReadParams()
{
	IvlParent::ReadParams();
	m_Error.ReadParams();
	m_Pro.Init(m_pImg, (IvlParent*)this);
}

template <class Err,class AIv,class Pro>
bool CIsoValue_d<Err,AIv,Pro>::AutoIv()
{
	if ( !U_BEGIN_PROC_ASK(Auto-Iv) )
		return false;
	m_AutoIvScanner.Init(m_pTn, m_pImg);
	m_AIOp.Init(m_pImg);
	m_AutoIvScanner.Run(&m_AIOp);
	m_AIOp.GetValues(&m_ivl);
	m_AIOp.FPrint();
	return true;
}

template <class Err,class AIv,class Pro>
inline bool CIsoValue_d<Err,AIv,Pro>::operator()(Coord _CurrCoord)
{
	m_CurrScalar = (*m_pImg)(_CurrCoord);
	bool bRet = false;
	switch(m_nTime)
	{
	case 0:
		m_LastScalar = m_CurrScalar;
		m_LastCoord = _CurrCoord;
		m_nTime++;
		return bRet;
	default:
		float iv;
		bRet = (*(IvlParent*)this)(m_LastScalar, m_CurrScalar, m_LastCoord, _CurrCoord, m_LastDetectedCoord, iv); 
		if ( bRet )			
			m_LastDetectedCoord.Init(m_LastScalar, m_CurrScalar, m_LastCoord, _CurrCoord, iv);
		m_LastScalar = m_CurrScalar;
		m_LastCoord = _CurrCoord;
		return bRet;
	}
}

template <class Err,class AIv,class Pro>
inline bool CIsoValue_d<Err,AIv,Pro>::PointError(Point c, FT& Error)
{	return m_Error(c, m_CurrCell, Error);	}

template <class Err,class AIv,class Pro>
inline CIsoValue_d<Err,AIv,Pro>::Point CIsoValue_d<Err,AIv,Pro>::FinalPoint(PrePoint& p)
{	return m_Pro.Project(p); }


#endif // !defined(AFX_IsoValue_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)