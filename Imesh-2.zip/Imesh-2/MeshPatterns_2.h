// MeshPatterns_2.h: interface for the CMeshPatterns_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MESHPATTERNS_2_H__443B9ABC_5EB9_45E8_9AE3_4FB5DE97054B__INCLUDED_)
#define AFX_MESHPATTERNS_2_H__443B9ABC_5EB9_45E8_9AE3_4FB5DE97054B__INCLUDED_

#include "PatternMeasurement_d.h"
#include "RGBPatternMeasurement_d.h"
#include "TriangleScan.h"

template <class Tni>
class CMeshPatterns_2  
{
public:
typedef Tni::Tnd				Tnd;
typedef Tni::Tn					Tn;
typedef Tni::Img				Img;
typedef Tni::RGBImg				RGBImg;
typedef Tnd::Ch					Ch;
typedef Tnd::Gt					Gt;
typedef Tnd::FT					FT;
typedef Img::IntTraits			IT;
typedef CMedian_d<Img>			PM;
typedef CTriangleScan<PM,IT>	CellScan;
typedef IT::TriangleI_2			SimplexI;
typedef CRGBMedian_d<RGBImg>	RGBPM;
typedef CTriangleScan<RGBPM,IT>	RGBCellScan;

public:
	CMeshPatterns_2();
	virtual ~CMeshPatterns_2(){};
	void Init(Tn* pTn, Img* pImg, RGBImg* pRGBImg);
	void MakeAllCellPatterns();
	void CellPattern(Ch fh);
	void MakeAllRGBCellPattern();
	void RGBCellPattern(Ch fh);

private:
	Tn* m_pTn;
	Img* m_pImg;
	Tnd m_Tnd; 
	RGBImg* m_pRGBImg;
};

template <class Tni>
CMeshPatterns_2<Tni>::CMeshPatterns_2()
{
	m_pTn = NULL;
	m_pImg = NULL;
	m_pRGBImg = NULL;	
}

template <class Tni>
void CMeshPatterns_2<Tni>::Init(Tn* pTn, Img* pImg, RGBImg* pRGBImg)
{
	m_pTn = pTn;
	m_pImg = pImg;
	m_pRGBImg = pRGBImg;	
	m_Tnd.Init(pTn);
}

template <class Tni>
void CMeshPatterns_2<Tni>::CellPattern(Ch fh)
{
	FT &cell_ptt = fh->info().Pattern();
	unsigned long& cell_area = fh->info().ScanArea();
	SimplexI tI = TniU::FaceToTriangleI<Gt>(fh);	
	PM msrmt(m_pImg);
	CellScan cs;
	cs(&tI, &msrmt);
	cell_ptt = msrmt.Result();
	cell_area = msrmt.ScanArea();
}

template <class Tni>
void CMeshPatterns_2<Tni>::RGBCellPattern(Ch fh)
{
	FT &cell_ptt = fh->info().Pattern();
	SimplexI tI = TniU::FaceToTriangleI<Gt>(fh);	
	RGBPM msrmt(m_pRGBImg);
	RGBCellScan cs;
		cs(&tI, &msrmt);
	fh->info().RGB() = msrmt.Result();
}

template <class Tni>
void CMeshPatterns_2<Tni>::MakeAllCellPatterns()
{
	U_BEGIN_SUB_PROC_T_(Cell-Patterns);	
	for ( Tnd::CIt ci = m_Tnd.cells_begin(); ci != m_Tnd.cells_end(); ++ci )
		CellPattern(ci);
	U_END_SUB_PROC_N_T_(m_Tnd.number_of_cells());
}

template <class Tni>
void CMeshPatterns_2<Tni>::MakeAllRGBCellPattern()
{
	for ( Tnd::CIt ci = m_Tnd.cells_begin(); ci != m_Tnd.cells_end(); ++ci )
		RGBCellPattern(ci);
}

#endif // !defined(AFX_MESHPATTERNS_2_H__443B9ABC_5EB9_45E8_9AE3_4FB5DE97054B__INCLUDED_)
