#include "matrix.h"
#include <cmath>

my_vector::my_vector(int r)
{
     rows = r; 
     array = new double[rows];
     for(int i = 0; i < rows; i++)
       array[i] = 0.0; 
}

void my_vector::print()
{
	std::cerr << "(";
	for( int i = 0; i < rows; i++)
		std::cerr << (*this)[i] << ",";
	std::cerr << ")" << std::endl;
}

my_vector::my_vector(const my_vector &object)
{
     rows = object.size();     
     array = new double[rows];

     for(int i = 0; i < rows; i++)
        array[i] = object.array[i];      
}

my_vector::~my_vector()
{
     delete array;
  	 rows =  0;
}


double my_vector::norm()
{
	
  double t = 0;	
  for (int i = 0; i < rows; i++)
    	t += (array[i])*(array[i]);
  t = sqrt(t);
  return t;
}


double my_vector::norm_infinity()
{
  int i;
  double t = fabs(array[0]);
	
  for (i = 1; i < rows; i++)
	  if(t < fabs(array[i]))
		  t = fabs(array[i]);
    
  return t;
}

my_vector my_vector::operator=(my_vector arg)
{
  for(int i = 0; i < rows; i++)
		array[i] = arg.array[i];
  return *this;
}


my_vector my_vector::operator-()
{
  my_vector var(rows);

  for(int i = 0; i < var.rows; i++)
  	var.array[i]= -array[i]; 
  return var;
}

my_vector operator+(my_vector arg, double x)
{
  my_vector temp( arg.rows);

  for(int i = 0; i < temp.rows; i++)
      temp.array[i] = arg.array[i] + x;
  return temp;
}

/*my_vector operator-(my_vector arg, double x)
{
  my_vector temp( arg.rows);

  for(int i = 0; i < temp.rows; i++)
      temp.array[i] = arg.array[i] - x;

  return temp;
}*/

my_vector operator*(my_vector arg, double x)
{
  my_vector temp( arg.rows);
  for(int i = 0; i < temp.rows; i++)
     temp.array[i] = arg.array[i] * x;
  return temp;
}

my_vector operator+(double x, my_vector arg)
{
  my_vector temp( arg.rows);

  for(int i = 0; i < temp.rows; i++)
      temp.array[i] = arg.array[i] + x;
  return temp;
}

/*my_vector operator-(double x, my_vector arg)
{
  my_vector temp( arg.rows);

  for(int i = 0; i < temp.rows; i++)
        temp.array[i] = arg.array[i] - x;
  return temp;
}*/

my_vector operator*(double x, my_vector arg)
{
  my_vector temp( arg.rows);

  for(int i = 0; i < temp.rows; i++)
        temp.array[i] = arg.array[i] * x;
  return temp;
}

my_vector my_vector::operator+=(double x)
{
  for(int i = 0; i < rows; i++)
 	array[i] += x;

  return *this;
}

my_vector my_vector::operator-=(double x)
{
  for(int i = 0; i < rows; i++)
  	array[i] -= x; 
  return *this;
}

my_vector my_vector::operator*=(double x)
{
  for(int i = 0; i < rows; i++)
  	array[i] *= x; 
  return *this;
}

my_vector my_vector::operator+=(my_vector &arg)
{
  rows = arg.rows;

  for(int i = 0; i < rows; i++)
  	array[i] += arg.array[i]; 
  return *this;
}

my_vector my_vector::operator-=(my_vector &arg)
{
  rows = arg.rows;
  for(int i = 0; i < rows; i++)
 	array[i] -= arg.array[i]; 
  return *this;
}

inline my_vector add(my_vector a, my_vector b)
{
  my_vector sum( a.rows);

  for(int i = 0; i < sum.rows; i++)
       sum.array[i] = a.array[i] + b.array[i];
  return sum;
}

my_vector operator+(my_vector a, my_vector b)
{
  return add( a, b);
}

/*inline my_vector sub(my_vector a, my_vector b)
{
  my_vector dif( a.rows);

  for(int i = 0; i < dif.rows; i++)
     dif.array[i] = a.array[i] - b.array[i];
  return dif;
}*/

/*my_vector operator-(my_vector a, my_vector b)
{
  return sub( a, b);
}*/

inline double dot_product(my_vector a, my_vector b)
{
  double sumv = 0.0;
   for(int i = 0; i < a.rows; i++)
             sumv  += (a.array[i]) * (b.array[i]);
  return sumv;
}

double operator*(my_vector a, my_vector b)
{
  return dot_product( a, b);
}

double my_vector::min()
{
  double minv = array[0];

  for(int i = 1; i < rows; i++)
        if(array[i] < minv)  minv = array[i]; 
  return minv;
}

double max(my_vector &arg)
{
  double maxv = arg.array[0];

  for(int i = 0; i < arg.rows; i++)
        if(arg.array[i] > maxv) maxv = arg.array[i]; 
  return maxv;
}

double my_vector::max()
{
  double minv = array[0];

  for(int i = 1; i < rows; i++)
        if(array[i] > minv)  minv = array[i]; 
  return minv;
}



my_vector my_vector::module()
{
  my_vector absv( rows);

  for(int i = 0; i < absv.rows; i++)
          absv.array[i] = fabsl(array[i]);
  return absv;
}

my_vector module(my_vector &arg)
{
  my_vector absv( arg.rows);

  for(int i = 0; i < absv.rows; i++)
        absv.array[i] = fabsl(arg.array[i]);
  return absv;
}



/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////



//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Matrix constructor

matrix::matrix(int r, int c)
{
	
     rows = r; columns = c;
     array = new double*[rows];

     for(int k = 0; k < rows; k++)
     {
        array[k] = new double[columns];
     }

     for(int i = 0; i < rows; i++)
     {
        for(int j = 0; j < columns; j++) { array[i][j] = 0.0; }
     }
}
 

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Matrix copy constructor

matrix::matrix(const matrix &object)
{
 // try
  {
     rows = object.height();
     columns = object.width();

     array = new double*[rows];

     for(int k = 0; k < rows; k++)
     {
        array[k] = new double[columns];
     }

     for(int i = 0; i < rows; i++)
     {
        for(int j = 0; j < columns; j++)
        {
           array[i][j] = object.array[i][j];
        }
     }
  }
 // catch(bad_alloc xa)
 // {
 //    cerr << "\nAlocation failure!" << endl;
 //    exit(EXIT_FAILURE);
 // }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Matrix destructor

matrix::~matrix()
{
  for(int k = 0; k < rows; k++)
  {
     delete[] array[k];
  }

  delete[] array;

  rows = columns = 0;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Matrix initializer

void matrix::make(int r, int c)
{
  //try
  {
     rows = r; columns = c;
     array = new double*[rows];

     for(int k = 0; k < rows; k++)
     {
        array[k] = new double[columns];
     }

     for(int i = 0; i < rows; i++)
     {
        for(int j = 0; j < columns; j++) { array[i][j] = 0.0; }
     }
  }
//  catch(bad_alloc xa)
 // {
 //    cerr << "\nAlocation failure!" << endl;
 //    exit(EXIT_FAILURE);
 // }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator =

matrix matrix::operator=(matrix arg)
{
  if((rows != arg.rows) && (columns != arg.columns))
  {
    rows = arg.rows;
    columns = arg.columns;

    if(!array)
    {
      for(int k = 0; k < rows; k++)
      {
         delete[] array[k];
      }

      delete[] array;
    }

  //  try
    {
       array = new double*[rows];

       for(int k = 0; k < rows; k++)
       {
          array[k] = new double[columns];
       }
    }
 //   catch(bad_alloc xa)
 //   {
 //      cerr << "Alocation failure!" << endl;
 //      exit(EXIT_FAILURE);
  //  }
  }

  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++) { array[i][j] = arg.array[i][j]; }
  }

  return *this;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading unary operator -

matrix matrix::operator-()
{
  matrix var(rows, columns);

  for(int i = 0; i < var.rows; i++)
  {
     for(int j = 0; j < var.columns; j++) { var.array[i][j] = -array[i][j]; }
  }

  return var;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator +

matrix operator+(matrix arg, double x)
{
  matrix temp( arg.rows, arg.columns);

  for(int i = 0; i < temp.rows; i++)
  {
     for(int j = 0; j < temp.columns; j++)
     {
        temp.array[i][j] = arg.array[i][j] + x;
     }
  }

  return temp;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator -

matrix operator-(matrix arg, double x)
{
  matrix temp( arg.rows, arg.columns);

  for(int i = 0; i < temp.rows; i++)
  {
     for(int j = 0; j < temp.columns; j++)
     {
        temp.array[i][j] = arg.array[i][j] - x;
     }
  }

  return temp;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator *

matrix operator*(matrix arg, double x)
{
  matrix temp( arg.rows, arg.columns);

  for(int i = 0; i < temp.rows; i++)
  {
     for(int j = 0; j < temp.columns; j++)
     {
        temp.array[i][j] = arg.array[i][j] * x;
     }
  }

  return temp;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator ^

matrix operator^(matrix arg, double x)
{
  matrix temp( arg.rows, arg.columns);

  for(int i = 0; i < temp.rows; i++)
  {
     for(int j = 0; j < temp.columns; j++)
     {
        temp.array[i][j] = powl( arg.array[i][j], x);
     }
  }

  return temp;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator +

matrix operator+(double x, matrix arg)
{
  matrix temp( arg.rows, arg.columns);

  for(int i = 0; i < temp.rows; i++)
  {
     for(int j = 0; j < temp.columns; j++)
     {
        temp.array[i][j] = arg.array[i][j] + x;
     }
  }

  return temp;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator -

matrix operator-(double x, matrix arg)
{
  matrix temp( arg.rows, arg.columns);

  for(int i = 0; i < temp.rows; i++)
  {
     for(int j = 0; j < temp.columns; j++)
     {
        temp.array[i][j] = arg.array[i][j] - x;
     }
  }

  return temp;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator *

matrix operator*(double x, matrix arg)
{
  matrix temp( arg.rows, arg.columns);

  for(int i = 0; i < temp.rows; i++)
  {
     for(int j = 0; j < temp.columns; j++)
     {
        temp.array[i][j] = arg.array[i][j] * x;
     }
  }

  return temp;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator +=

matrix matrix::operator+=(double x)
{
  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++) { array[i][j] += x; }
  }

  return *this;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator -=

matrix matrix::operator-=(double x)
{
  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++) { array[i][j] -= x; }
  }

  return *this;
}


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator *=

matrix matrix::operator*=(double x)
{
  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++) { array[i][j] *= x; }
  }

  return *this;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator ^=

matrix matrix::operator^=(double x)
{
  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++)
     {
        array[i][j] = powl( array[i][j], x);
     }
  }

  return *this;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator +=

matrix matrix::operator+=(matrix &arg)
{
  rows = arg.rows;
  columns = arg.columns;

  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++) { array[i][j] += arg.array[i][j]; }
  }

  return *this;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator -=

matrix matrix::operator-=(matrix &arg)
{
  rows = arg.rows;
  columns = arg.columns;

  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++) { array[i][j] -= arg.array[i][j]; }
  }

  return *this;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator ^=

matrix matrix::operator^=(matrix &arg)
{
  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++)
     {
        array[i][j] *= arg.array[i][j];
     }
  }

  return *this;
}

//----------------------------------------------------------------------------
// Function add() - Calculates and returns the addition between two matrices.
//----------------------------------------------------------------------------

matrix add(matrix a, matrix b)
{
  matrix sum( a.rows, a.columns);

  for(int i = 0; i < sum.rows; i++)
  {
     for(int j = 0; j < sum.columns; j++)
     {
        sum.array[i][j] = a.array[i][j] + b.array[i][j];
     }
  }

  return sum;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator +

matrix operator+(matrix a, matrix b)
{
  return add( a, b);
}

//----------------------------------------------------------------------------
// Function sub() - Calculates and returns the difference between two
//                  matrices.
//----------------------------------------------------------------------------

matrix sub(matrix a, matrix b)
{
  matrix dif( a.rows, a.columns);

  for(int i = 0; i < dif.rows; i++)
  {
     for(int j = 0; j < dif.columns; j++)
     {
        dif.array[i][j] = a.array[i][j] - b.array[i][j];
     }
  }

  return dif;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator -

/*matrix operator-(matrix a, matrix b)
{
  return sub( a, b);
}*/

//----------------------------------------------------------------------------
// Function product() - Calculates and returns the product between two
//                      matrices.
//----------------------------------------------------------------------------

matrix product(matrix a, matrix b)
{
  matrix p;

  if(a.columns == b.rows)
  {
    p.make( a.rows, b.columns);

    for(int i = 0; i < p.rows; i++)
    {
       for(int j = 0; j < p.columns; j++)
       {
          double sum = 0.0;

          for(int k = 0; k < a.columns; k++)
          {
             sum += a.array[i][k] * b.array[k][j];
          }

          p.array[i][j] = sum;
       }
    }
  }

  else if((a.rows == 1) && (a.columns == 1))
  {
    p.make( b.rows, b.columns);

    for(int i = 0; i < p.rows; i++)
    {
       for(int j = 0; j < p.columns; j++)
       {
          p.array[i][j] = a.array[0][0] * b.array[i][j];
       }
    }
  }

  else if((b.rows == 1) && (b.columns == 1))
  {
    p.make( a.rows, a.columns);

    for(int i = 0; i < p.rows; i++)
    {
       for(int j = 0; j < p.columns; j++)
       {
          p.array[i][j] = b.array[0][0] * a.array[i][j];
       }
    }
  }

  return p;
}

my_vector product2(matrix a, my_vector b)
{
	my_vector p(b.size());
	for(int i = 0; i < a.rows;i++)
		for(int j = 0; j < a.columns;j++)		
			p.set(i, p.get(i) +  (a[i][j] * b.get(j) ));
	return p;
}

my_vector operator*(matrix &a, my_vector &b)
{
	return product2(a,b);
}
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator *

matrix operator*(matrix a, matrix b)
{
  return product( a, b);
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

// Overloading operator ^

matrix operator^(matrix a, matrix b)
{
  matrix temp( a.rows, a.columns);

  for(int i = 0; i < temp.rows; i++)
  {
     for(int j = 0; j < temp.columns; j++)
     {
        temp.array[i][j] = a.array[i][j] * b.array[i][j];
     }
  }

  return temp;
}

//----------------------------------------------------------------------------
// Function delta() - Calculates and it returns the determinative from one
//                    matrix.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Menber version
//----------------------------------------------------------------------------

double matrix::delta()
{
  double x = 1.0;

  matrix g = gaussian();

  for(int k = 0; k < g.rows; k++)
  {
     if((x > 0.0) && (x <= MAXLD)) { return MAXLD; }

     else if((x < 0.0) && (x >= -MAXLD)) { return -MAXLD; }

     else { x *= g.array[k][k]; }
  }

  return x;
}

//----------------------------------------------------------------------------
// Friend version
//----------------------------------------------------------------------------

double delta(matrix &arg)
{
  double x = 1.0;

  matrix g = gaussian(arg);

  for(int k = 0; k < g.rows; k++)
  {
     if((x > 0.0) && (x <= MAXLD)) { return MAXLD; }

     else if((x < 0.0) && (x >= -MAXLD)) { return -MAXLD; }

     else { x *= g.array[k][k]; }
  }

  return x;
}

//----------------------------------------------------------------------------
// Function min() - Calculates and returns the minimum value of one matrix.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Member version
//----------------------------------------------------------------------------

double matrix::min()
{
  double min = array[0][0];

  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++)
     {
        if(array[i][j] < min) { min = array[i][j]; }
     }
  }

  return min;
}

//----------------------------------------------------------------------------
// Friend version
//----------------------------------------------------------------------------

double min(matrix &arg)
{
  double min = arg.array[0][0];

  for(int i = 0; i < arg.rows; i++)
  {
     for(int j = 0; j < arg.columns; j++)
     {
        if(arg.array[i][j] < min) { min = arg.array[i][j]; }
     }
  }

  return min;
}

//----------------------------------------------------------------------------
// Function max() - Calculates and returns the maximum value of one matrix.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Menber version
//----------------------------------------------------------------------------

double matrix::max()
{
  double max = array[0][0];

  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++)
     {
        if(array[i][j] > max) { max = array[i][j]; }
     }
  }

  return max;
}



//----------------------------------------------------------------------------
// Friend version
//----------------------------------------------------------------------------

double max(matrix &arg)
{
  double max = arg.array[0][0];

  for(int i = 0; i < arg.rows; i++)
  {
     for(int j = 0; j < arg.columns; j++)
     {
        if(arg.array[i][j] > max) { max = arg.array[i][j]; }
     }
  }

  return max;
}

//----------------------------------------------------------------------------
// Function module() - Calculates and returns one matrix whose elements are
//                     the absolute values from the original matrix.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Member version
//----------------------------------------------------------------------------

matrix matrix::module()
{
  matrix absv( rows, columns);

  for(int i = 0; i < absv.rows; i++)
  {
     for(int j = 0; j < absv.columns; j++)
     {
        absv.array[i][j] = fabsl(array[i][j]);
     }
  }

  return absv;
}

//----------------------------------------------------------------------------
// Friend version
//----------------------------------------------------------------------------

matrix module(matrix &arg)
{
  matrix absv( arg.rows, arg.columns);

  for(int i = 0; i < absv.rows; i++)
  {
     for(int j = 0; j < absv.columns; j++)
     {
        absv.array[i][j] = fabsl(arg.array[i][j]);
     }
  }

  return absv;
}

//----------------------------------------------------------------------------
// Function transpose() - Returns the transpose of one matrix.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Member version
//----------------------------------------------------------------------------

matrix matrix::transpose()
{
  matrix t( columns, rows);

  for(int i = 0; i < t.rows; i++)
  {
     for(int j = 0; j < t.columns; j++)
     {
        t.array[i][j] = array[j][i];
     }
  }

  return t;
}

//----------------------------------------------------------------------------
// Friend version
//----------------------------------------------------------------------------

matrix transpose(matrix &arg)
{
  matrix t( arg.columns, arg.rows);

  for(int i = 0; i < t.rows; i++)
  {
     for(int j = 0; j < t.columns; j++)
     {
        t.array[i][j] = arg.array[j][i];
     }
  }

  return t;
}

//----------------------------------------------------------------------------
// Function gaussian() - Calculates and returns the gaussian from one matriz.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Member version
//----------------------------------------------------------------------------

matrix matrix::gaussian()
{
  matrix g( rows, columns);

  for(int i = 0; i < g.rows; i++)
  {
     for(int j = 0; j < g.columns; j++)
     {
        g.array[i][j] = array[i][j];
     }
  }

  for(int j = 0; j < g.columns; j++)
  {
     if((g.array[j][j] == 0.0) && (j < rows-1))
     {
       g.exchange_rows( j, j+1);
     }

     for(int i = j+1; i < g.rows; i++)
     {
        if(g.array[i][j] == 0.0) i++;

        if(i < rows)
        {
          double x = g.array[i][j] / g.array[j][j];

          for(int k = j; k < g.columns; k++)
          {
             g.array[i][k] -= g.array[j][k] * x;
          }
        }
     }
  }

  return g;
}

//----------------------------------------------------------------------------
// Friend version
//----------------------------------------------------------------------------

matrix gaussian(matrix &arg)
{
  matrix g( arg.rows, arg.columns);

  for(int i = 0; i < g.rows; i++)
  {
     for(int j = 0; j < g.columns; j++)
     {
        g.array[i][j] = arg.array[i][j];
     }
  }

  for(int j = 0; j < g.columns; j++)
  {
     if((g.array[j][j] == 0.0) && (j < g.rows-1))
     {
       g.exchange_rows( j, j+1);
     }

     for(int i = j+1; i < g.rows; i++)
     {
        if(g.array[i][j] == 0.0) i++;

        if(i < g.rows)
        {
          double x = g.array[i][j] / g.array[j][j];

          for(int k = j; k < g.columns; k++)
          {
             g.array[i][k] -= g.array[j][k] * x;
          }
        }
     }
  }

  return g;
}

//----------------------------------------------------------------------------
// Function cholesky() - Calculates and returns an inferior triangular matrix
//                       gotten by a triangular decomposition algorithm based
//                       in Cholesky's method.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Member version
//----------------------------------------------------------------------------

matrix matrix::cholesky()
{
  double sum;

  matrix g( rows, columns);

  for(int i = 0; i < g.rows; i++)
  {
     for(int j = 0; j < i; j++)
     {
        sum = 0.0;

        for(int k = 0; k < j; k++)
        {
           sum += g.array[i][k] * g.array[j][k];
        }

        g.array[i][j] = (array[i][j] - sum) / g.array[j][j];
     }

     sum = 0.0;

     for(int k = 0; k < i; k++)
     {
        sum += g.array[i][k] * g.array[i][k];
     }

     if(array[i][i] < sum) { break; }

     else { g.array[i][i] = sqrtl(array[i][i] - sum); }
  }

  return g;
}

//----------------------------------------------------------------------------
// Friend version
//----------------------------------------------------------------------------

matrix cholesky(matrix &arg)
{
  double sum;

  matrix g( arg.rows, arg.columns);

  for(int i = 0; i < g.rows; i++)
  {
     for(int j = 0; j < i; j++)
     {
        sum = 0.0;

        for(int k = 0; k < j; k++)
        {
           sum += g.array[i][k] * g.array[j][k];
        }

        g.array[i][j] = (arg.array[i][j] - sum) / g.array[j][j];
     }

     sum = 0.0;

     for(int k = 0; k < i; k++)
     {
        sum += g.array[i][k] * g.array[i][k];
     }

     if(arg.array[i][i] < sum) { break; }

     else { g.array[i][i] = sqrtl(arg.array[i][i] - sum); }
  }

  return g;
}

//----------------------------------------------------------------------------
// Function inverse() - Calculates and returns the inverse from one matrix.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Member version
//----------------------------------------------------------------------------

matrix matrix::inverse()
{
  matrix inv = eye(rows);

  matrix mat( rows, columns);

  for(int i = 0; i < mat.rows; i++)
  {
     for(int j = 0; j < mat.columns; j++)
     {
        mat.array[i][j] = array[i][j];
     }
  }

  if(delta() == 0.0) return inv;

  for(int j = 0; j < inv.columns; j++)
  {
     if((fabsl(mat.array[j][j]) < TOLCG) && (j < inv.rows-1))
     {
       mat.exchange_rows( j, j+1);
       inv.exchange_rows( j, j+1);
     }

     for(int i = j+1; i < inv.rows; i++)
     {
        if(mat.array[i][j] == 0.0) i++;

        if(i < inv.rows)
        {
          double x = mat.array[i][j] / mat.array[j][j];

          for(int k = 0; k < inv.columns; k++)
          {
             mat.array[i][k] -= mat.array[j][k] * x;
             inv.array[i][k] -= inv.array[j][k] * x;
          }
        }
     }
  }

  for(j = inv.columns-1; j > 0; j--)
  {
     if((fabs(mat.array[j][j]) < TOLCG) && (j > 0))
     {
       mat.exchange_rows( j-1, j);
       inv.exchange_rows( j-1, j);
     }

     for(i = j-1; i >= 0; i--)
     {
        if(mat.array[i][j] == 0.0) i--;

        if(i >= 0)
        {
          double x = mat.array[i][j] / mat.array[j][j];

          for(int k = 0; k < inv.columns; k++)
          {
             mat.array[i][k] -= mat.array[j][k] * x;
             inv.array[i][k] -= inv.array[j][k] * x;
          }
        }
     }
  }

  for(int u = 0; u < inv.rows; u++)
  {
     for(int v = 0; v < inv.columns; v++)
     {
        inv.array[u][v] /= mat.array[u][u];
     }
  }

  return inv;
}

//----------------------------------------------------------------------------
// Friend version
//----------------------------------------------------------------------------

matrix inverse(matrix &arg)
{
  matrix inv = eye(arg.rows);

  matrix mat( arg.rows, arg.columns);

  mat = arg;

  if(delta(arg) == 0.0) return inv;

  for(int j = 0; j < inv.columns; j++)
  {
     if((fabsl(mat.array[j][j]) < TOLCG) && (j < inv.rows-1))
     {
       mat.exchange_rows( j, j+1);
       inv.exchange_rows( j, j+1);
     }

     for(int i = j+1; i < inv.rows; i++)
     {
        if(mat.array[i][j] == 0.0) i++;

        if(i < inv.rows)
        {
          double x = mat.array[i][j] / mat.array[j][j];

          for(int k = 0; k < inv.columns; k++)
          {
             mat.array[i][k] -= mat.array[j][k] * x;
             inv.array[i][k] -= inv.array[j][k] * x;
          }
        }
     }
  }

  for(j = inv.columns-1; j > 0; j--)
  {
     if((fabs(mat.array[j][j]) < TOLCG) && (j > 0))
     {
       mat.exchange_rows( j-1, j);
       inv.exchange_rows( j-1, j);
     }

     for(int i = j-1; i >= 0; i--)
     {
        if(mat.array[i][j] == 0.0) i--;

        if(i >= 0)
        {
          double x = mat.array[i][j] / mat.array[j][j];

          for(int k = 0; k < inv.columns; k++)
          {
             mat.array[i][k] -= mat.array[j][k] * x;
             inv.array[i][k] -= inv.array[j][k] * x;
          }
        }
     }
  }

  for(int u = 0; u < inv.rows; u++)
  {
     for(int v = 0; v < inv.columns; v++)
     {
        inv.array[u][v] /= mat.array[u][u];
     }
  }

  return inv;
}

//----------------------------------------------------------------------------
// Function exchange_rows() - Changes the x row by the y row.
//----------------------------------------------------------------------------

void matrix::exchange_rows(int x, int y)
{
  for(int k = 0; k < columns; k++)
  {
     double temp = array[x][k];
     array[x][k] = array[y][k];
     array[y][k] = temp;
  }
}

//----------------------------------------------------------------------------
// Function exchange_columns() - Changes the x column by the y column.
//----------------------------------------------------------------------------

void matrix::exchange_columns(int x, int y)
{
  for(int k = 0; k < rows; k++)
  {
     double temp = array[k][x];
     array[k][x] = array[k][y];
     array[k][y] = temp;
  }
}

//----------------------------------------------------------------------------
// Function eye() - Generate one matrix identity.
//----------------------------------------------------------------------------

matrix eye(int size)
{
  matrix id( size, size);

  for(int k = 0; k < size; k++)
  {
     id.array[k][k] = 1.0;
  }

  return id;
}


double matrix::norm()
{
	double _sum = 0.0;
  for(int i = 0; i < rows; i++)
     for(int j = 0; j < columns; j++)
        _sum+= array[i][j]*array[i][j];
	return _sum;
}

//----------------------------------------------------------------------------
// Function print() - Displays one matrix on screen.
//----------------------------------------------------------------------------

void matrix::print()
{

  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++)
     {
        cout << array[i][j];

        if(j < columns) { cout << "\t"; }
     }

     cout << endl;
  }

  cout << "\n";
}
//----------------------------------------------------------------------------
// Function GetFromFile() - Reads one matrix from a file.
//----------------------------------------------------------------------------

matrix GetFromFile(char *filename)
{
  ifstream data(filename);

  if(!data)
  {
    cerr << "\nUnable to open file!" << endl;
    exit(EXIT_FAILURE);
  }

  int rows, columns;

  data >> rows >> columns;

  matrix m( rows, columns);

  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++)
     {
        data >> m.array[i][j];
     }
  }

  data.close();

  return m;
}

//----------------------------------------------------------------------------
// Function SaveToFile() - Save matrix to file.
//----------------------------------------------------------------------------

void matrix::SaveToFile(char *filename)
{
  ofstream data(filename);

  if(!data)
  {
    cerr << "\nUnable to open file!" << endl;
    exit(EXIT_FAILURE);
  }

  data << rows << ' ' << columns << "\n\n";

  data << setiosflags(ios::fixed) << setprecision(6);

  for(int i = 0; i < rows; i++)
  {
     for(int j = 0; j < columns; j++)
     {
        data << array[i][j];

        if(j < columns) { data << "\t"; }
     }

     data << endl;
  }

  data.close();
}


void matrix::normalize()
{
	double sum = 0.0;
	for(int i = 0 ; i < rows; i++)
		sum += fabs(array[i][0]);
	for(i = 0; i < rows; i++)
    	for(int j = 0; j < columns; j++)
  			array[i][j] /= sum;
	return ;
}
