#ifndef matrix_H
#define matrix_H
//----------------------------------------------------------------------------
#define TOLCG 1e-5
#define MAXLD 3.37e49
//----------------------------------------------------------------------------
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
//----------------------------------------------------------------------------
using namespace std;

#ifndef DIM
#define DIM 2
#endif

class my_vector
{
  public :

	int rows;
    double *array;  

  public :
	  
    my_vector(int r = DIM);
    my_vector(const my_vector &object);

    ~my_vector();
    inline int size() const { return rows; }

    void set(int i , double X ) { array[i] = X; }
   	double get(int i) { return array[i]; }
    double operator[](unsigned int p) { return array[p] ; }	

    my_vector operator=(my_vector arg);

    my_vector operator-();
	//note que os operadores de + e - de um real com um vetor ou uma matriz
	//nao existe matematicamente, no entanto aqui estao implementados para somar
	//ou subtrair um numero de todos as componentes do vetor ou da matriz

    friend my_vector operator+(my_vector arg, double x);
    friend my_vector operator*(my_vector arg, double x);
//    friend my_vector operator-(my_vector arg, double x);

my_vector operator-(double x)
{
  my_vector temp(rows);

  for(int i = 0; i < temp.rows; i++)
      temp.array[i] = array[i] - x;

  return temp;
}
  

    friend my_vector operator+(double x, my_vector arg);
//    friend my_vector operator-(double x, my_vector arg);
    friend my_vector operator*(double x, my_vector arg);

    my_vector operator+=(double x);
    my_vector operator-=(double x);
    my_vector operator*=(double x);
  

    my_vector operator+=(my_vector &arg);
    my_vector operator-=(my_vector &arg);
  

    friend my_vector add(my_vector a, my_vector b);
    friend my_vector operator+(my_vector a, my_vector b);

    friend my_vector sub(my_vector a, my_vector b);
//    friend my_vector operator-(my_vector a, my_vector b);

	my_vector sub(my_vector a, my_vector b)
	{
	  my_vector dif( a.rows);

	  for(int i = 0; i < dif.rows; i++)
		 dif.array[i] = a.array[i] - b.array[i];
	  return dif;
	}

	my_vector operator-(my_vector b)
	{
	  return sub(*this, b);
	}

    friend double dot_product(my_vector a, my_vector b);
    friend double operator*(my_vector a, my_vector b);

    double min();
    friend double min(my_vector &arg);

    double max();
    friend double max(my_vector &arg);
 
    my_vector module();
    friend my_vector module(my_vector &arg);
		
	double norm();
	double norm_infinity();
	void print();

};

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
// Matrix class
class matrix
{
  public:
    int rows, columns;  // Matrix dimensions
    double **array;     // Matrix elements

  public:
    matrix(int r = DIM, int c = DIM);          // Constructor

    matrix(const matrix &object);          // Copy constructor

    ~matrix();                             // Destructor

    void make(int  r = DIM, int c = DIM);      // Initializer

    ////////////////////////////////////////////////
    // Returns the height (in rows) of one matrix //
    ////////////////////////////////////////////////

    inline int height() const { return rows; }
	double norm();
    //////////////////////////////////////////////////
    // Returns the width (in columns) of one matrix //
    //////////////////////////////////////////////////

    inline int width() const { return columns; }

	void set(int i, int j, double X ) { array[i][j] = X; }
    double get(int i , int j ) { return array[i][j]; }
    double *operator[](unsigned int p) { return array[p] ; }

    matrix operator=(matrix arg);

    matrix operator-();

    friend matrix operator+(matrix arg, double x);
//    friend matrix operator-(matrix arg, double x);
    friend matrix operator*(matrix arg, double x);
    friend matrix operator^(matrix arg, double x);
	
	friend my_vector product2(matrix a, my_vector b);
	friend my_vector operator*(matrix &arg, my_vector &b);  

    friend matrix operator+(double x, matrix arg);
//    friend matrix operator-(double x, matrix arg);
    friend matrix operator*(double x, matrix arg);

    matrix operator+=(double x);
    matrix operator-=(double x);
    matrix operator*=(double x);
    matrix operator^=(double x);

    matrix operator+=(matrix &arg);
    matrix operator-=(matrix &arg);
    matrix operator^=(matrix &arg);
	void normalize();
    friend matrix add(matrix a, matrix b);
    friend matrix operator+(matrix a, matrix b);

    friend matrix sub(matrix a, matrix b);
    //friend matrix operator-(matrix a, matrix b);

	matrix operator-(matrix b)
	{
	  return sub(*this, b);
	}

    friend matrix product(matrix a, matrix b);
    friend matrix operator*(matrix a, matrix b);

    friend matrix operator^(matrix a, matrix b);

    double min();
    friend double min(matrix &arg);

    double max();
    friend double max(matrix &arg);

    double delta();
    friend double delta(matrix &arg);

    matrix module();
    friend matrix module(matrix &arg);

    matrix transpose();
    friend matrix transpose(matrix &arg);

    matrix gaussian();
    friend matrix gaussian(matrix &arg);

    matrix cholesky();
    friend matrix cholesky(matrix &arg);

    matrix inverse();
    friend matrix inverse(matrix &arg);

    friend matrix eye(int size);
    friend matrix GetFromFile(char *filename);

    void SaveToFile(char *filename);

    void exchange_rows(int x, int y);
    void exchange_columns(int x, int y);
    void print();
};
#endif
