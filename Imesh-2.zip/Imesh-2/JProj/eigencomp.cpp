#include "eigencomp.h"

#define ERROR 1e-20
//////////////////////////////////////////////////////////////////
bool eigencomp::SolveBiConjugate( int iter, real eps, int n, matrix  &M, my_vector &B, my_vector &sol)
{
  my_vector p(n),  P(n), r(n), R(n), x(n), X(n), Ap(n);
  my_vector pbarra(n),  Pbarra(n), rbarra(n), Rbarra(n),   Aptransposta(n);
  matrix Mtransposta(n,n);
  
  real a, b;
  
  int cont = 1;
    
  p = B;
  r = B;
  pbarra = B;
  rbarra = B;
   
  Mtransposta = M.transpose();
	
  while( r.norm() >= eps && cont < iter) 
  {
	cont++;
	Ap = M * p;
	Aptransposta = Mtransposta*pbarra;    	
	if(fabs(Ap * pbarra) == 0.0f)
	{
		printf("Divisao por zero no gradientes BI-conjugados \n");
		return false;
	}
	a = (r * rbarra) / (Ap * pbarra); 
	R = r - (Ap * a);	
	Rbarra = rbarra  - (Aptransposta * a); 

	if(fabs(rbarra * r) == 0.0f)
	{
		printf("Divisao por zero no gradientes BI-conjugados \n");
		return false;
	}

    b = (Rbarra * R ) / (rbarra * r); 
	P = R + (p * b);
	Pbarra = Rbarra + (pbarra * b);
	X = x + ( p * a );
    	p = P;
    	r = R;
	pbarra = Pbarra;
    	rbarra = Rbarra;
    	x = X;
   }
    sol = x;
   //	printf("Iteracao %5d, Residuo = %e \n", cont, r.norm() );
   return true;
}

/*--------------------------------------------------------*/
/* Resolve o sistema usando o metodo dos Gradientes Conju-*/
/* gados.                                                 */
/*--------------------------------------------------------*/
bool eigencomp::SolveCG( int iter, real eps, int n, matrix  &M, my_vector &B, my_vector &sol)
{
  my_vector p(n), P(n), r(n), R(n), x(n), X(n), Ap(n);
  real a, b;
  int cont = 1;
  p = B; 
  r = B;
 // printf("iterando...\n");
  while( r.norm() >= eps && cont < iter)
  {	  
	cont++;
	Ap = M * p;
//	Ap.print();
	if(fabs(Ap*p) == 0.0f)
	{
		printf("Divisao por zero no gradientes conjugados \n");
		return false;
	}
    a = (r * p) / (Ap * p);       
    X = x + ( p * a );         
    R = r - (Ap * a);            
   	b = (R * Ap ) / (p * Ap); 
    P = R - (p * b);             
    p = P;
    r = R;
    x = X; 
	}
//	printf("Iteracao %5d, Residuo = %e \n", cont, r.norm() );
    sol = x;
	return true;
}

bool eigencomp::SolveSmallestEigenvalue(int n, real &eigenvalue, matrix &M, my_vector &x)
{	
	my_vector y(n);
	real alpha, eigenvalueold = 0.0;
	
	eigenvalue = 1.0;
	
	for(int j = 0; j < n; j++)
		x.set(j, 1.0);	
	int cont = 0;
	while( fabs(eigenvalueold - eigenvalue) > ERROR && cont++ < 20)
	{
		if( this->SolveBiConjugate(20,ERROR,n,M,x,y) )	
		//if(	this->SolveCG(20,ERROR,n,M,x,y) )
		{			
			alpha = y.norm_infinity();	
			eigenvalueold = eigenvalue;
			eigenvalue = (x*y)/(x*x);
			x = y*(1.0/alpha);				
		}
		else return false;
	}
	x = x*(1/x.norm());
	return true;
}

void eigencomp::SolveLargestEigenvalueSimetricMatrix(int n, real &eigenvalue, matrix &M, my_vector &x)
{	
	my_vector y(n);	
	real eigenvalueold = 0.0, alpha;
	eigenvalue = 1.0;
	
	for(int j = 0; j < n; j++)
		x.set(j, 1.0);
	
	while( fabs(eigenvalueold - eigenvalue) > ERROR)
	{		
		y = M*x;	
		alpha = y.norm_infinity();		
		eigenvalueold = eigenvalue;		
		eigenvalue = (x*y)/(x*x);			
		x = y*(1.0/alpha);
	}
	x = x*(1/x.norm());
}
