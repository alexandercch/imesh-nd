#ifndef _EIGENCOMP_H
#define _EIGENCOMP_H

#ifndef real
#define real double
#endif

#include "matrix.h"

#include <iostream>
#include <cmath>
#include <cstdio>
 

class eigencomp
{
 
 public:

  eigencomp(){};
  ~eigencomp(){};
  bool SolveCG( int iter, real eps, int n, matrix  &M, my_vector  &B, my_vector &sol);
  bool  SolveBiConjugate( int iter, real eps, int n, matrix &M, my_vector &B, my_vector &sol);
  
  bool SolveSmallestEigenvalue(int n, real &eigenvalue, matrix &M, my_vector &sol);  
  void SolveLargestEigenvalueSimetricMatrix(int n, real &eigenvalue, matrix &M, my_vector &sol);  
  
};


#endif
