// Gradient_2.h: interface for the CGradient_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Gradient_2_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
#define AFX_Gradient_2_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_

#include "Gradient_d.h"

template <class Mask, class Err>
class CGradient_2  : public CGradient_d<Mask,Err>
{
typedef typename CGradient_d<Mask,Err> Parent;
public:
	void TestImg();
	void ReadParams();
};

template <class Mask, class Err>
void CGradient_2<Mask,Err>::ReadParams()
{
	TestImg();
	Parent::ReadParams();
}

template <class Mask, class Err>
void CGradient_2<Mask,Err>::TestImg()
{
	if ( !U_BEGIN_PROC_ASK(img-gradient-test) )
		return;

	Img gimg;
	double threshold;
	int i, j;
	
	RectangleI_2 r = m_pImg->RectI();
	gimg.Resize(m_pImg->XMax(), m_pImg->YMax());
	do
	{
		(*m_pWs)<<*m_pImg;
		cout<<"\nthreshold: "; cin>>threshold;
		for ( i = r.xmin(); i <= r.xmax(); i++ )
			for ( j = r.ymin(); j <= r.ymax(); j++ )
				gimg(i, j) = 0;
	
		for ( i = r.xmin(); i <= r.xmax(); i++ )
			for ( j = r.ymin(); j <= r.ymax(); j++ )
				gimg(i,j) = 255*(m_pMask->Convolution(Img::Coord(i,j)) > threshold) ;

		m_pWs->clear();
		(*m_pWs)<<gimg;			
	}while( ! U_OK_ASK2("ok") );
	cout<<"\n";
}

#endif // !defined(AFX_Gradient_2_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
