// InCellPointSelector_d.h: interface for the CInCellPointSelector_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_InCellPointSelector_d_H__BE0350AA_55F2_4335_83F5_3F3E07BE4181__INCLUDED_)
#define AFX_InCellPointSelector_d_H__BE0350AA_55F2_4335_83F5_3F3E07BE4181__INCLUDED_

template <class PD, class PS>
class CInCellPointSelector_d  
{
public:
typedef typename PD					PointDetector;
typedef typename PS					PointSelector;
typedef typename PD::PrePoint		PrePoint;
typedef typename PS::Tn				Tn;
typedef typename Tn::Geom_traits	Gt;
typedef typename Tn::Point			Point;
typedef typename Gt::FT				FT;
typedef typename PD::Img			Img;
typedef typename Img::Coord			Coord;
typedef typename PD::Ch				Ch;
public:
	CInCellPointSelector_d();
	void Init(PointDetector* pd, PointSelector* ps);
	virtual ~CInCellPointSelector_d();
	void ReadParams();
	void SetCurrCell(Ch ch);
	inline void operator()(Coord c);
	inline void begin();
	inline void end();
	bool IsSelectedPoint(PrePoint& c, FT& error);
private:
	PointDetector* m_pPD; 
	PointSelector* m_pPS;
};

template <class PD, class PS>
CInCellPointSelector_d<PD,PS>::CInCellPointSelector_d()
{	m_pPD = NULL; m_pPS = NULL;		}

template <class PD, class PS>
CInCellPointSelector_d<PD,PS>::~CInCellPointSelector_d()
{}

template <class PD, class PS>
void CInCellPointSelector_d<PD,PS>::Init(PointDetector* pd, PointSelector* ps)
{	m_pPD = pd; m_pPS = ps;	}

template <class PD, class PS>
void CInCellPointSelector_d<PD,PS>::SetCurrCell(Ch ch)
{	m_pPD->SetCurrCell(ch); m_pPS->SetCurrCell(ch);	}

template <class PD, class PS>
void CInCellPointSelector_d<PD,PS>::ReadParams()
{	m_pPD->ReadParams(); m_pPS->ReadParams();	}

template <class PD, class PS>
bool CInCellPointSelector_d<PD,PS>::IsSelectedPoint(PrePoint& c, FT& error)	
{ 	
	if (!m_pPS->IsSelectedPoint(c))
		return false;
	return m_pPD->PointError(c, error);
}

template <class PD, class PS>
inline void CInCellPointSelector_d<PD,PS>::begin()	{	m_pPD->begin();	}
template <class PD, class PS>
inline void CInCellPointSelector_d<PD,PS>::end()	{	m_pPD->end();	}

template <class PD, class PS>
inline void CInCellPointSelector_d<PD,PS>::operator()(Coord c)
{
	if ( (*m_pPD)(c) ) 
		(*m_pPS)(m_pPD->LastDetectedCoord());
}

////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_InCellPointSelector_d_H__BE0350AA_55F2_4335_83F5_3F3E07BE4181__INCLUDED_)