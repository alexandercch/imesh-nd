// SmoothCellPatternNode_2.h: interface for the CSmoothPatternNode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMOOTHPATTERNNODE2_H__EE7E8582_2CAB_47A3_B403_BB35FC3A1728__INCLUDED_)
#define AFX_SMOOTHPATTERNNODE2_H__EE7E8582_2CAB_47A3_B403_BB35FC3A1728__INCLUDED_

template <class Tni>
struct CSmoothPatternNode_d  
{
public:
typedef typename CSmoothPatternNode_d<Tni>	Self;
typedef typename Tni::FT					FT;
typedef typename Tni::FI					FI;
typedef typename Tni::Tn					Tn;
typedef typename Tni::Ch					Ch;
public:
	CSmoothPatternNode_d(Tn* pTn, Ch ch)
	{
		m_pTn = pTn;
		m_ch = ch;
		m_fact = FI::MaxEdge(m_ch);
		m_patt = m_ch->Info().Pattern();
	}

	void MakeSum()
	{
		Ch ni; Self* si;
		m_sum = m_fact;
		for ( int i = 0; i < Tni::Dim; i++ )
		{
			ni = m_ch->neighbor(i);
			if ( m_pTn->is_infinite(ni) )
				continue;
			si = NodeFromCell(ni);
			m_sum += si->m_fact;
		}
	}

	void SmoothStep1(FT fThreshold)
	{
		m_patt_i = m_ch->Info().Pattern();
		if ( m_fact > fThreshold )
			return;
		Ch ni; Self* si;
		FT pa, fa, nn = 1;
		m_patt_i = m_patt_i;// * m_fact;
		for ( int i = 0; i < Tni::Dim; i++ )
		{
			ni = m_ch->neighbor(i);
			if ( m_pTn->is_infinite(ni) )
				continue;
			si = NodeFromCell(ni);
			pa = ni->Info().Pattern();
			fa = si->m_fact;
			m_patt_i += pa;// * fa;
			nn++;
		}
		m_patt_i /= nn;
	}

	void SmoothStep2()
	{	m_ch->Info().Pattern() = m_patt_i;	}

	void Clear()
	{	m_ch->Info().Pattern() = m_patt;	}

	static Self*& NodeFromCell(Ch ch)
	{ return (Self*&)(ch->Info().VoidPtr());}

public:
	FT m_sum, m_fact;
	Ch m_ch;
	Tn* m_pTn;
	FT m_patt_i, m_patt;

};

#endif // !defined(AFX_SMOOTHPATTERNNODE2_H__EE7E8582_2CAB_47A3_B403_BB35FC3A1728__INCLUDED_)
