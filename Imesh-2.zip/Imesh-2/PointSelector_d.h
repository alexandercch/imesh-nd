// PointSelector_d.h: interface for the CPointSelector_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PointSelector_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_)
#define AFX_PointSelector_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_

template <class PD>
class CPointSelector_d  
{
public:
typedef typename PD::Tni		Tni;
typedef typename Tni::Tn		Tn;
typedef typename Tni::Ch		Ch;
typedef typename Tni::Img		Img;
typedef typename Img::Coord		Coord;
typedef typename Tn::Point		Point;
typedef typename PD::PrePoint	PrePoint;

public:
	CPointSelector_d();
	virtual ~CPointSelector_d(){};
	void Init(Tn* pTn);
	inline bool IsSelectedPoint(PrePoint& c);
	virtual inline void SetCurrCell(Ch ch);
	virtual inline bool operator()(Point c){ return false; };
	virtual void ReadParams(){};
	Window_stream* m_ws;
protected:	
	PrePoint m_SelectedCoord;
	bool m_bSelectedCoord;
	Ch m_CurrCell;
	Tn* m_pTn;
};

template <class PD>
CPointSelector_d<PD>::CPointSelector_d() {	m_pTn = NULL;	}
template <class PD>
void CPointSelector_d<PD>::Init(Tn* pTn) {	m_pTn = pTn;	}

template <class PD>
inline bool CPointSelector_d<PD>::IsSelectedPoint(PrePoint& c)
{
	if ( m_bSelectedCoord )
	{	c = m_SelectedCoord; return true;	}
	return false;
}

template <class PD>
void CPointSelector_d<PD>::SetCurrCell(Ch ch)
{
	m_bSelectedCoord = false;	
	m_CurrCell = ch;
}


#endif // !defined(AFX_PointSelector_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_)
