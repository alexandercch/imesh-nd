// MGIntTraits.h: interface for the CITTraits class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ITTRAITS_H__0BC826B9_B184_4843_89F8_ED624D2B6D53__INCLUDED_)
#define AFX_ITTRAITS_H__0BC826B9_B184_4843_89F8_ED624D2B6D53__INCLUDED_

#include <CGAL/basic.h>
#include <CGAL/Cartesian.h>

struct CMGIntTraits
{
typedef int									INT;
typedef CGAL::Cartesian<INT>				CKI;
typedef CKI::Point_2						PointI_2;
typedef CKI::Iso_rectangle_2				RectangleI_2;	
typedef CKI::Segment_2						SegmentI_2;
typedef CKI::Triangle_2						TriangleI_2;
typedef CKI::Point_3						PointI_3;
typedef CKI::Iso_cuboid_3					Iso_cuboidI_3;
typedef CKI::Tetrahedron_3					TetrahedronI_3;	
typedef CKI::Segment_3						SegmentI_3;
};

#endif // !defined(AFX_ITTRAITS_H__0BC826B9_B184_4843_89F8_ED624D2B6D53__INCLUDED_)
