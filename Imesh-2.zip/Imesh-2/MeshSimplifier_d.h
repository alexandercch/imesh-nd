// MeshSimplifier_d.h: interface for the CMeshSimplifier_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MeshSimplifier_d_H__0C6CFB7F_5844_45A2_B54B_6B19B1BDD9E0__INCLUDED_)
#define AFX_MeshSimplifier_d_H__0C6CFB7F_5844_45A2_B54B_6B19B1BDD9E0__INCLUDED_

#include WRITER_H
#include "MeshRegion_d.h"

template <class BeG>
class CMeshSimplifier_d  
{
public:
typedef BeG								VBeGroup;
typedef VBeGroup::Tni					Tni;
typedef WRITER_CLASS<Tni>				Writer;
typedef Tni::Tnd						Tnd;
typedef Tnd::Tn							Tn;
typedef Tnd::VIt						VIt;
typedef Tnd::Cell_vector				Cell_vector;
typedef Tnd::Vertex_list				Vertex_list;
typedef CMeshRegion_d<Tni>				MeshRegion;
typedef MeshRegion::MeshRegionVector	Mrv;

public:
	CMeshSimplifier_d();
	virtual ~CMeshSimplifier_d();
	void Init(Tn* pTn);
	void SetDebugUtilObjects(Mrv* pMrv, VBeGroup* pVBeGroup, Writer* _w);
	void InteriorSim();
	bool RgnVariationInStart(VIt vi);
	virtual void BorderSim();
	void SRefresh();

protected:
	Tn* m_pTn;
	Tnd m_Tnd;
	Writer* w;
	Mrv* m_pMrv;
	VBeGroup* m_pVBeGroup;
};

template <class BeG>
CMeshSimplifier_d<BeG>::CMeshSimplifier_d()		
{	
	m_pTn = NULL; 
	w = NULL;
	m_pMrv = NULL;
	m_pVBeGroup = NULL;
}

template <class BeG>
CMeshSimplifier_d<BeG>::~CMeshSimplifier_d()	{}

template <class BeG>
void CMeshSimplifier_d<BeG>::Init(Tn* pTn)
{	
	m_Tnd.Init(m_pTn = pTn); 
}

template <class BeG>
void CMeshSimplifier_d<BeG>::SetDebugUtilObjects(Mrv* pMrv, VBeGroup* pVBeGroup, Writer* _w)
{
	w = _w;
	m_pMrv = pMrv;
	m_pVBeGroup = pVBeGroup;
}

template <class BeG>
void CMeshSimplifier_d<BeG>::SRefresh()	
{	
	m_pMrv->FixCellsToRegions(true); 	
	m_pVBeGroup->LoadEdgesFromTnInList(); 
//	w->Refresh();
}

template <class BeG>
void CMeshSimplifier_d<BeG>::InteriorSim()
{
	if ( !U_E_BEGIN_SUB_PROC_ASK(Interior-Simplification)	)
		return;
	U_START_DEF_TIME_;

	int count = 0;
	Vertex_list vl;
	Tnd::VIt vi;
	for ( vi = m_Tnd.vertices_begin(); vi != m_Tnd.vertices_end(); ++vi )
	{
		if ( RgnVariationInStart(vi) )
			continue;
		vl.push_back(vi);
		U_IF_COUNTER_EX(count, Tnd::NStep, Tnd::InfNStep, "*")
			U_SCOUT(count);
	}
	count = 0;
	Vertex_list::iterator it;
	for ( it = vl.begin(); it != vl.end(); ++it )
	{
		U_CGAL_WARNING(m_Tnd->remove(*it));
		U_IF_COUNTER_EX(count, Tnd::NStep, Tnd::InfNStep, "-")
			U_SCOUT(count);
	}

	U_END_SUB_PROC_N_T_E_(vl.size());
}

template <class BeG>
bool CMeshSimplifier_d<BeG>::RgnVariationInStart(VIt vi)
{
	Cell_vector cv;
	m_Tnd.incident_cells(vi, &cv);
	Cell_vector::iterator vei;
	
	vei = cv.begin();
	int nRgn = (*vei)->info().Region(), nRgnT;
	for ( ; vei != cv.end(); ++vei )
	{
		if ( m_Tnd->is_infinite(*vei) )	
			return true;
		nRgnT = (*vei)->info().Region();
		if ( nRgnT != nRgn )
			return true;
	}
	return false;
}

template <class BeG>
void CMeshSimplifier_d<BeG>::BorderSim()
{}

#endif // !defined(AFX_MeshSimplifier_d_H__0C6CFB7F_5844_45A2_B54B_6B19B1BDD9E0__INCLUDED_)
