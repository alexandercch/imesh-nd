// JProjection_2.h: interface for the CJProjection_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_JProjection_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)
#define AFX_JProjection_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_

#include "PointCloudProjection_2.h"
#include "JProj\eigencomp.h"
#include "JProj\matrix.h"

#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
#define tol 1e-5f
#define ITMAX 500
#define CGOLD 0.3819660
#define ZEPS 1.0e-80
#define SHIFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);

template <class Tni>
class CJProjection_2 : public CPointCloudProjection_2<Tni>
{
public:
	CJProjection_2();
	Point Project(Point& p);
	bool   building_covariance_matrix();
	CCloudPoint  get_normal_point();
	double evaluate_function(double x);
	CCloudPoint  set_mult_normal_vector(double &x);
	double evaluate_derivative(double x);
	double compute_minima_brents_derivative(double ax,double bx,double cx, double &xmin);
	double gaussian(double h,  CCloudPoint & p, CCloudPoint &q);
	double squared_distance(CCloudPoint &p, CCloudPoint &q);

private:	
	FT m_h; //cloud point spacing
	int m_iterac;
	double m_tmin;	
	matrix   *m_wcov;
	my_vector m_eigenvector;	
	eigencomp m_eigencalculus;
	CCloudPoint m_ppoint;
};

template <class Tni>
CJProjection_2<Tni>::CJProjection_2()
					:m_eigenvector(Tni::Dim)
{
	m_h = 1.5*::sqrt(2);
	m_iterac = 5;
}

template <class Tni>
CJProjection_2<Tni>::Point CJProjection_2<Tni>::Project(Point& p)
{
	MakeCloud(p);
	double eigenvalue = 0.0;
	m_ppoint = CCloudPoint(p.x(), p.y());

	for(int i = 0; i < m_iterac; i++)
	{
		m_tmin = 0.0f;				
		m_wcov = new matrix(Tni::Dim,Tni::Dim);
		if(building_covariance_matrix())
		{
			m_eigencalculus.SolveSmallestEigenvalue(m_eigenvector.size(),eigenvalue,*m_wcov,m_eigenvector);
		
			double a = -m_h*.5, n = 0.0f, b = m_h*.5;
			compute_minima_brents_derivative(a,n,b,m_tmin);

			m_ppoint = m_ppoint + get_normal_point()*m_tmin;
		}
		delete m_wcov;
	}
	Point pret(m_ppoint.get_x(), m_ppoint.get_y());
	WriteCloud(p, pret);
	return pret;
}

template <class Tni>
bool CJProjection_2<Tni>::building_covariance_matrix()
{
	for(register int j = 0; j < Tni::Dim; j++)				  
		for(register int k = 0; k < Tni::Dim; k++)
			for(register unsigned int i = 0; i < m_nCloudPoints;i++)
			{
				double x = gaussian(m_h,m_ppoint,m_pCloud[i]);
				m_wcov->set(j,k,	m_wcov->get(j,k) +  
								x * ( (m_pCloud[i].coordenadas[j] - m_ppoint[j])* 
								      (m_pCloud[i].coordenadas[k] - m_ppoint[k]) ) );
			}
	if(m_wcov->norm() > 1e-20)
		return true;
	else
	{ cerr << "Definiu uma matriz de covariancia quase nula\n";
		return false;
	}

}

template <class Tni>
double CJProjection_2<Tni>::gaussian(double h,  CCloudPoint & p, CCloudPoint &q)
{
	return (double)expl(-squared_distance(p,q)/(h*h));
}

template <class Tni>
double CJProjection_2<Tni>::squared_distance(CCloudPoint &p, CCloudPoint &q)
{
	return (p.get_x()-q.get_x())*(p.get_x()-q.get_x()) + (p.get_y()-q.get_y())*(p.get_y()-q.get_y());
}

template <class Tni>
CCloudPoint CJProjection_2<Tni>::get_normal_point()
{
	return  CCloudPoint(m_eigenvector[0],m_eigenvector[1]);
}

template <class Tni>
double CJProjection_2<Tni>::evaluate_function(double x)
{
	double sum = 0;
	CCloudPoint p1, p2, p3;
	p3 = get_normal_point();
	for(register unsigned int i = 0; i < m_nCloudPoints ; i++)	
	{				
		p2 = m_ppoint+set_mult_normal_vector(x);
		p1 = m_pCloud[i]-p2;
		double dot=p3*p1;
		sum += ((dot)*(dot))*gaussian(m_h, m_pCloud[i], p2);
	}
	return sum;
} 

template <class Tni>
CCloudPoint CJProjection_2<Tni>::set_mult_normal_vector(double &x)
{		 
	return  CCloudPoint(m_eigenvector[0]*x,m_eigenvector[1]*x);
}

template <class Tni>
double CJProjection_2<Tni>::evaluate_derivative(double x)
{
	double sum = 0;
	CCloudPoint p1, p2, p3;
	double hh = m_h*m_h;
	p3 = get_normal_point();
	for(register unsigned int i = 0; i < m_nCloudPoints ; i++)	
	{				
		p2 = m_ppoint+set_mult_normal_vector(x);
		p1 = m_pCloud[i]-p2; 
	
		double dot = p3*p1;
		sum += (dot)*gaussian(m_h,m_pCloud[i],p2) * (((dot)*(dot))/(hh) - 1.0);
	}
	return 2*sum;
}		   

/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////
	#define GOLD 1.618034
	#define GLIMIT 100.0
	#define TINY 1.0e-20
	#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);
	static double maxarg1,maxarg2;
	#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ?\
        (maxarg1) : (maxarg2))
	#define MOV3(a,b,c,d,e,f) (a)=(d);(b)=(e);(c)=(f);
	#define R 0.61803399
	#define C (1.0-R)
	#define SHFT2(a,b,c) (a)=(b);(b)=(c);
	#define SHFT3(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);

template <class Tni>
double CJProjection_2<Tni>::compute_minima_brents_derivative(double ax,double bx,double cx, double &xmin)
{
	unsigned register int iter;
	bool ok1, ok2;
	double a,b,d = 0,d1,d2,du,dv,dw,dx,e=0.0;
	double fu, fv, fw, fx, olde, tol1, tol2, u = 0, u1, u2, v,w,x,xm;

	a=(ax<cx?ax:cx);
	b=(ax>cx?ax:cx);
	x=w=v=bx;
	fw=fv=fx=evaluate_function(x);
	dw=dv=dx=evaluate_derivative(x);
		
	for(iter=0; iter < ITMAX; iter++){
		xm=0.5*(a+b);
		tol1=tol*fabs(x)+ZEPS;
		tol2=2.0*tol1;
		if(fabs(x-xm) <= (tol2-0.5*(b-a))){
			xmin = x;
			return fx;
		}
		if(fabs(e) > tol1){
			d1=2.0*(b-a);
			d2=d1;
			if (dw != dx) d1=(w-x)*dx/(dx-dw);
			if (dv != dx) d2=(v-x)*dx/(dx-dv);
			u1=x+d1;
			u2=x+d2;
			ok1 =  (a-u1)*(u1-b) > 0.0 && dx*d1 <= 0.0 ;
			ok2 =  (a-u2)*(u2-b) > 0.0 && dx*d2 <= 0.0 ;
			olde=e;
			e=d;
			if(ok1 || ok2){
				if(ok1 && ok2)
					d = (fabs(d1) < fabs(d2)? d1:d2);
				else if (ok1)
					d = d1;
				else
					d = d2;
				if (fabs(d) <= fabs(0.5*olde)){
					u = x + d;
					if(u-a < tol2 || b - u < tol2)
						d = SIGN(tol1,xm-x);
				}
				else{
					d = 0.5*(e=(dx>=0.0? a - x: b-x));
				}	
			}
			else{					
				d = 0.5*(e=(dx>=0.0? a - x: b-x));
			}
		}
		else {
			d = 0.5*(e=(dx>=0.0? a - x: b-x));
		}
		if(fabs(d) >= tol1)
		{
			u = x + d;
			fu = evaluate_function(u);
		}
		else
		{
			u=x+SIGN(tol1,d);
			fu=evaluate_function(u);
			if (fu > fx){
				xmin = x;
				return fx;
			}
		}
		du=evaluate_derivative(u);
		if(fu<=fx){
			if(u >=x) a=x; else b =x;
			MOV3(v,fv,dv,w,fw,dw);
			MOV3(w,fw,dw,x,fx,dx);
			MOV3(x,fx,dx,u,fu,du);
		}
		else
		{
			if(u < x) a = u; else b = u;
				if(fu <=fw || w == x){
					MOV3(v,fv,dv,w,fw,dw);
					MOV3(w,fw,dw,u,fu,du);
				}
			else if (fu < fv || v == x || v == w)
				MOV3(v,fv,dv,u,fu,du);
		}
	}
	std::cerr << "Muitas iteracoes\n";
	return 0.0;
}



#endif // !defined(AFX_JProjection_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)

