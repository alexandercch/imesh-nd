// ColorTable.h: interface for the CColorTable class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COLORTABLE_H__793BD514_D178_4D9D_9CCE_5241141C56A7__INCLUDED_)
#define AFX_COLORTABLE_H__793BD514_D178_4D9D_9CCE_5241141C56A7__INCLUDED_

class CColorTable  : public vector<CGAL::Color>
{
public:
	CColorTable();
	virtual ~CColorTable(){};
	void FillWithBasicColors();
	CGAL::Color RandomColor();
	CGAL::Color NextColor();
private:
	int m_nCount;
};

CColorTable::CColorTable()
{
	m_nCount = 0;
};

CGAL::Color CColorTable::RandomColor()
{
	return (*this)[rand()%size()];	
}

CGAL::Color CColorTable::NextColor()
{
	return (*this)[++m_nCount%size()];	
}

void CColorTable::FillWithBasicColors()
{
	clear();
	push_back(CGAL::Color(255,0,255) );
	push_back(CGAL::Color(128,128,128));
	push_back(CGAL::Color(0,0,255));
	push_back(CGAL::Color(255,0,0));
	push_back(CGAL::Color(128,128,0));
//	push_back(CGAL::Color(255,255,255));
	push_back(CGAL::Color(255,255,0));
	push_back(CGAL::Color(255,128,255));
	push_back(CGAL::Color(255,255,128));
	push_back(CGAL::Color(128,0,0));
	push_back(CGAL::Color(0,255,128));
	push_back(CGAL::Color(255,128,0));
	push_back(CGAL::Color(0,0,128));
	push_back(CGAL::Color(0,128,255));
	push_back(CGAL::Color(0,128,128));
	push_back(CGAL::Color(128,255,0));
	push_back(CGAL::Color(0,255,0));
	push_back(CGAL::Color(0,255,255));
	push_back(CGAL::Color(128,255,255));
	push_back(CGAL::Color(128,0,255));
	push_back(CGAL::Color(128,255,128));
	push_back(CGAL::Color(0,128,0));
//	push_back(CGAL::Color(0,0,0));
	push_back(CGAL::Color(255,128,128));
	push_back(CGAL::Color(255,0,128));
	push_back(CGAL::Color(128,0,128));
	push_back(CGAL::Color(128,128,255));
}

#endif // !defined(AFX_COLORTABLE_H__793BD514_D178_4D9D_9CCE_5241141C56A7__INCLUDED_)
