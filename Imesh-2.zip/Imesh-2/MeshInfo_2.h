// MeshInfo_2.h: interface for the CMGInfo_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MGINFO_2_H__3FE90AD6_B891_43EA_BC7A_6167B10F4D8D__INCLUDED_)
#define AFX_MGINFO_2_H__3FE90AD6_B891_43EA_BC7A_6167B10F4D8D__INCLUDED_

////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "RGBImageElement.h"

template<class _Gt>
struct CVertexInfo_2
{
typedef _Gt Gt;

	CVertexInfo_2()			{	m_nID = m_nIDCount++; m_nWID = -1; 
								m_pVoidPtr = NULL; m_nGray = -1; m_nVertexType = VtNoType; }
	inline int& ID()		{	return m_nID;						}
	inline int& WID()		{	return m_nWID;						}
	inline int& Gray()		{	return m_nGray;						}
	inline void*& VoidPtr()	{	return m_pVoidPtr;					}	
	inline int& VType()		{	return m_nVertexType;				}
private:
	int m_nID;				//id of creation order
	int m_nWID;				//id for writing operations
	void* m_pVoidPtr;		//i.e. to create edge nodes
	int m_nGray;
	int m_nVertexType;
public:
	static int m_nIDCount;
	enum {VtNoType = -1, VtBBoxCorner, VtBBoxSide, VtIn};
};
template<class _Gt>
int CVertexInfo_2<_Gt>::m_nIDCount = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class _Gt>
struct CFaceInfo_2
{
typedef _Gt		Gt;
typedef Gt::FT	FT;	

	enum FType{FNoType, FPeak, FBreakable};
	CFaceInfo_2()
	{	
		m_nType = FNoType;
		m_nRegion = -1; m_fPattern = -1; 
		m_nID = m_nIDCount++; 
		m_pVoidPtr = NULL;
		m_nFlag = -1;
		m_fB = -1;
		//printf("~");
	}
	virtual ~CFaceInfo_2()			{	/*printf("#");*/		}
	/**/inline FType& Type()		{	return m_nType;			}
	inline int& ID()				{	return m_nID;			}
	inline int& Region()			{	return m_nRegion;		}
	inline FT& Pattern()			{	return m_fPattern;		}
	inline CRGBImageElement& RGB()	{	return m_rgb;			}
	inline unsigned long& ScanArea(){	return m_nScanArea;		}
	inline void*& VoidPtr()			{	return m_pVoidPtr;		}
	inline int& Flag()				{	return m_nFlag;			}
	inline FT& B()					{	return m_fB;			}
private:	
	FType m_nType;
	int m_nRegion;
	int m_nID;
	FT m_fPattern;
	unsigned long m_nScanArea;
	void* m_pVoidPtr;
	int m_nFlag;
	FT m_fB; //Circumradius-to-shortest edge ratio is r/d = 1/2sin(min_angle)
	CRGBImageElement m_rgb;
public:
	static long m_nIDCount;
};

template<class _Gt>
long CFaceInfo_2<_Gt>::m_nIDCount = 0;

///////////////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_MGINFO_2_H__3FE90AD6_B891_43EA_BC7A_6167B10F4D8D__INCLUDED_)
