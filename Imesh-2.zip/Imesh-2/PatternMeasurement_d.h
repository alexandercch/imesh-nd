// MGFunctionObjects.h: interface for the CMGFunctionObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MGFUNCTIONOBJECT_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_)
#define AFX_MGFUNCTIONOBJECT_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_

template <class _Image>
class CMedian_d
{
public:
typedef typename _Image::Coord		Coord;
typedef typename _Image::IndexType	IdxT;
	CMedian_d(_Image* m)	{	Reset(); matrix = m;	}
	void Reset()			{	sum = 0; N = 0;			}
	double Result()			{	return sum/(N+0.0);		}
	int ScanArea()			{	return N;				}
	inline void operator()(IdxT x, IdxT y, IdxT z)
	{	N++; sum += (*matrix)(x,y,z);	}
	inline void operator()(Coord c)
	{	N++; sum += (*matrix)(c);	}
private:
	double sum;	
	int N;	
	_Image* matrix;
};

#endif // !defined(AFX_MGFUNCTIONOBJECT_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_)
