// Imesh_2.h: interface for the CImesh_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Imesh_2_H__1B4A51DA_CEF9_42AC_80BD_B7E525BF455F__INCLUDED_)
#define AFX_Imesh_2_H__1B4A51DA_CEF9_42AC_80BD_B7E525BF455F__INCLUDED_

#include "ImeshTraits_2.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template <class Traits = CImeshTraits_2 >
class CImesh_2 
{
public:
#include "ImeshTypes_2.h"

//General-------------------------------------------------------------------------------------------------- 
public:
	CImesh_2();
	virtual ~CImesh_2();
	int Execute();
	void SetImageName(string strFileName);
	void SelectImageFromIndex(string index_file);
	void SetOutDir(string out);
	void SetIO(string io);
	void CreateLedaWindow();
	Image& GetImage();
	Tn& GetTn();
	void Refresh();
	void FRefresh();
	void SRefresh();
	void CalcMeshBinaryError();
	void PutColorsInVertices();	

private:
	void ShowNoBreakableTriangles();
	void ShowTriangles(Cell_list* fl);
	void NewOldCellTest();
	void ShowBadTriangles(bool bErase = true);
	void ShowCircunCircles(list<Edge>* _edges);
	//Sequence of points on border capture
	void CtrlPointsCapture();
	Vertex_list_list Border_strip_points_list;

//Variables
	RGBImage m_RGBImage;
	Image m_Img, m_HeightImage;
	Tn m_Tn;
	Tnd m_Tnd;
	string m_strTmpParams;
	Writer w;
	Window_stream* m_ws;
	//force test comparison 
	int m_nEqual, m_nNoEqual;
	double m_fEqualSumMinAngle, m_fNEqualSumMinAngle;

//Imeshing--------------------------------------------------------------------------------------------------	
private:
	int Imeshing();
	void GenerateInitialMeshPoints(int b = 3);
	void TnMinAngle();
	void PatternsSmoothing();
	ImgCellError m_ice;
	MPatterns m_MPatts;

//Segmentation---------------------------------------------------------------------------------------------- 
private:	
	int	 SegmentMesh();
	void LoadBordersInTnFromBorderDetector();
	void GroupBigEdgesNeighborCells();
	void GroupNeighborRegions();
	void PrintfMeshRegionNeighbors();
	void InitMeshForSegmentation();
	void GroupNeighborCells();
	void GroupNonNeighborRegions();
	void MergeLittleRegions();
	void GroupMoreSimilarRegions();
	void EMMPM();
	void LoadEMMPMArrayFromTn(TEMMPMElem*& elems, int& nelems);
	void UpdateTnFromEMMPMArray(TEMMPMElem*& elems, int& n_elems);
	void TrickyMerges();
	void ShowColorRegions(bool bFixCellsToRegions = true, bool bWait = true);
	void MeshBorderRestriction();
	void HoldMeshes();
	void ShowCellIds();

	int	m_nSegmentationDifference, m_nRegions, m_First_nRegions, m_nSeg_type;
	Mrv m_Mrv;
	Mbd m_Mbd;

//Mesh Simplification----------------------------------------------------------------------------------------
public:
	MLabeling m_MLab;
	MSimplifier m_MSim;

//Quality Mesh ----------------------------------------------------------------------------------------------
private:
	int  QualityMesh();
	void IsolatePeaks();
	void RawRefinement();
	inline Point Circumcenter(Ch ch);
	inline Point Offcenter(Ch ch);
	inline FT MinAngle(Triangle t);	
	inline FT BRatio(Triangle t);
	inline void MinEdge(Triangle& t, FT& me, int &op_v);
	void TryRegBRatioCell(Ch ch);	
	void UnregBRatioCell(Ch ch);
	void LoadBadCells();
	void UpdtBadCells(Vh vh, int nNewCellsLimit);
	void UpdtBadCells(BVBeGroup* pBVBeGroup, int nNewCellsLimit);

	FT m_fMinAngle, m_fB;
	VBeGroup m_VBeGroup;
	PeakGroup m_PeakGroup;
	BRatioCell_pmset m_BRatioCell_pmset;

//Complementary data for meshes -------------------------------------------------------------------------	
	bool LoadHeightImage();
	void RGBMesh();
	bool LoadRGBImage();
	void PutAllRGBInVertices();
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <class Traits>
CImesh_2<Traits>::CImesh_2()
{
	m_Tnd.Init(&m_Tn);
	m_ws = NULL;
	m_nSeg_type = -1;
	m_nSegmentationDifference = m_First_nRegions = m_nRegions =  0;
	m_fMinAngle = 0;
	m_Mbd.Init(&m_Tn, &m_Img, m_ws);
	m_MSim.Init(&m_Tn);	m_MSim.SetDebugUtilObjects(&m_Mrv, &m_VBeGroup, &w);	
	m_MLab.Init(&m_Tn, &m_Mrv, &w);	
	m_MPatts.Init(&m_Tn, &m_Img, &m_RGBImage);
	m_VBeGroup.Init(&m_Tn, &m_Img, &w, m_ws);
	m_Mrv.Init(&m_Tn);
}

template <class Traits>
CImesh_2<Traits>::~CImesh_2()
{	m_Mrv.FreeAll();	}

template <class Traits>
CImesh_2<Traits>::Tn& CImesh_2<Traits>::GetTn()			{	return m_Tn;	} 

template <class Traits>
CImesh_2<Traits>::Image& CImesh_2<Traits>::GetImage()	{	return m_Img;	}

template <class Traits>
void CImesh_2<Traits>::SetImageName(string strImageName){	m_Img.SetImageName(strImageName);	}

template <class Traits>
void CImesh_2<Traits>::SetOutDir(string out) {	w.SetOutDir(out); }

template <class Traits>
void CImesh_2<Traits>::SelectImageFromIndex(string index_file)
{
	string line = CMGUtility::SelectFileFromIndex(index_file);
	SetImageName(line);	
}

template <class Traits>
void CImesh_2<Traits>::SetIO(string io)
{
	string idx = io + "in2\\index.txt";
	string out = io + "out2\\";
	SelectImageFromIndex(idx); 
	SetOutDir(out);
}

template <class Traits>
void CImesh_2<Traits>::CreateLedaWindow()
{
	m_ws = new Window_stream(m_Img.XMax()-1, m_Img.YMax()-1);
	m_ws->init(1,m_Img.XMax(),1);
	m_ws->display();
}

template <class Traits>
Window_stream& operator<<(Window_stream& ws, CImesh_2<Traits>& mesh_gen)
{
	ws.clear();
	//ws<<mesh_gen.GetImage();
	ws.set_fill_color(invisible);
	ws.set_color(color(0,255,0));
	ws.set_line_width(1);
	ws<<mesh_gen.GetTn();
	return ws;
}

template <class Traits>
void CImesh_2<Traits>::Refresh()	{	PutColorsInVertices(); w.Refresh();	}

template <class Traits>
void CImesh_2<Traits>::FRefresh()	{	m_Mrv.FixCellsToRegions(true); Refresh(); 		}

template <class Traits>
void CImesh_2<Traits>::SRefresh()	{	m_VBeGroup.LoadEdgesFromTnInList(); FRefresh();	}

template <class Traits>
void CImesh_2<Traits>::PutColorsInVertices()	
{	
	for ( Tnd::VIt fvi = m_Tn.finite_vertices_begin(); fvi != m_Tn.finite_vertices_end();  ++fvi)
		fvi->info().Gray() = (int)m_Img(PointI(fvi->point().x(), fvi->point().y()));
}

template <class Traits>
int CImesh_2<Traits>::Execute()
{
	m_Img.LoadImage();
	LoadRGBImage(); 
	LoadHeightImage();
	w.Create(&m_Tn, &m_Img, &m_RGBImage, &m_HeightImage, &m_Mrv, m_VBeGroup.List());	
	CreateLedaWindow();

	U_BEGIN(m_Img.ImageName());
	{
		Imeshing();
		TnMinAngle();
		m_MPatts.MakeAllCellPatterns();	
			*m_ws<<*this;
			Refresh();	
		SegmentMesh();
	//	CalcMeshBinaryError();		

		m_VBeGroup.LoadInTnFromSegmentation();
		m_MLab.LoadLabeling();
		m_MSim.InteriorSim();
		m_MLab.UnloadLabeling();
			SRefresh();	
			ShowColorRegions(true, false);
		m_MSim.BorderSim();
		m_VBeGroup.LoadEdgesFromTnInList();		
		m_MLab.UnloadLabeling();
			SRefresh();	
			ShowColorRegions(true, false);

		QualityMesh();

		m_MLab.UnloadLabeling();
		ShowColorRegions(false, false);
		m_MPatts.MakeAllCellPatterns();	
		m_VBeGroup.Clear();

			FRefresh();		
		//CtrlPointsCapture();
		RGBMesh();
	}
	U_END;
	U_WAIT_S(\n\n________end________\n);
	return 1;			
}

template <class Traits>
void CImesh_2<Traits>::CalcMeshBinaryError()
{
	if ( !U_BEGIN_PROC_ASK(CalcMeshBinaryError) )
		return;

	map<int,double> ph, ch; //pixel/cell histogram

	IntTraits::RectangleI_2 r = m_Img.RectI();

	unsigned i, j;
	for ( j = r.ymin() ; j < r.ymax(); j++ )
		for ( i = r.xmin() ; i <= r.xmax(); i++ )
			ph[m_Img(i,j)]++;
	
	Tn::Finite_faces_iterator fi;
	for(fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
		ch[fi->info().Region()] += m_Tn.triangle(fi).area();

	U_COUT("\nPixels\n");
	map<int,double>::iterator hi;
	for ( hi = ph.begin(); hi != ph.end(); ++hi )
		U_COUT(hi->first<<" -> " << hi->second << "\n"); 
	
	U_COUT("\nTriangles\n");	
	for ( hi = ch.begin(); hi != ch.end(); ++hi )
		U_COUT(hi->first<<" -> " << hi->second << "\n"); 
	U_COUT("\n");
	Refresh();		
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///IMESHING//////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class Imeshing{};
template <class Traits>
int CImesh_2<Traits>::Imeshing()
{
	U_BEGIN_PROC_E(Imeshing);

	Ch ch;
	PrePoint xbp;
	Vh vh; 
	Tn::Finite_faces_iterator si;
	int nMeshPoints, last_cell_id, last_vertex_id, count = 0;
	PriorityCellSet pcs;

	m_ice.Init(&m_Img, &m_Tn, m_ws);
	pcs.Init(&m_Tn, &m_ice);
	GenerateInitialMeshPoints(5);	
		*m_ws<<*this;
	m_ice.ReadParams();
	U_TCIN_ASK_DEF("n-MeshPoints: ", nMeshPoints, Mat::MaxInt32());

	U_DEF_TIME(ins); U_DEF_TIME(starfix); U_START_DEF_TIME(im_total);	

	for (si = m_Tn.finite_faces_begin(); si != m_Tn.faces_end(); ++si) 
		pcs.FirstRegCell(si);
	
	while( m_Tn.number_of_vertices() <  nMeshPoints && pcs.PopFront(ch, xbp) )
	{
		if ( m_Tn.is_infinite(ch) )
			continue;
		last_cell_id = CFaceInfo_2<Gt>::m_nIDCount;
		last_vertex_id = CVertexInfo_2<Gt>::m_nIDCount;
		U_TAKE_TIME(ins, vh = m_Tn.insert(m_ice.FinalPoint(xbp), ch));
		if ( CVertexInfo_2<Gt>::m_nIDCount != last_vertex_id )
			pcs.UpdateStar(vh, last_cell_id);
		//status...
		U_IF_COUNTER(count,50,5)
			U_SCOUT("[pts=" << m_Tn.number_of_vertices() << ",s=" << pcs.Size() << "]");
	}
//	pcs.Clear(); 

	U_COUT("\n");
	U_STOP_PRINT_TIME(im_total);	U_PRINT_TIME(ins);	U_PRINT_TIME_E(starfix);
	U_COUT("\n[pts=" << m_Tn.number_of_vertices() << "]\n");

	return 1;
}

template <class Traits>
void CImesh_2<Traits>::GenerateInitialMeshPoints(int n)
{
	unsigned long MinSide, inc, xm, ym, i;
	RectangleI_2 r = m_Img.RectI();
	typedef pair<Point,int> PointT;
	list<PointT > l;

	xm = abs(r.xmax() - r.xmin());
	ym = abs(r.ymax() - r.ymin());
	MinSide = xm < ym ? xm: ym;
	
	l.push_back(PointT( Point(r.xmin(),r.ymin()), VInf::VtBBoxCorner));	
	l.push_back(PointT( Point(r.xmin(),r.ymax()), VInf::VtBBoxCorner));	
	l.push_back(PointT( Point(r.xmax(),r.ymax()), VInf::VtBBoxCorner));	
	l.push_back(PointT( Point(r.xmax(),r.ymin()), VInf::VtBBoxCorner));

	if ( !n )	return;
	inc = MinSide/n;
	assert(inc >= 2);

	for ( i = r.xmin() + inc; i < r.xmax() - inc; i+=inc )
	{	l.push_back(PointT( Point(i,r.ymin()), VInf::VtBBoxSide) );		
		l.push_back(PointT( Point(i,r.ymax()), VInf::VtBBoxSide) );	
	}
	
	for ( i = r.ymin() + inc; i < r.ymax() - inc; i+=inc )
	{	l.push_back(PointT( Point(r.xmin(),i), VInf::VtBBoxSide));		
		l.push_back(PointT( Point(r.xmax(),i), VInf::VtBBoxSide));	
	}
	
	list<PointT >::iterator li;
	Vh vh;
	for ( li = l.begin(); li != l.end(); ++li )
	{	vh = m_Tn.insert(li->first);
		vh->info().VType() = li->second;
	}
}

template <class Traits>
void CImesh_2<Traits>::TnMinAngle()
{
	FT angle, min = 1000;
	Tn::Finite_faces_iterator fi;
	for(fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
	{
		angle = MinAngle(m_Tn.triangle(fi));
		angle = Mat::RadiansToDegrees(angle);
		if ( angle < min )
			min = angle;
	}
	printf("\nMin-Angle:%.5lf\n", min);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///SEGMENTATION//////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <class Traits>
int CImesh_2<Traits>::SegmentMesh()
{
	U_BEGIN_PROC_E(SegmentMesh);

	do
	{
		U_TMP_SS_ON;
		cout<<"\n___________________\n";
		U_COUT((string)(m_Mbd)<<"\n");	
		U_COUT(m_Mrv.HoldRgnString()<<"\n");
		U_TCIN("Seg-type: " , m_nSeg_type);
		if ( m_nSeg_type >= 0 && m_nSeg_type <= 5 )
		{	if ( m_nSeg_type != 5 )
				U_TCIN("Patt-Diff: ", m_nSegmentationDifference);
			U_TCIN("nRegions: ",  m_nRegions);
			InitMeshForSegmentation();
		}
		
		switch(m_nSeg_type)
		{
		default:
			cout<<"-3 -> TrickyMerges\n";
			cout<<"-2 -> HoldMeshes\n";
			cout<<"-1 -> BorderRestriction\n";
			cout<<"0  -> NClG  - NNSmG - LSmG\n";
			cout<<"1  -> NClG  - NSmG\n";
			cout<<"2  -> BEClG - NNSmG - LSmG\n";
			cout<<"3  -> NClG  - NSmG | NNSmG - LSmG\n";
			cout<<"4  -> NClG  - NSmG | MSSmG\n";
			cout<<"5  -> EMMPM\n";
			continue;
		case -3: 
			TrickyMerges();
			ShowColorRegions(true, false); FRefresh();
			break;
		case -2: 
			HoldMeshes();
			continue;
		case -1:
			MeshBorderRestriction();
			break;
		case 0:
			GroupNeighborCells();		 //ShowColorRegions(true, false); FRefresh();
			GroupNonNeighborRegions();	 //ShowColorRegions(true, false); FRefresh();
			MergeLittleRegions();		 //ShowColorRegions(true, false); FRefresh();
			break;
		case 1:
			GroupNeighborCells();		 //ShowColorRegions(true, false); FRefresh();
			GroupNeighborRegions();		 //ShowColorRegions(true, false); FRefresh();
			break;
		case 2:
			GroupBigEdgesNeighborCells();	//ShowColorRegions(true, false); FRefresh();
			GroupNeighborCells();				//ShowColorRegions(true, false); FRefresh();
			GroupNeighborRegions();				//ShowColorRegions(true, false); FRefresh();		
			//MergeLittleRegions();				//ShowColorRegions(true, false); FRefresh();
				break;
		case 3:
			GroupNeighborCells();		
			GroupNeighborRegions();				
				ShowColorRegions(true, false); FRefresh();
			U_TCIN("nRegions: ",  m_nRegions);			
			GroupNonNeighborRegions();		
			MergeLittleRegions();			
			break;
		case 4:
			GroupNeighborCells();				//ShowColorRegions(true, false); FRefresh();
			GroupNeighborRegions();				ShowColorRegions(true, false); FRefresh();
			U_TCIN("nRegions2: ",  m_nRegions);			
			GroupMoreSimilarRegions();			ShowColorRegions(true, false); FRefresh();
			break;
		case 5:
			m_Mrv.ClearHolds();
			EMMPM();
			break;
		}
		FRefresh();
		ShowColorRegions(false, false);

	}while( !U_OK_ASK2("\nseg-ok") );

	m_VBeGroup.Clear();
	U_TMP_SS_OFF;
	return 1;
}

template <class Traits>
void CImesh_2<Traits>::LoadBordersInTnFromBorderDetector()
{
	U_BEGIN_PROC(mesh-restriction);

	m_VBeGroup.Clear();
	Tn::Finite_edges_iterator ei;
	Mbd::EMeshBorder bMeshBorder;
	Ch ch;
	int i;

	m_Mbd.ReadParams();

	for(ei = m_Tn.finite_edges_begin(); ei != m_Tn.finite_edges_end(); ++ei) 
	{
		ch = ei->first;
		i = ei->second;
		bMeshBorder = (m_Mbd)(*ei);
		if ( bMeshBorder == Mbd::be_border )
		{
			VBe edge(ch->vertex((i+1)%3), ch->vertex((i+2)%3));
			edge.Mount();
			m_VBeGroup->push_back(LVBe(edge.v0(), edge.v1()));
		}
	}
}

template <class Traits>
void CImesh_2<Traits>::ShowCellIds()
{
	printf("\n-------------------------------------------------------------------\n");
	Tn::Finite_faces_iterator fi;
	int id, count = 0;
	for(fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
	{
		id = fi->info().Region();
		printf("%d ",  id);
		count += id==14; //m_Mrv.IsRgnHold(id);
	}
	printf("\n----------%d-holded----------------------------------------------\n", count);
}

template <class Traits>
void CImesh_2<Traits>::TrickyMerges()
{
	U_BEGIN_SUB_PROC_T_(TrickyMerges);		
	char op;
	int r1, r2, size;
	printf("\n0-Out | 1-Merge ?");	
	op = _getch();
	switch(op)
	{
	case char('1'):
		cout<<"\nr1:"; cin>>r1;
		cout<<"r2:"; cin>>r2;
		size = m_Mrv.size();
		if ( ( r1 >= size || r2 >= size || r1 < 0 || r2 < 0 )			||	
			 ( !m_Mrv[r1] || !m_Mrv[r2] )		||
			 ( m_Mrv[r1]->Id() == -1 || m_Mrv[r2]->Id() == -1  )
		   )
		{	cout<<" no-valid-rgn(s) "; }
		U_COUT("r1: "<<r1<<" r2: "<<r2<<"\n");
		m_Mrv[r1]->Incorporate(m_Mrv[r2]);
		break;
	}
}

template <class Traits>
void CImesh_2<Traits>::EMMPM()
{
	float fBeta; int nIterations;
	U_TCIN("fBeta: ",  fBeta);				
	U_TCIN("nIterations: ",  nIterations);			

	U_BEGIN_SUB_PROC_T_(EMMPM);

	int i, n_elems;
	TEMMPMElem *elems;
	LoadEMMPMArrayFromTn(elems, n_elems);
//------------------------------------------------------------------------------
	CEMMPM emmpm(elems,n_elems,m_nRegions, 0.0f, fBeta/nIterations, fBeta, 3.0f);

	COtsu otsu(elems, n_elems, 3/*2^3 classes*/,1);
	otsu.run();
	for ( i = 0; i < m_nRegions; i++ )
		emmpm.theta[i].set(otsu.thetas[m_nRegions-2][i].mu,otsu.thetas[m_nRegions-2][i].sigma2);

	printf("\n");
	for (i = 1; i <= nIterations; i++)
	{
		emmpm.MPM_Geometrical_1();
		emmpm.EM_Geometrical();
		emmpm.Annealing();
		cout<<i<<"\r";
		//printf("%d \r", i);
		//fflush(stdout);
	}
	printf("\n");
	emmpm.fileWithTheta("emmpm-test.txt");

//------------------------------------------------------------------------------
	UpdateTnFromEMMPMArray(elems, n_elems);

	U_END_SUB_PROC_T_;
}

template <class Traits>
void CImesh_2<Traits>::LoadEMMPMArrayFromTn(TEMMPMElem*& elems, int& n_elems)
{
	n_elems = m_Tn.number_of_faces();
	elems = new TEMMPMElem[n_elems];
	TEMMPMElem* p;
	int i,j;

	Tn::Finite_faces_iterator fi;
	for(i = 0, fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
		fi->info().ID() = i++;

	list<TEMMPMElem*> neigh_list;
	list<TEMMPMElem*>::iterator nli;
	Ch nj;
	for(i = 0, fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
	{
		p = &elems[i++];
		p->y = fi->info().Pattern();
		p->x = rand()%m_nRegions;
		p->area = fabs(m_Tn.triangle(fi).area());

		neigh_list.clear();
		for ( j = 0; j < 3; j++ )
		{
			nj = fi->neighbor(j);
			if ( !m_Tn.is_infinite(nj) )
				neigh_list.push_back(&elems[nj->info().ID()]);
		}

		p->nn = neigh_list.size();
		p->neighbor = new TEMMPMElem*[p->nn];
		for ( j = 0, nli = neigh_list.begin(); nli != neigh_list.end(); ++nli )
			p->neighbor[j++] = *nli;

		//porcentagem do perimetro que represena cada aresta
		p->neighbor_edge = new float[p->nn];

		//total perimeter
		float fPerimeter = 0;
		for ( j = 0; j < 3; j++ )
		{
			nj = fi->neighbor(j);
			if ( !m_Tn.is_infinite(nj) )
				fPerimeter += ::sqrt ( squared_distance(fi->vertex((j+1)%3)->point(), fi->vertex((j+2)%3)->point()) );
		}

		int kk = 0;
		for ( j = 0; j < 3; j++ )
		{
			nj = fi->neighbor(j);
			if ( !m_Tn.is_infinite(nj) )
				p->neighbor_edge[kk++] = ::sqrt ( squared_distance(fi->vertex((j+1)%3)->point(), fi->vertex((j+2)%3)->point()) )/fPerimeter;
		}
	}	
}

template <class Traits>
void CImesh_2<Traits>::UpdateTnFromEMMPMArray(TEMMPMElem*& elems, int& n_elems)
{
	//Rotulating cells from EMMPM array
	TEMMPMElem* p;	
	int i;
	Tn::Finite_faces_iterator fi;	
	for(i = 0, fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
	{
		p = &elems[i++];	
		fi->info().Region() = p->x;
	}		

	//creating sub-meshes
	CColorTable colors;
	colors.FillWithBasicColors();
	for ( i = 0; i < m_nRegions; i++ )
	{
		MeshRegion* pMr = new MeshRegion;
		pMr->Init(&m_Tn, &m_Mrv, colors.NextColor());
		//m_Mrv.push_back(pMr);
	}
	
	//fixing cells
	m_Mrv.FixCellsToRegions(true);
	
	//deleting EMMPM array
//	for ( i = 0; i < n_elems; i++ )
//		delete elems[i].neighbor;
//	delete elems;
}

template <class Traits>
void CImesh_2<Traits>::GroupMoreSimilarRegions()
{
	U_BEGIN_SUB_PROC_T_(MSSmG);
	
	MinPattDistMeshRegionSet mds;
	Mrv v;
	Mrv::iterator mrvi;

	//loading active sub-meshes
	for ( mrvi = m_Mrv.begin(); mrvi != m_Mrv.end(); ++mrvi )
		if ( m_Mrv.IsActive(*mrvi) )
		//if ( (*mrvi)->Id() != -1 )
			v.push_back(*mrvi); 

	mds.Init((MinPattDistMeshRegionSet::Obj_vector*)(&v));

	//merging
	do
	{
		MeshRegion *sm1, *sm2;		
		mds.GetLessDistPair(sm1, sm2);
			//printf("\n{sm1=%d, sm2=%d}", sm1->Id(), sm2->Id());
		sm1->Incorporate(sm2);
			//printf("\n{sm1=%d, sm2=%d}", sm1->Id(), sm2->Id());
		mds.UpdtLessDistPair();
			//ShowColorRegions(true, false);
			//Refresh();
	}while(	mds.Size() > m_nRegions );
	U_END_SUB_PROC_T_;
}

template <class Traits>
void CImesh_2<Traits>::GroupNeighborRegions()
{
	U_BEGIN_SUB_PROC_T_(NSmG);

	LessIdxDistMeshRegionSet index;
	Mrv::iterator mri;

	//major values
	FT major_area, major_nelmts;//, dist;
	major_area = m_Img.Area();
	major_nelmts = m_Tn.number_of_faces();

	//indexing Area-Elements distances
	for ( mri = m_Mrv.begin(); mri != m_Mrv.end(); ++mri )
	{
		if ( ! m_Mrv.IsActive(*mri) )
			continue;
		(*mri)->MakeIdxDist(major_area, major_nelmts);
		index.insert((MeshRegion*)(*mri));
	}

	//merging regions
	LessIdxDistMeshRegionSet::reverse_iterator mi;
	MeshRegion* lRgn, *closestRgn, *cRgn;
	MeshRegion::NeighborsSet* lNSet;
	MeshRegion::NeighborsSet::iterator ni;
	FT closestRgnPattDist, cDist;

	for ( mi = index.rbegin(); index.size() > m_nRegions; mi = index.rbegin() )
	{
		lRgn = *mi;
		lNSet = &(lRgn->NSet());

		//findin' the first close neighbor
		for ( ni = lNSet->begin(); ni != lNSet->end(); ++ni )
		{
			closestRgn = (MeshRegion*)m_Mrv[*ni];
			if ( !m_Mrv.IsActive(closestRgn) )
				continue;
			closestRgnPattDist = fabs( lRgn->Pattern() - closestRgn->Pattern() );
			break;
		}
		// no closestRgn
		if ( ni == lNSet->end() )
		{	
			index.erase(*mi);	
			continue;
		}
		//findin' the closest neighbor region
		for ( ++ni; ni != lNSet->end(); ++ni )
		{
			cRgn = (MeshRegion*)m_Mrv[*ni];
			if ( !m_Mrv.IsActive(closestRgn) )
				continue;
			cDist = fabs( lRgn->Pattern() - cRgn->Pattern() );
			if ( cDist < closestRgnPattDist )
			{
				closestRgnPattDist = cDist;
				closestRgn = cRgn;
			}
		}
		//merging...
		index.erase(*mi);
		index.erase(closestRgn);
		closestRgn->Incorporate(lRgn);
		closestRgn->MakeIdxDist(major_area, major_nelmts);
		index.insert(closestRgn);
	}

	U_END_SUB_PROC_T_;
}

/*{
	U_BEGIN_SUB_PROC_T_(NSmG);

	LessIdxDistMeshRegionSet index;
	Mrv::iterator mri;

	//major values
	FT major_area, major_nelmts;//, dist;
	major_area = m_Img.Area();
	major_nelmts = m_Tn.number_of_faces();

	//indexing Area-Elements distances
	for ( mri = m_Mrv.begin(); mri != m_Mrv.end(); ++mri )
	{
		if ( ! m_Mrv.IsActive(*mri) )
			continue;
		(*mri)->MakeIdxDist(major_area, major_nelmts);
		index.insert((MeshRegion*)(*mri));
	}

	//merging regions
	LessIdxDistMeshRegionSet::reverse_iterator mi;
	MeshRegion* lRgn, *closestRgn, *cRgn;
	MeshRegion::NeighborsSet* lNSet;
	MeshRegion::NeighborsSet::iterator ni;
	FT closestRgnPattDist, cDist;

	for (mi = index.rbegin() ; index.size() > m_nRegions; mi = index.rbegin() )
	{
		lRgn = *mi;
		lNSet = &(lRgn->NSet());
		//findin' de closest neighbor region
		ni = lNSet->begin();
		closestRgn = m_Mrv[*ni];
		closestRgnPattDist = fabs( lRgn->Pattern() - closestRgn->Pattern() );
		for ( ++ni; ni != lNSet->end(); ++ni )
		{
			cRgn = m_Mrv[*ni];
			cDist = fabs( lRgn->Pattern() - cRgn->Pattern() );
			if ( cDist < closestRgnPattDist )
			{
				closestRgnPattDist = cDist;
				closestRgn = cRgn;
			}
		}
		//merging...
		index.erase(*mi);
		index.erase(closestRgn);
		closestRgn->Incorporate(lRgn);
		closestRgn->MakeIdxDist(major_area, major_nelmts);
		index.insert(closestRgn);
	}

	U_END_SUB_PROC_T_;
}*/

template <class Traits>
void CImesh_2<Traits>::PrintfMeshRegionNeighbors()
{
	Mrv::iterator mri;
	MeshRegion::NeighborsSet* mns;
	MeshRegion::NeighborsSet::iterator ni;
	for ( mri = m_Mrv.begin(); mri != m_Mrv.end(); ++mri )
	{
		int rid = (*mri)->Id();
		if ( rid == -1 )
			continue;
		mns = &((*mri)->NSet());
		printf ("\nmr-%d -> ", rid );
		for ( ni = mns->begin(); ni != mns->end(); ++ni )
			printf ("%d,", *ni);
	}
}

template <class Traits>
void CImesh_2<Traits>::InitMeshForSegmentation()	
{
	m_Mrv.Free();
	Tn::Finite_faces_iterator fi;
	for(fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
	{
		int &id = fi->info().Region();
		if ( !m_Mrv.IsRgnHold(id)	)
			id = -1;
	}
}

template <class Traits>
void CImesh_2<Traits>::GroupBigEdgesNeighborCells()
{
	U_BEGIN_SUB_PROC_T_(BEClG);

	FT dist;
	int i;
	CColorTable colors;
	Ch ch;
	CIt ci;		
	Cell_list rl,cl;
	Point p1,p2;
	MeshRegion* pMr;
	Cell_list::iterator cli;
	FT min_size;
	Edge edgs[Tnd::NCellEdges];
	colors.FillWithBasicColors();

	U_TCIN("MinEdge: ", min_size);
	min_size *= min_size;

	for(ci = m_Tnd.cells_begin(); ci != m_Tnd.cells_end(); ++ci)
	{
		if ( ci->info().Region() != -1 )
			continue;
		pMr = NULL;
		rl.clear();
		rl.push_back(ci);

		while ( !rl.empty() )
		{
			ch = rl.front(); rl.pop_front();
			if ( pMr )
				pMr->Incorporate(ch);
			
			m_Tnd.cell_edges(ch, edgs);
			for ( i = 0; i < Tnd::NCellEdges; i++ )
			{
				m_Tnd.edge_points(edgs[i], p1, p2);
				dist = CGAL::squared_distance(p1,p2);
				if ( dist > min_size )
				{
					m_Tnd.incident_edge_cells(edgs[i], &cl);
					for ( cli = cl.begin(); cli != cl.end(); ++cli )
					{
						if ((*cli)->info().Region() != -1)
							continue;
						if ( !pMr )
						{
							pMr = new MeshRegion;
							pMr ->Init(&m_Tn, &m_Mrv, colors.NextColor());
							pMr->Incorporate(*cli);
						}
						(*cli)->info().Region() = -2;
						rl.push_back(*cli);
					}
				}
			}
		}
		//if ( pMr ) m_Mrv.push_back(pMr);
	}

	U_END_SUB_PROC_N_T_(m_Mrv.size());
}

template <class Traits>
void CImesh_2<Traits>::GroupNeighborCells()
{
	U_BEGIN_SUB_PROC_T_(NClG);
	int count = 0;	
	CColorTable colors;
	colors.FillWithBasicColors();
		*m_ws<<*this;
	Tn::Finite_faces_iterator fi;		
	for(fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
	{
		if ( fi->info().Region() != -1 )
			continue;

		MeshRegion* pMr = new MeshRegion;
		pMr->Init(&m_Tn, &m_Mrv, colors.NextColor());

		list<Ch> rl;
		rl.push_back(fi);
	
		Ch f, ni;
		int i;
		while ( !rl.empty() )
		{
			f = rl.front(); rl.pop_front();
			pMr->Incorporate(f);

			for ( i = 0; i < 3; i++ )
			{
				ni = f->neighbor(i);
				if ( m_Tn.is_infinite(ni) || ni->info().Region() != -1 )
					continue;

				if ( (fabs(ni->info().Pattern() - f->info().Pattern()) <= m_nSegmentationDifference) &&
					 (!VBe(Edge(f,i)).IsBorderElement()) )
				{
					ni->info().Region() = -2;
					rl.push_back(ni);	
				}
			}
		}

		//m_Mrv.push_back(pMr);
		count++;
	}
	U_END_SUB_PROC_N_T_(m_Mrv.size());
}

template <class Traits>
void CImesh_2<Traits>::GroupNonNeighborRegions()
{
	U_BEGIN_SUB_PROC_T_(NNSmG);

	Mrv::iterator mri;
	multimap<FT, MeshRegion*> patt_map;
	multimap<FT, MeshRegion*>::iterator pmi, abs_mr;
	for ( mri = m_Mrv.begin(); mri != m_Mrv.end(); ++mri )
	{
		if ( !m_Mrv.IsActive(*mri) )
			continue;
		patt_map.insert(make_pair((*mri)->Pattern(), (MeshRegion*)*mri));
	}

	int size = patt_map.size();
	if (size < 2)
		return;
	FT diff;
	int n = 1;
	for ( abs_mr = pmi = patt_map.begin(), ++pmi; pmi != patt_map.end(); ++pmi )
	{
		diff = fabs(abs_mr->first - pmi->first);
		if ( diff < m_nSegmentationDifference )
			abs_mr->second->Incorporate(pmi->second);
		else
		{
			abs_mr = pmi;
			n++;
		}
	}

	U_END_SUB_PROC_N_T_(n);	
}

template <class Traits>
void CImesh_2<Traits>::MergeLittleRegions()
{
	U_BEGIN_SUB_PROC_T_(LSmG);

	multimap<FT, MeshRegion*> area_map;
	multimap<FT, MeshRegion*>::iterator ami;
	vector<MeshRegion*> v;

	Mrv::iterator mri;	
	for ( mri = m_Mrv.begin(); mri != m_Mrv.end(); ++mri )
	{
		if ( !m_Mrv.IsActive(*mri) )
			continue;
		area_map.insert(make_pair((*mri)->RealArea(), (MeshRegion*)*mri));
	}

	int size = area_map.size();
	v.resize(size);
	int i = 0;
	for ( ami = area_map.begin(); ami != area_map.end(); ++ami, i++)
		v[size-i-1] = ami->second;

	MeshRegion* pLittle;
	int id_sim, id_lit;
	FT id_dif, dif;
	for (;size > m_nRegions && size > 1; size--)
	{
		id_lit = size-1;
		pLittle = v[id_lit];
		
		//most similar...
		id_sim = size-2;
		id_dif = fabs(v[id_sim]->Pattern() - pLittle->Pattern());
		for ( i = size-2; i >= 0; i-- )
		{
			dif = fabs( v[i]->Pattern() - pLittle->Pattern() );
			if ( dif < id_dif )
			{
				id_sim = i;
				id_dif = dif;
			}
		}

		v[id_sim]->Incorporate(v[id_lit]);
		for ( i = id_sim; i > 0 ; i-- )
			if ( v[i]->RealArea() > v[i-1]->RealArea() )
				swap(v[i], v[i-1]);
	}
	U_END_SUB_PROC_T_;	
}

template <class Traits>
void CImesh_2<Traits>::MeshBorderRestriction()
{
	U_BEGIN_PROC(MeshBorderRestriction);
	printf(" 0-Off | 1-On | 2-test\n");
	int c;
	cout<<"?"; cin>>c;
	switch(c)
	{
	case 0:	m_VBeGroup.Clear();	printf("cleared!\n");		break;
	case 1:	LoadBordersInTnFromBorderDetector();				break;
//	case 2:	m_VBeGroup.TestBorderRestriction(m_ws, &w);		break;
	default: printf("no-action\n");
	}
}

template <class Traits>
void CImesh_2<Traits>::HoldMeshes()
{
	U_BEGIN_PROC(HoldMeshes);
	printf(" 0-Off | 1-AddMeshId | 2-DelMeshId | 3-PrintHoldMeshIds \n");
	int c, id;
	cout<<"?"; cin>>c;
	switch(c)
	{
	case 0:	m_Mrv.ClearHolds(); printf("cleared!\n");			break;
	case 1:	cout<<"AddMeshId: "; cin>>id; m_Mrv.AddRgnHold(id);	break;
	case 2:	cout<<"DelMeshId: "; cin>>id; m_Mrv.DelRgnHold(id);	break;
	default: printf("no-action\n");
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///Quality MESH /////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <class Traits>
int CImesh_2<Traits>::QualityMesh()
{//Ruppert's algorithm adaptation 
	
	U_BEGIN_PROC_E(QualityMesh);

	U_TCIN("MinAngle: ", m_fMinAngle);			
	m_fMinAngle = TniU::DegreesToRadians(m_fMinAngle);
	m_fB = 1/( 2*sin(m_fMinAngle) );
	
	IsolatePeaks();
	m_VBeGroup.RecoverEncroachedEdges();
	RawRefinement();
	m_PeakGroup.SelectAllPeaks();

	return 1;
}

template <class Traits>
void CImesh_2<Traits>::IsolatePeaks()
{//Small angles isolation
	U_BEGIN_SUB_PROC_T_(PeaksIso);

	m_PeakGroup.Create(&m_Tn, TniU::DegreesToRadians(60.0), &w);
	int b = 0, size;
	if ( m_PeakGroup.ComputePeaks() )
		b = m_PeakGroup.IsolatePeaks();
	size = m_PeakGroup.size();
	printf("_%d_%s ", size, !size|b? "ok":"?");

	U_END_SUB_PROC_T_E;
}

template <class Traits>
void CImesh_2<Traits>::RawRefinement()
{
	U_BEGIN_SUB_PROC_T_(RawRefinement);

	BRatioCell_pmset::reverse_iterator ri;
	Ch ch;
	Vh vh;
	Point cc;
	IntTraits::RectangleI_2 _r = m_Img.RectI();
	Gt::Iso_rectangle_2 r(_r.xmin(), _r.ymin(), _r.xmax(), _r.ymax());
	BVBeGroup eg; eg.Create(&m_Tn, &w);
	BVBeGroup::ViolatorPoint vp;
	bool bPeakEdge;
	int nNewCellsLimit, count = 0;
	
	LoadBadCells();
	while ( m_BRatioCell_pmset.size() )
	{
		//status
		U_IF_COUNTER(count,10,10)
			U_SCOUT("[pts=" << m_Tn.number_of_vertices() << ",s=" << m_BRatioCell_pmset.size() << "]");
		
		//stainer point
		ri = m_BRatioCell_pmset.rbegin();
		ch = ***ri;
		assert( !m_Tn.is_infinite(ch) );
		UnregBRatioCell(ch);
		cc = Circumcenter(ch); //Offcenter(ch); 
		
		//outside of the domain
		if ( r.has_on_unbounded_side(cc) )  
		{	printf("?");	continue;		}
		
		//violated border edges
		nNewCellsLimit = CFaceInfo_2<Gt>::m_nIDCount;
		vp = BVBeGroup::ViolatorPoint(cc, ch);
		if ( eg.ComputeViolations(vp, bPeakEdge) )
		{
			if ( bPeakEdge ) 
				continue;
			//printf("-%d-", eg.size());
			eg.CommitBreaks();
			UpdtBadCells(&eg, nNewCellsLimit);
			continue;
		}

		//far-border bad cell circuncenter 
		vh = m_Tn.insert(cc, ch);
		UpdtBadCells(vh, nNewCellsLimit);
	}

	U_END_SUB_PROC_T_E;
}

template <class Traits>
CImesh_2<Traits>::Point CImesh_2<Traits>::Circumcenter(Ch ch)
{	return m_Tn.dual(ch);	}

template <class Traits>
CImesh_2<Traits>::Point CImesh_2<Traits>::Offcenter(Ch ch)
{	
	Point cc = m_Tn.dual(ch);
		//MGU::DrawBigPoint(cc, red, m_ws);
	int op_v; FT me;
	Triangle t = m_Tn.triangle(ch);
	MinEdge(t, me, op_v);
	Point p1(t[(op_v+1)%3]), p2(t[(op_v+2)%3]);
	Triangle met(cc, p1, p2);
	FT metB = BRatio(met);
	if ( metB <= m_fB )
		return cc;
	
	FT	ofr = m_fB*me,
		r = ::sqrt(squared_distance(cc, t[0])); 
	Point midme = Point( (p1.x()+p2.x())/2, (p1.y()+p2.y())/2 );
		//MGU::DrawBigPoint(midme, blue, m_ws);

	FT f = ofr/r;
	Point ofc(	midme.x() + f*(cc.x() - midme.x()), 
				midme.y() + f*(cc.y() - midme.y()) );
		//MGU::DrawBigPoint(ofc, black, m_ws);
	return ofc;	
}

template <class Traits>
CImesh_2<Traits>::FT CImesh_2<Traits>::MinAngle(Triangle t)
{
	FT B = BRatio(t);
	return asin(1/(2*B));
}

template <class Traits>
CImesh_2<Traits>::FT CImesh_2<Traits>::BRatio(Triangle t)
{//Circumradius-to-shortest edge ratio is r/d.
	Point cc = circumcenter(t[0], t[1], t[2]);
	FT cr = ::sqrt(squared_distance(cc, t[0]));
	int op_v; FT me;
	MinEdge(t, me, op_v);
	return cr/me;	
}

template <class Traits>
void CImesh_2<Traits>::MinEdge(Triangle& t, FT& me, int &op_v)
{
	me = squared_distance(t[0], t[1]); op_v = 2;
	FT _me = squared_distance(t[1], t[2]);
	if ( _me < me )		{ me = _me; op_v = 0; }
	_me = squared_distance(t[2], t[0]);
	if ( _me < me )		{ me = _me; op_v = 1; }
	me = ::sqrt(me);
}

template <class Traits>
void CImesh_2<Traits>::LoadBadCells()
{
	Tn::Finite_faces_iterator ffi;
	for(ffi = m_Tn.finite_faces_begin(); ffi != m_Tn.finite_faces_end(); ++ffi)
		TryRegBRatioCell(ffi);
}

template <class Traits>
void CImesh_2<Traits>::TryRegBRatioCell(Ch ch)
{
	FT& fB = ch->info().B() = BRatio(m_Tn.triangle(ch));
	if ( !( fB > m_fB ) )
		return;
	BRatioCell_pmset::iterator msi;
	msi = m_BRatioCell_pmset.insert(new BRatioCell(ch));
	BRatioCell_pmset::iterator* pit = new BRatioCell_pmset::iterator;
	*pit = msi;
	void*& vp = (***msi)->info().VoidPtr();
	assert(vp == NULL);
	vp = (void*)pit;
}

template <class Traits>
void CImesh_2<Traits>::UnregBRatioCell(Ch ch)
{
	void*& vp = ch->info().VoidPtr();
	assert(vp != NULL);
	BRatioCell_pmset::iterator* pit = (BRatioCell_pmset::iterator*)vp;
	BRatioCell* pRc = **pit;
	m_BRatioCell_pmset.erase(*pit);
	delete pRc;
	delete vp;
	vp = NULL; 
}

template <class Traits>
void CImesh_2<Traits>::UpdtBadCells(Vh vh, int nNewCellsLimit)
{//In CGAL Delaunay triangulation no cell is eliminated at this time -- only at the beginning.

	Tn::Face_circulator fc, done;
	done = fc = vh->incident_faces();
	do
	{	
		if ( m_Tn.is_infinite(fc) )
		{
			if ( fc->info().VoidPtr() )
				UnregBRatioCell(fc);
			continue;
		}
		if ( fc->info().ID() >= nNewCellsLimit )		//new faces
		{	
			if ( !fc->info().VoidPtr() )
				TryRegBRatioCell(fc);
		}
		else												//old faces, and no tested faces 
		{
			void*& vp = fc->info().VoidPtr();
			if ( vp )
				UnregBRatioCell(fc);
			TryRegBRatioCell(fc);
		}
	} while(--fc != done);
}

template <class Traits>
void CImesh_2<Traits>::UpdtBadCells(BVBeGroup* eg, int nNewCellsLimit)
{
	BVBeGroup::iterator i;
	BVBe::EPoint_list* elist;
	BVBe::EPoint_list::iterator it;
	int k, size;		
	for ( i = eg->begin(); i != eg->end(); ++i )
	{
		elist = (*i)->EPointsList();
		k=1; size = elist->size()-1;		
		it = elist->begin();
		for ( ++it; k < size; k++, ++it )
			UpdtBadCells(it->vh(), nNewCellsLimit);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///CONTROL SEQUENCE CAPTURE /////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
http://public.kitware.com/pipermail/vtkusers/2005-January/078121.html
scalar/index (a value between 0 and 1) in the default vtk lookup table?
A possibility is to use the luminance.
A common expression is given by
A*(0.299*R + 0.587*G + 0.114*B).
*/

template <class Traits>
void CImesh_2<Traits>::CtrlPointsCapture()
{
	if ( !CMGUtility::OkAsk("CtrlPts Capture") )
		return;

	//enumerating vertices
	int i, k = 0;	
	Tn::Finite_faces_iterator fi;
	for( fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi )	
		for ( i = 0; i < 3; i++ )
			fi->vertex(i)->info().WID() = -1;
	for( fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi )	
		for ( i = 0; i < 3; i++ )
		{
			Vh vh = fi->vertex(i);
			int &id = vh->info().WID();
			if ( id == -1 ) 
				id = k++;
		}

	//capturing
	string fn = CMGUtility::GetFileName(	m_Img.ImageName());

	FT x,y;
	int c; i = 0;
	Vh vh;
	list<int> ids;

	for (;;)
	{
		*m_ws<<*this;		
		printf("-----------------\n");		
		ids.clear();
		for(;;)
		{
			c = m_ws->read_mouse(x,y);
			if ( c == -3 )
				break;
			vh = m_Tn.nearest_vertex(Point(x,y));
			ids.push_back(vh->info().WID()); 
			printf("(%.1lf,%.1lf)\n",x,y);		
			MGU::DrawBigPoint(vh->point(), red, m_ws);				
		}

		char str[255], seq_name[255];
		
		printf("seq_name?");
		scanf("%s", seq_name);

		sprintf(str, "out\\%s%d-%s.ctrl", fn.c_str(), i++, seq_name);
		FILE* pf = fopen(str, "w"); 
			fprintf(pf, "%d\n\n", ids.size());
			list<int>::iterator it;
			for (it = ids.begin(); it != ids.end(); ++it)
				fprintf(pf, "%d\n", *it);			
		fclose(pf);
	}
	*m_ws<<*this;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///COMPLEMENTARY IMAGES////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <class Traits>
bool CImesh_2<Traits>::LoadHeightImage()
{
	if ( m_HeightImage.IsLoaded() )
		return true;
	string img_name = m_Img.ImageName();
	string himg_name = CMGUtility::ReplaceExt(img_name, string(".hgt"));
	m_HeightImage.SetImageName(himg_name);
	m_HeightImage.LoadImage();
	bool b = m_HeightImage.IsLoaded();
	printf("[%sHgtImg]", !b?"No-":"");
	return b;
}

template <class Traits>
void CImesh_2<Traits>::RGBMesh()
{
	U_BEGIN_PROC_E(RGBMesh);
	if ( !LoadRGBImage() )
		return;
	PutAllRGBInVertices();
	m_MPatts.MakeAllRGBCellPattern();
	FRefresh();
}

template <class Traits>
bool CImesh_2<Traits>::LoadRGBImage()
{
	if ( m_RGBImage.IsLoaded() )
		return true;
	string img_name = m_Img.ImageCompleteName();
	string cimg_name = CMGUtility::ReplaceExt(img_name, string(".ppm"));
	m_RGBImage.SetImageName(cimg_name);
	m_RGBImage.LoadImage();
	bool b = m_RGBImage.IsLoaded();
	printf("[%sRGBImg]", !b?"No-":"");
	return b;
}

template <class Traits>
void CImesh_2<Traits>::PutAllRGBInVertices()
{
	RGBImage::ImageElement cie;
	Tnd::VIt vi;
	for ( vi = m_Tn.finite_vertices_begin(); vi != m_Tn.finite_vertices_end();  ++vi )
		cie = m_RGBImage(vi->point().x(), vi->point().y());		
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///OTHER FUNCTIONS ////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <class Traits>
void CImesh_2<Traits>::ShowColorRegions(bool bFixCellsToRegions, bool bWait)
{
	m_ws->clear();
	if ( bFixCellsToRegions ) 
		m_Mrv.FixCellsToRegions(true);
	Tn::Finite_faces_iterator fi;
	int rgn;
	for ( fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi )
	{
		rgn = fi->info().Region();
		if ( rgn < 0 )
			continue;
		CGAL::Color c = m_Mrv[rgn]->Color();
		color ccc(c.red(), c.green(), c.blue());
		m_ws->set_fill_color(ccc);
		*m_ws<<c;
		*m_ws<<m_Tn.triangle(fi);
	}
	
	if (bWait) U_WAIT;
}

template <class Traits>
void CImesh_2<Traits>::ShowNoBreakableTriangles()
{
	(*m_ws).clear();
	(*m_ws)<<GREEN;
	(*m_ws).set_line_width(1);
	(*m_ws)<<m_Tn;
	Tn::Finite_faces_iterator fi;
	for (fi = m_Tn.finite_faces_begin(); fi != m_Tn.faces_end(); ++fi) 
	{
		if ( !fi->info().Breakable() ) 
		{
			m_ws->set_fill_color(color(0, 255, 255));			
			(*m_ws)<<m_Tn.triangle(fi);
		}
	}
}

template <class Traits>
void CImesh_2<Traits>::ShowBadTriangles(bool bErase)
{
	if (bErase) 
	{	
		m_ws->clear();
		m_ws->set_line_width(1);
		*m_ws<<CGAL::GREEN<<m_Tn;
	}

	FT ma;
	int nBads = 0;
	Tn::Finite_faces_iterator fi;		
	m_ws->set_fill_color(color(0, 0, 0));
	for(fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
	{
		ma = MGU::RadiansToDegrees( MGU::GetMinAngle(fi) );
		if ( ma < m_fMinAngle )
		{
			TriangleI_2 t = MGU::TriangleI_2FromFace_2<Gt>(fi);
			*m_ws<<t;
			nBads++;
			fi->info().Breakable() = true;
		}
	}
	printf("nBads=%d\n", nBads);
}

template <class Traits>
void CImesh_2<Traits>::NewOldCellTest()
{
	CMGUtility::BeginSubProc("NewOldCellTest");		
	FT cx, cy;
	int last_id_cell, b;
	Tn::Vh vh;
	Tn::Face_circulator fc, done;
	
	while ( m_ws->read_mouse(cx,cy) != -3 )
	{
		last_id_cell = CFaceInfo::m_nIDCount;
		vh = m_Tn.insert(Point(cx,cy));
		m_ws->clear();
		*m_ws<<CGAL::GREEN<<m_Tn;
				
		done = fc = vh->incident_faces();
		do
		{
			b = fc->info().ID() >= last_id_cell;
			m_ws->set_fill_color(color(b*255, 0, !b*255));						
			*m_ws<<m_Tn.triangle(fc);
		}while(--fc != done);
	}
}

template <class Traits>
void CImesh_2<Traits>::PatternsSmoothing()
{
	if ( !U_BEGIN_PROC_ASK(PatternsSmoothing) )
		return;

	Tn::Finite_faces_iterator ci;
	Ch ni;
	int i, nIterations;
	FT fThreshold;
	
	//initializing nodes...
	for ( ci = m_Tn.finite_faces_begin(); ci != m_Tn.finite_faces_end(); ++ci )
	{
		SmoothPatternNode*& node = SmoothPatternNode::NodeFromCell(ci);	assert(node == NULL);
		node = new SmoothPatternNode(&m_Tn, ci);
	}
	//initializing sums...
	for ( ci = m_Tn.finite_faces_begin(); ci != m_Tn.finite_faces_end(); ++ci )
		SmoothPatternNode::NodeFromCell(ci)->MakeSum();

	if ( U_BEGIN_PROC_ASK(fThreshold-query) )
	{
		do 
		{
			w.UnselectAllCells();
			*m_ws<<*this;
			U_TCIN("Ts: " , fThreshold);		
			for ( ci = m_Tn.finite_faces_begin(); ci != m_Tn.finite_faces_end(); ++ci )
			{
				if ( SmoothPatternNode::NodeFromCell(ci)->m_fact < fThreshold )
				{
					m_ws->set_color(color(0,0,255));
					m_ws->set_line_width(2);
					*m_ws<<m_Tn.triangle(ci);
					w.SelectCell(ci);
				}
			}
			w.Refresh();
		}while( !U_OK_ASK2("ok") );
	}

	do
	{
		U_TCIN("N-Iterations: " , nIterations);		
		U_TCIN("Ts: " , fThreshold);		

		for ( ci = m_Tn.finite_faces_begin(); ci != m_Tn.finite_faces_end(); ++ci )
			SmoothPatternNode::NodeFromCell(ci)->Clear();
		for ( i = 0 ; i < nIterations; i++ )
		{
			for ( ci = m_Tn.finite_faces_begin(); ci != m_Tn.finite_faces_end(); ++ci )
				SmoothPatternNode::NodeFromCell(ci)->SmoothStep1(fThreshold);
			for ( ci = m_Tn.finite_faces_begin(); ci != m_Tn.finite_faces_end(); ++ci )
				SmoothPatternNode::NodeFromCell(ci)->SmoothStep2();
		}
		Refresh();
	}while( ! U_OK_ASK2("ok") );

	//deleting the nodes...
	for ( ci = m_Tn.finite_faces_begin(); ci != m_Tn.finite_faces_end(); ++ci )
	{
		SmoothPatternNode*& node = SmoothPatternNode::NodeFromCell(ci);	assert(node != NULL);
		delete node; node = NULL;
	}
}

#endif // !defined(AFX_Imesh_2_H__1B4A51DA_CEF9_42AC_80BD_B7E525BF455F__INCLUDED_)


/*	m_ws->clear();
	*m_ws<<m_Tn;
	m_ws->set_fill_color(color(0, 0, 0));
	Tn::Finite_faces_iterator fi;
	int kkk = 0;
	for(fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi)
	{
		for ( i = 0; i < 3; i++ )
		{
			if ( fi->vertex(i)->point().x() == 10  && fi->info().Region() == 1 )
			{
				*m_ws<< m_Tn.triangle(fi);
				printf("\n ---------------------------\n %f ", kkk);
				float  a,b,c;
				a = elems[kkk].neighbor_edge[0];
				b = elems[kkk].neighbor_edge[1];
				c = elems[kkk].neighbor_edge[2];
				printf("\n %f %f %f", a,b,c);
				printf("\n %d ", elems[kkk].nn);
			}
		}
		kkk++;
	}
*/

/*{
	m_nEqual = m_nNoEqual = 0;
	m_fNEqualSumMinAngle = m_fEqualSumMinAngle = 0.0;

	U_BEGIN_PROC_E(Imeshing);
	PriorityCellSet pcs;
	m_ice.Init(&m_Img, &m_Tn, m_ws);
	m_ice.TestGradient();

	GenerateInitialMeshPoints(5);
	*m_ws<<*this;
	m_ice.ReadParams();
		
	Cell_list sl;
	Ch sh;
	Point bp;
	Vh vh; 
	bool b;
	Tn::Finite_faces_iterator si;
	int last_face_id, count = 0;
	int ani_count = 0;
	FT error;

	U_DEF_TIME(error);	U_DEF_TIME(ins);	U_DEF_TIME(starfix);
	U_START_DEF_TIME(im);	

	for (si = m_Tn.finite_faces_begin(); si != m_Tn.faces_end(); ++si) 
	{	si->info().Flag() = 0;	sl.push_back(si);	
		pcs.FirstRegCell(si);
	}

	while( !sl.empty() )
	{
		sh = sl.front(); sl.pop_front();
		sh->info().Flag() = 1;
		if ( m_Tn.is_infinite(sh) )
			continue;
		
		U_TAKE_TIME(error, b = m_ice(sh, bp, error) );		
		if ( b )
		{
			last_face_id = CFaceInfo<Gt>::m_nIDCount;
			U_TAKE_TIME(ins, vh = m_Tn.insert(bp, sh));
			U_TAKE_TIME(starfix, UpdateListWithNewElements(vh, &sl, last_face_id) );
		}
		//status...
		U_IF_COUNTER(count,100,10)
		{
			U_SCOUT("[pts=" << m_Tn.number_of_vertices() << ",s=" << sl.size() << "]");
		}
	}

	U_COUT("\n");
	U_STOP_PRINT_TIME(im);	U_PRINT_TIME(error);	U_PRINT_TIME(ins);	U_PRINT_TIME_E(starfix);
//	int nTotal  = m_nEqual + m_nNoEqual; 
//	U_COUT("[FN-Equal:"   << m_nEqual	<<" "<<m_nEqual/(float)nTotal<<"%"	 <<" "<< m_fEqualSumMinAngle/(float)m_nEqual<<"]");
//	U_COUT("\n[FN-NOEqual:" << m_nNoEqual <<" "<<m_nNoEqual/(float)nTotal<<"%" <<" "<< m_fNEqualSumMinAngle/(float)m_nNoEqual<<"]");
	U_COUT("\n[pts=" << m_Tn.number_of_vertices() << "]\n");

	return 1;
}*/

/*		*m_ws<<*this;
		m_ws->set_color(color(0,0,255));		
		*m_ws<<m_Tn.triangle(ch);
		Ut::DrawBigPoint(bp, red, m_ws);
		int side = m_Tn.triangle(ch).bounded_side(bp);
		printf("side = %d\n", side);
*/


/*template <class Traits>
void CImesh_2<Traits>::FixCellsToRegions(bool bMakeCellRgnCList) 
{
	U_BEGIN_SUB_PROC(f);
	int mrl_size = m_Mrv.size();
	vector<MeshRegion* > table(mrl_size);

	Mrv::iterator pli;
	MeshRegion::IdList* pIList;
	MeshRegion::IdList::iterator ii;
		
	CColorTable colors;
	colors.FillWithBasicColors();
//ShowCellIds();
	for ( pli = m_Mrv.begin(); pli != m_Mrv.end(); ++pli )
	{
		if ( *pli == NULL )
			continue;
		(*pli)->CList().clear();
		if ( (*pli)->Id() == -1 )
			continue;

		(*pli)->Color() = colors.NextColor();
		pIList = &((*pli)->IList());
		for ( ii = pIList->begin(); ii != pIList->end(); ++ii)
			table[*ii] = (MeshRegion*)*pli;
	}

	// Fixing Cell regions values
	// Making regions simplices list
//	if ( bMakeCellRgnCList )
	{
		Tn::Finite_faces_iterator fi;
		for (fi = m_Tn.finite_faces_begin(); fi != m_Tn.faces_end(); ++fi) 
		{ 
			int id_rgn = fi->info().Region();
			if ( !( id_rgn >= 0 && id_rgn < mrl_size ) )
				continue;
			table[id_rgn]->Store(fi);
		}
	}
	
	for ( pli = m_Mrv.begin(); pli != m_Mrv.end(); ++pli )
	{
		if ( *pli == NULL )
			continue;
		(*pli)->IncorporateCells();
	}

//ShowCellIds();
	U_END_SUB_PROC;	
}*/



