// ImeshTraits_2.h: interface for the CRefinementMethodTraits1 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MeshGeneratorTwoTraits21_H__3D4DDFA5_F28A_4890_81FC_A7EECB6CA4F2__INCLUDED_)
#define AFX_MeshGeneratorTwoTraits21_H__3D4DDFA5_F28A_4890_81FC_A7EECB6CA4F2__INCLUDED_

#include <iostream>
#include <sstream>

#include <set>
#include <conio.h>

#include "Tnd_2.h"
#include "MGUtility.h"
#include "MGIntTraits.h"
#include "Image_2.h"
#include "PGMAsciiImageReader_2.h"
#include "PPMAsciiImageReader_2.h"
#include "GrayImageElement.h"
#include "RGBImageElement.h"

#include "LineScan.h"
#include "MeshRegion_d.h"
#include "TniU_2.h"
#include "ForceMaxPointSelector.h"
#include "SpatialGradientMask.h"
#include "SmoothPatternNode_d.h"
#include "MinDistancesSet.h"
#include "VBeGroup_2.h"
#include "BVBe_2.h"
#include "Peak_2.h"
#include "BRatioCell_2.h"
#include "ColorTable.h"
#include "Writer_2.h"
#include "EMMPM/emmpm.h"

#include "ImgCellErrorTraits_2.h"
#include "ImgCellError_2.h"
#include "TnCellList_2.h"
#include "TnCellMultimap_2.h"
#include "TniTraits_2.h"
#include "PatternIsoBorder_d.h"
#include "TraverserIsoBorder_2.h"
#include "MeshSimplifier_2.h"
#include "MeshPatterns_2.h"
#include "MeshLabeling_d.h"

///////////////////////////////////////////////////////////////////////////////////////////

class CImeshTraits_2
{
public:
//Triangulation------------------------------------------------------------------------------------------

	typedef CTnd_2		Tnd;
	typedef Tnd::Tn		Tn;
	typedef Tnd::Gt		Gt;
	typedef Tnd::FT		FT;
	
//Image--------------------------------------------------------------------------------------------------	
	typedef CMGIntTraits												IntTraits;	
	typedef CGrayImageElement											GrayImageElement;
	typedef CPGMAsciiImageReader_2<GrayImageElement,IntTraits>			PGMImageReader;
	typedef CImage_2<PGMImageReader>									Image;
	typedef CSobel33<Image>												GradientMask;
//	typedef CMaxPointSelector<Image, GradientMask>						TriangleInPointSelector;
//	typedef CForceMaxPointSelector<Tn,Image,GradientMask>				ForceTriangleInPointSelector;
	typedef IntTraits::PointI_2											PointI;
	typedef CRGBImageElement											RGBImageElement;
	typedef CPPMAsciiImageReader_2<RGBImageElement,IntTraits>			PPMImageReader;
	typedef CImage_2<PPMImageReader>									RGBImage;

//-------------------------------------------------------------------------------------------		
	typedef CTniTraits_2<Tnd,Image,RGBImage>							_Tni;
		struct Tni : public _Tni{};
	typedef CWriter_2<Tni>												Writer;
//Imeshing-------------------------------------------------------------------------------------------		
	typedef CImgCellErrorTraits_2<Tni>									ImgCellErrorTraits;
	typedef CImgCellError_2<ImgCellErrorTraits>							ImgCellError;
//	typedef CTnCellList_2<Tn,ImgCellError>								PriorityCellSet;
	typedef CTnCellMultimap_2<Tni,ImgCellError>							PriorityCellSet;
	typedef CMeshPatterns_2<Tni>										MPatterns;

//Segmentation-------------------------------------------------------------------------------------------		
//	typedef CPatternIsoBorder_d<Tni>									Mbd;
	typedef CTraverserIsoBorder_2<Tni>									Mbd;
	typedef CMeshRegion_d<Tni>											MeshRegion;
	typedef MeshRegion::MeshRegionVector								Mrv;
	typedef set<MeshRegion*, MeshRegion::PLessCPtr>						LessIdxDistMeshRegionSet;
	typedef CMinDistancesSet<MeshRegion>								MinPattDistMeshRegionSet;

//Simplification---------------------------------------------------------------------------------------------
	typedef CVBeGroup_2<Tni>											VBeGroup;
	typedef CMeshSimplifier_2<VBeGroup>									MSimplifier;
	typedef CMeshLabeling_d<Tni>										MLabeling;

//Refinement---------------------------------------------------------------------------------------------

	typedef CBVBeGroup_2<Tni>											BVBeGroup;
	typedef CPeakGroup_2<Tni>											PeakGroup;
	typedef CVertexEdgeNode_2<Tn>										VertexEdgeNode;
	typedef CVBe_2<Tn>													VBe;
	typedef CBVBe_2<Tni>												BVBe;
	typedef CPeak_2<Tni>												Peak;
	typedef list<VBe>													VBe_list;
	typedef CBRatioCell_2<Tn>											BRatioCell;
	typedef multiset<BRatioCell*, BRatioCell::LessPtrCmp>				BRatioCell_pmset;

//Others-------------------------------------------------------------------------------------------------	
	typedef CSmoothPatternNode_d<Tni>									SmoothPatternNode;
};

///////////////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_MeshGeneratorTwoTraits21_H__3D4DDFA5_F28A_4890_81FC_A7EECB6CA4F2__INCLUDED_)



