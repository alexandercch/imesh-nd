/**
  cemmpm.cpp
  EM/MPM "element" segmentation class implementation
  nov/2005
**/



#include <math.h>
#include "cemmpm.h"



/**  ========== CEMMPM Methods ==========
     ====================================
**/

/** run - iterates once
**/
void CEMMPM::run()
{
  int s, k, y, g;
  
  // initialize P_Xs|Y_(k|y,theta)
  for (s=0; s<N; s++)
    for (k=0; k<L; k++)
      element[s].time[k] = 0;
  
  // initializa cpmf_arr
  for (k=0; k<L; k++)
    for (y=0; y<GRAYLEVELS; y++)
      for (g=0; g<MAXNEIGHBORS; g++)
        cpmf_arr[k][y][g] = -1.;
  
  // calcule X and P_Xs|Y_(k|y,theta)
  MPM();
  
  // estime theta by P_Xs|Y_(k|y,theta)
  EM();
}


/** MPM - Maximization of the Posterior Marginal: segment the elements
**/
void CEMMPM::MPM()
{
  int s, t, k, g, y, nn;
  float z, acpmf, random, *aux;
  CEMMPMElem *current, **neighbor;
  CLabelParameters *label;

  for (t=0; t<T; t++){ // visit each element once
    for (s=0; s<N; s++){ // visit one element
      // get element properties
      current = &element[s];
      y = current->y;
      neighbor = current->neighbor;
      nn = current->nn;
      
      // count different neighbors number if k=0..L-1 (dnn)
      for (k=0; k<L; k++) dnn[k] = nn;
      for (g = 0; g<nn; g++)
        dnn[neighbor[g]->x]--;
      
      // calculate the cpmf (condicional probability mass function)
      // that indicates the probability of the current element be the
      // label k giving y and theta, with k=0..L-1
      // P_Xs|Y,Xg,g=neighborsOfS,theta_(k|y,xg,theta)
      // z is the normalization factor
      for (z=0, k=0; k<L; k++){
        aux = cpmf_arr[k][y] + dnn[k];
        if (*aux<0){
          label = theta + k;
          *aux = label->term1 * exp (label->term2[y] - beta*dnn[k]);
        }
        z += cpmf[k] = *aux;
      }
      
      // generates the new label k for the current element randomicaly
      // with the mcpf just calculated by examining the accumulated mcpf
      k=0;
      acpmf = cpmf[0];
      random = RANDOM*z;
      while (random>acpmf)
        acpmf += cpmf[++k];
      
      current->x = k;
      current->time[k]++;
    }
  }
}


/** EM - Expectation Maximization: estime label parameters
**/
void CEMMPM::EM()
{
  int k, s;
  float mu, sigma2, aux1, aux2, aux3;
  CEMMPMElem *current;
  
  for (k=0; k<L; k++){
    // mean calculation (mu)
    aux2 = 0;
    aux3 = 0;
    for (s=0; s<N; s++){
      current = &element[s];
      aux1 = current->time[k];
      aux2 += current->y*aux1;
      aux3 += aux1;
    }
    mu = aux2/aux3;
    
    // variance calcutation (sigma2)
    aux2 = 0;
    aux3 = 0;
    for (s=0; s<N; s++){
      current = &element[s];
      aux1 = current->time[k];
      aux2 += pow(current->y-mu,2)*aux1;
      aux3 += aux1;
    }
    sigma2 = aux2/aux3;
    if (sigma2<=0.)
      theta[k].sigma2 = 0.1;
    
     theta[k].set(mu,sigma2);
  }
}


/** CEMMPM - contructor
  @param CEMMPMElem *elem_: array of elements
  @param int    N_   : number of elements
  @param int    L_   : number of labels
  @param float  beta_: spacial interaction parameter
**/
CEMMPM::CEMMPM(CEMMPMElem * elem_, int N_, int L_, float beta_)
{
  int s, k, y, nn;

  // set variables and parameters
  element = elem_;
  N = N_;
  L = L_;
  beta = beta_;
  
  T = 3; // it's enough
  
  // allocation
  theta = new CLabelParameters[L];
  dnn = new int[L];
  cpmf = new float[L];
  for (s=0; s<N; s++)
    element[s].time = new int[L];
  
  cpmf_arr = new float**[L];
  for (k=0; k<L; k++){
    cpmf_arr[k] = new float*[GRAYLEVELS];
    for (y=0; y<GRAYLEVELS; y++)
      cpmf_arr[k][y] = new float[MAXNEIGHBORS];
  }
  
  
  // initialize theta
  for (k=0; k<L; k++)
    theta[k].set((255.*k)/(float)L + 128./(float)L, SIGMA2);
}



/**  ========== CLabelParameters Methods ==========
     ==============================================
**/

/** CLabelParameters - constructor
  @param float mu_    : mean
  @param float sigma2_: variance
**/
CLabelParameters::CLabelParameters (float mu_, float sigma2_)
{
  set (mu_, sigma2_);
}


/** set - set parameters
	@param float mu_    : mean
	@param float sigma2_: variance
**/
void CLabelParameters::set(float mu_, float sigma2_)
{
  int y;
  float aux;
  
  // parameters
  mu = mu_;
  sigma2 = sigma2_;
  
  // auxiliar variables
  term1 = 1/sqrt(TWOPI*sigma2);
  aux = 2*sigma2;
  for (y=0; y<256; y++)
    term2[y] = -pow (y-mu,2)/aux;
}



/**  ========== CElements Methods ==========
     =======================================
**/

/** CElements - constructor by image
  @param unsigned_char *img: array of pixels
  @param int            w  : width  of the image in pixels
  @param int            h  : heigth of the image in pixels
  @param int            g  : neighborhood (4 or 8)
  @param int            L  : number of labels
  @param int            min: minimum gray level
  @param int            max: maximum gray level
**/
CElements::CElements
  (unsigned char *img, int w, int h, int g, int L, int min, int max)
{
  int s, i, j, u, gs, gcalc[8];
  CEMMPMElem *neighbor[8];
  
  // set variables
  img_N = w*h;
  
  // alocation
  img_labels = new unsigned char[img_N];
  img_elem   = new           int[img_N];
  
  // select pixels betimg_ween min and max
  for (i=0, s=0; s<img_N; s++)
    if (img[s]>=min && img[s]<=max)
      img_elem[s] = i++;
    else
      img_elem[s] = img_N;
  N = i;
  
  // allocation
  element  = new CEMMPMElem[N];
  elem_img = new   int[N];
  
  // set element gray levels and initialize labels values;
  for (s=0; s<img_N; s++){
    i = img_elem[s];
    img_labels[s] = L;
    if (i<img_N){
      elem_img[i] = s;
      element[i].y = img[s];
      element[i].x = RANDOM*L;
    }
  }
  
  // set neighborhood
  /************************************************************************/
  /**/ gcalc[7] = -1 - w; /**/ gcalc[3] = 0 - w; /**/ gcalc[5] = 1 - w; /**/
  /************************************************************************/
  /**/ gcalc[1] = -1 + 0;  /************************/ gcalc[0] = 1 + 0; /**/
  /************************************************************************/
  /**/ gcalc[6] = -1 + w; /**/ gcalc[2] = 0 + w; /**/ gcalc[4] = 1 + w; /**/
  /************************************************************************/
  for (i=0; i<N; i++){
    j = 0;
    s = elem_img[i];
    for (u=0; u<g; u++){
      gs = s+gcalc[u];
      if ((gs<img_N && gs>=0) && gs%w)
        neighbor[j++] = element+img_elem[gs];
      else
        neighbor[j++] = element+i;
    }
    element[i].neighbor = new CEMMPMElem *[j];
    element[i].nn = j;
    for (u=0; u<j; u++)
      element[i].neighbor[u] = neighbor[u];
    }
}


/** getLabels - get pixels label
**/
unsigned char *CElements::getLabels()
{
  int i;
  
  for (i=0; i<N; i++)
    img_labels[elem_img[i]] = element[i].x;
  
  return img_labels;
}
