// Tnd_2.h: interface for the CTnd_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Tnd_2_H__700EA2EE_26FB_4960_A6F4_8A440C863021__INCLUDED_)
#define AFX_Tnd_2_H__700EA2EE_26FB_4960_A6F4_8A440C863021__INCLUDED_

#include "Delaunay_Triangulation_Imesh_2.h"
#include <CGAL/IO/Window_stream.h>
#include "VBe_2.h"

using namespace std;

class CTnd_2  
{
public:
	typedef CDelaunay_triangulation_Imesh_2		DtImesh_2;
	typedef DtImesh_2::Tn						Tn;
	typedef DtImesh_2::Gt						Gt;
	typedef DtImesh_2::CInf						CInf;
	typedef DtImesh_2::VInf						VInf;
	typedef DtImesh_2::CK						CK;
	typedef DtImesh_2::FT						FT;
												
	typedef Tn::Triangle						Triangle;
	typedef Tn::Segment							Segment;
	typedef Tn::Point							Point;
	typedef Tn::Edge							Be;
	typedef Tn::Edge							Edge;
	typedef CVBe_2<Tn>							VBe;
												
	typedef Tn::Vertex_handle					Vh;
	typedef Tn::Face_handle						Ch;
	typedef Tn::Finite_vertices_iterator		VIt;
	typedef Tn::Finite_faces_iterator			CIt;
												
	typedef vector<Ch>							Cell_vector;
	typedef list<Point>							Point_list;
	typedef list<Segment>						Segment_list;
	typedef list<Ch>							Cell_list;
	typedef list<Vh>							Vertex_list;
	typedef list<Vertex_list>					Vertex_list_list;

//---------------------------------------------------------------------------------------------------------

public:		
	CTnd_2(Tn* pTn = NULL)			{	m_pTn = pTn;							}
	void Init(Tn* pTn)				{	m_pTn = pTn;							}
	inline Tn*& operator->()		{	return m_pTn;							}			
	inline FT Aread(Ch ch)			{	return m_pTn->triangle(ch).area();		}
	inline int number_of_cells()	{	return m_pTn->number_of_faces();		}
	inline CIt cells_begin()		{	return m_pTn->finite_faces_begin();		}
	inline CIt cells_end()			{	return m_pTn->faces_end();				}
	inline VIt vertices_begin()		{	return m_pTn->finite_vertices_begin();	}
	inline VIt vertices_end()		{	return m_pTn->finite_vertices_end();	}

	inline Point Centroid(Ch ch)
	{	return CGAL::centroid(	ch->vertex(0)->point(), 
								ch->vertex(1)->point(), ch->vertex(2)->point() );	}

	inline void incident_cells(Vh vh, Cell_vector* cv)
	{	cv->clear();
		Tn::Face_circulator fc, done;
		done = fc = m_pTn->incident_faces(vh);
		do 	{	cv->push_back(fc);	} while(--fc != done);
	}

	inline void cell_edges(Ch ch, Edge* eds)
	{	eds[0] = Edge(ch,0); eds[1] = Edge(ch,1); eds[2] = Edge(ch,1);	}

	inline void edge_points(Edge e, Point& p1, Point& p2)
	{	p1 = e.first->vertex( (e.second+1)%3 )->point();
		p2 = e.first->vertex( (e.second+2)%3 )->point();
	}

	inline void incident_edge_cells(Edge e, Cell_list* cl)
	{	cl->clear();
		if ( !m_pTn->is_infinite(e.first) ) cl->push_back(e.first);
		Ch op = e.first->neighbor(e.second);
		if ( !m_pTn->is_infinite(op) )		cl->push_back(op);
	}

	inline void incident_vertices(Vh vh, Vertex_list* vl)
	{	vl->clear();
		Tn::Vertex_circulator vc, vcdone;
		vcdone = vc = m_pTn->incident_vertices(vh);
		do { vl->push_back(vc); } while(--vc != vcdone);
	}

public:
	static const int Dim, NCellSides, NCellEdges, NStep, InfNStep;
private:
	Tn* m_pTn;
};

const int CTnd_2::Dim = 2;
const int CTnd_2::NCellSides = 3;
const int CTnd_2::NCellEdges = 3;
const int CTnd_2::NStep = 50;
const int CTnd_2::InfNStep = 5;

#endif // !defined(AFX_Tnd_2_H__700EA2EE_26FB_4960_A6F4_8A440C863021__INCLUDED_)
