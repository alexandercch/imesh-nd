// MeshRgnVector_d.h: interface for the CMeshRgnVector_d class.
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MeshRgnVector_d_H__94A0255D_C28F_4C5E_90DB_E806C029617B__INCLUDED_)
#define AFX_MeshRgnVector_d_H__94A0255D_C28F_4C5E_90DB_E806C029617B__INCLUDED_

#include "UMacros_d.h"

template <class Tni, class MRgnPtr>
class CMeshRgnVector_d : public vector<MRgnPtr>
{
public:
typedef typename list<int>  HoldRgnIdList;
typedef typename Tni::Ch	Ch;
typedef typename Tni::Tn	Tn;
typedef typename list<int>	IdList;
typedef typename Tni::Tnd	Tnd;
public:
	CMeshRgnVector_d();
	~CMeshRgnVector_d();
	void Init(Tn* pTn);
	void FixCellsToRegions(bool bMakeCellRgnCList = false);	
	inline bool IsRgnHold(MRgnPtr rgn);
	inline bool IsRgnHold(int i);
	inline void AddRgnHold(int i);
	inline void DelRgnHold(int i);
	inline void PrintHoldIds();
	inline bool IsActive(MRgnPtr pMr);
	inline bool IsRgnFree(Ch ch);
	void ClearHolds();
	int NewId();
	void Free();
	void FreeAll();
	inline string HoldRgnString();
	void PrintRgns();
private:
	HoldRgnIdList m_HoldRgnIdList;
	int m_nRgnNewPos;
	Tn* m_pTn;
	Tnd m_Tnd;
};

template <class Tni, class MRgnPtr>
CMeshRgnVector_d<Tni, MRgnPtr>::CMeshRgnVector_d()
{ m_pTn = NULL; m_nRgnNewPos = -1; }

template <class Tni, class MRgnPtr>
CMeshRgnVector_d<Tni, MRgnPtr>::~CMeshRgnVector_d()
{ 	}

template <class Tni, class MRgnPtr>
void CMeshRgnVector_d<Tni, MRgnPtr>::Init(Tn* pTn)
{	m_pTn = pTn; 
	m_Tnd.Init(pTn);
}

template <class Tni, class MRgnPtr>
void CMeshRgnVector_d<Tni, MRgnPtr>::ClearHolds()
{	m_HoldRgnIdList.clear();	}

template <class Tni, class MRgnPtr>
inline void CMeshRgnVector_d<Tni, MRgnPtr>::AddRgnHold(int i)
{	m_HoldRgnIdList.push_back(i);	}

template <class Tni, class MRgnPtr>
inline void CMeshRgnVector_d<Tni, MRgnPtr>::DelRgnHold(int i)
{	
	HoldRgnIdList::iterator it;
	for ( it = m_HoldRgnIdList.begin(); it != m_HoldRgnIdList.end(); ++it )
		if ( *it == i )
		{	m_HoldRgnIdList.erase(it); break; }
}

template <class Tni, class MRgnPtr>
string CMeshRgnVector_d<Tni, MRgnPtr>::HoldRgnString()
{	
	string s = "HoldIds: ";	char str[255];
	if ( !m_HoldRgnIdList.size() )
		s += "Off";
	HoldRgnIdList::iterator it;
	for ( it = m_HoldRgnIdList.begin(); it != m_HoldRgnIdList.end(); ++it )
	{
		sprintf(str, "%d ", *it);
		s += str;
	}
	return s;
}

template <class Tni, class MRgnPtr>
inline void CMeshRgnVector_d<Tni, MRgnPtr>::PrintHoldIds()
{	printf("%s", HoldRgnString().c_str() );	}

template <class Tni, class MRgnPtr>
inline bool CMeshRgnVector_d<Tni, MRgnPtr>::IsRgnFree(Ch ch)
{
	int rgn_id = ch->info().Region();
	return ( rgn_id == -1 || !IsRgnHold(rgn_id) );
}

template <class Tni, class MRgnPtr>
inline bool CMeshRgnVector_d<Tni, MRgnPtr>::IsRgnHold(MRgnPtr rgn)
{	return IsRgnHold(rgn->Id());	}

template <class Tni, class MRgnPtr>
inline bool CMeshRgnVector_d<Tni, MRgnPtr>::IsRgnHold(int id)
{
	for ( HoldRgnIdList::iterator i = m_HoldRgnIdList.begin(); i != m_HoldRgnIdList.end(); ++i )
		if ( *i == id )
			return true;
	return false;
}

template <class Tni, class MRgnPtr>
inline bool CMeshRgnVector_d<Tni, MRgnPtr>::IsActive(MRgnPtr pMr)
{	return !( !pMr || pMr->Id() == -1 || IsRgnHold( pMr->Id() ) );	}

template <class Tni, class MRgnPtr>
int CMeshRgnVector_d<Tni, MRgnPtr>::NewId()
{
	int next;
	for( next = m_nRgnNewPos+1; IsRgnHold(next); next++ );
	if ( next >= size() )
		push_back(NULL);
	return m_nRgnNewPos = next;
}

template <class Tni, class MRgnPtr>
void CMeshRgnVector_d<Tni, MRgnPtr>::Free()
{
	m_nRgnNewPos = -1;	
	int i, bHold = 0;
	for ( i = 0; i < size(); ++i )
	{
		if ( !IsRgnHold(i) )
		{
			MRgnPtr& pRgn = (*this)[i];
			delete pRgn;
			pRgn = NULL;
		}
		else bHold = 1;
	}
	if ( !bHold )
		clear();
}

template <class Tni, class MRgnPtr>
void CMeshRgnVector_d<Tni, MRgnPtr>::FreeAll()
{
	for ( iterator mi = begin(); mi != end(); ++mi )
		delete *mi;
	clear();
}

template <class Tni, class MRgnPtr>
void CMeshRgnVector_d<Tni, MRgnPtr>::FixCellsToRegions(bool bMakeCellRgnCList) 
{
	U_BEGIN_SUB_PROC(f);
	int mrl_size = size();
	vector<MRgnPtr> table(mrl_size);

	iterator pli;
	IdList* pIList;
	IdList::iterator ii;
	MRgnPtr pRgn;
	CColorTable colors;
	colors.FillWithBasicColors();
//ShowCellIds();

	for ( pli = begin(); pli != end(); ++pli )
	{
		pRgn = *pli;
		if ( pRgn == NULL )
			continue;
		pRgn->CList().clear();
		if ( pRgn->Id() == -1 )
			continue;

		pRgn->Color() = colors.NextColor();
		pIList = &(pRgn->IList());
		for ( ii = pIList->begin(); ii != pIList->end(); ++ii)
			table[*ii] = pRgn;
	}

	// Fixing Cell regions values
/*	Tn::Finite_faces_iterator fi;
	for (fi = m_pTn->finite_faces_begin(); fi != m_pTn->faces_end(); ++fi) 
	{ 
		int id_rgn = fi->info().Region();
		if ( !( id_rgn >= 0 && id_rgn < mrl_size ) )
			continue;
		fi->info().Region() = table[id_rgn]->Id();
	}
*/
	// Making regions simplices list
//	if ( bMakeCellRgnCList )
	{
		Tnd::CIt ci;
		for (ci = m_Tnd.cells_begin(); ci != m_Tnd.cells_end(); ++ci) 
		{ 
			int id_rgn = ci->info().Region();
			if ( !( id_rgn >= 0 && id_rgn < mrl_size ) )
				continue;
			table[id_rgn]->Store(ci);
		}
	}
	
	for ( pli = begin(); pli != end(); ++pli )
	{
		if ( *pli == NULL )
			continue;
		(*pli)->IncorporateCells();
	}

//ShowCellIds();
	U_END_SUB_PROC;	
}

template <class Tni, class MRgnPtr>
void CMeshRgnVector_d<Tni, MRgnPtr>::PrintRgns()
{
	MRgnPtr pRgn;
	printf("\n%d-Rgns : ", size());
	for ( iterator i = begin(); i != end(); ++i )
	{
		pRgn = *i;
		if ( pRgn == NULL )
		{	printf("n ");	continue; }
		if ( pRgn->Id() == -1 )
		{	printf("-1 ");	continue; }
		printf("(%d) ", pRgn->Id());
	}
}

#endif // !defined(AFX_MeshRgnVector_d_H__94A0255D_C28F_4C5E_90DB_E806C029617B__INCLUDED_)
