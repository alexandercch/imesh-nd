// RectScan.h: interface for the CRectScan class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECTSCAN_H__3692D919_4466_4537_A5B9_0FDA55455BAA__INCLUDED_)
#define AFX_RECTSCAN_H__3692D919_4466_4537_A5B9_0FDA55455BAA__INCLUDED_

#include "Primitives_2.h"

template <class _FO>
class CRectScan  
{
public:
	void operator()(RectangleI_2* r, _FO* fo);
};

template <class _FO>
inline void CRectScan<_FO>::operator()(RectangleI_2* r, _FO* fo)
{
	int i,j;
	for ( i = r->xmin(); i <= r->xmax(); i++ )
		for ( j = r->ymin(); j <= r->ymax(); j++ )
			(*fo)(i,j);
}

#endif // !defined(AFX_RECTSCAN_H__3692D919_4466_4537_A5B9_0FDA55455BAA__INCLUDED_)
