// SpatialGradientMask.h: interface for the CConvolution class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SpatialGradientMask_H__6E1EB856_7D6B_49BA_925A_4705BD5D91C9__INCLUDED_)
#define AFX_CONVOLUTION_H__6E1EB856_7D6B_49BA_925A_4705BD5D91C9__INCLUDED_

template<class Img, int Size = 3>
struct MaskXY
{
public:
typedef typename Img			Img;
typedef typename Img::Coord		Coord;
typedef typename Img::IndexType	IndexType;
protected:
	IndexType GX[Size][Size], GY[Size][Size];
	Img* m;
	MaskXY(Img* _m)
	{		m = _m;	}
public:
	inline double Convolution(Coord c)
	{
		double sumgx = 0, sumgy = 0, g = 0;
		Img::IndexType i,j,ii,jj,xi,yi,sm = Size/2;
		xi = c.x()-sm;		yi = c.y()-sm;

		for ( ii = xi, i = 0; i < 3; i++, ii++ )
			for ( jj = yi, j = 0; j < 3; j+=2, jj+=2 )
				sumgx += (*m)(ii,jj)*GX[i][j];

		for ( ii = xi, i = 0; i < 3; i+=2, ii+=2 )
			for ( jj = yi, j = 0; j < 3; j++, jj++ )
				sumgy += (*m)(ii,jj)*GY[i][j];

		g = ::sqrt( sumgx*sumgx + sumgy*sumgy );
		return g;
	}
};

template<class Img>
struct CSobel33 : public MaskXY<Img, 3>
{
	CSobel33(Img* _m=0): MaskXY<Img, 3>(_m)
	{
		GX[0][0] = -1; GX[0][1] =  0; GX[0][2] =  1;
		GX[1][0] = -2; GX[1][1] =  0; GX[1][2] =  2;
		GX[2][0] = -1; GX[2][1] =  0; GX[2][2] =  1;
		
		GY[0][0] =  1; GY[0][1] =  2; GY[0][2] =  1;
		GY[1][0] =  0; GY[1][1] =  0; GY[1][2] =  0;
		GY[2][0] = -1; GY[2][1] = -2; GY[2][2] = -1;
	};
};

template<class Img>
struct CPrewitt33 : public MaskXY<Img, 3>
{
	CPrewitt33(Img* _m=0): MaskXY<Img, 3>(_m)
	{
		GX[0][0] = 1; GX[0][1] =  0; GX[0][2] =  -1;
		GX[1][0] = 1; GX[1][1] =  0; GX[1][2] =  -1;
		GX[2][0] = 1; GX[2][1] =  0; GX[2][2] =  -1;
		
		GY[0][0] =  1; GY[0][1] =  1; GY[0][2] =  1;
		GY[1][0] =  0; GY[1][1] =  0; GY[1][2] =  0;
		GY[2][0] = -1; GY[2][1] = -1; GY[2][2] = -1;
	};
};

template<class Img>
struct CMSK77 : public MaskXY<Img, 7>
{
	CMSK77(Img* _m=0): MaskXY<Img, 3>(_m)
	{
		GX[0][0] = -3; 		GX[0][1] = -142; 	GX[0][2] = -113; 	GX[0][3] = 0; 	GX[0][4] = 113; 	GX[0][5] = 142; 	GX[0][6] = 3; 
		GX[1][0] = -348; 	GX[1][1] = -372; 	GX[1][2] = -228; 	GX[1][3] = 0; 	GX[1][4] = 228; 	GX[1][5] = 372; 	GX[1][6] = 348; 
		GX[2][0] = -555; 	GX[2][1] = -510; 	GX[2][2] = -297; 	GX[2][3] = 0; 	GX[2][4] = 297; 	GX[2][5] = 510; 	GX[2][6] = 555; 
		GX[3][0] = -624; 	GX[3][1] = -556; 	GX[3][2] = -320; 	GX[3][3] = 0; 	GX[3][4] = 320; 	GX[3][5] = 556; 	GX[3][6] = 624; 
		GX[4][0] = -555; 	GX[4][1] = -510; 	GX[4][2] = -297; 	GX[4][3] = 0; 	GX[4][4] = 297; 	GX[4][5] = 510; 	GX[4][6] = 555; 
		GX[5][0] = -348; 	GX[5][1] = -372; 	GX[5][2] = -228; 	GX[5][3] = 0; 	GX[5][4] = 228; 	GX[5][5] = 372; 	GX[5][6] = 348; 
		GX[6][0] = -3; 		GX[6][1] = -142; 	GX[6][2] = -113; 	GX[6][3] = 0; 	GX[6][4] = 113; 	GX[6][5] = 142; 	GX[6][6] = 3; 
		
		GY[0][0] = -3; 		GY[0][1] = -348; 	GY[0][2] = -555; 	GY[0][3] = -624; 	GY[0][4] = -555; 	GY[0][5] = -348; 	GY[0][6] = -3; 
		GY[1][0] = -142; 	GY[1][1] = -372; 	GY[1][2] = -510; 	GY[1][3] = -556; 	GY[1][4] = -510; 	GY[1][5] = -372; 	GY[1][6] = -142; 
		GY[2][0] = -113; 	GY[2][1] = -228; 	GY[2][2] = -297; 	GY[2][3] = -320; 	GY[2][4] = -297; 	GY[2][5] = -228; 	GY[2][6] = -113; 
		GY[3][0] = 0; 		GY[3][1] = 0; 		GY[3][2] = 0; 		GY[3][3] = 0; 		GY[3][4] = 0; 		GY[3][5] = 0; 		GY[3][6] = 0; 
		GY[4][0] = 113; 	GY[4][1] = 228; 	GY[4][2] = 297; 	GY[4][3] = 320; 	GY[4][4] = 297; 	GY[4][5] = 228; 	GY[4][6] = 113; 
		GY[5][0] = 142; 	GY[5][1] = 372; 	GY[5][2] = 510; 	GY[5][3] = 556; 	GY[5][4] = 510; 	GY[5][5] = 372; 	GY[5][6] = 142; 
		GY[6][0] = 3; 		GY[6][1] = 348; 	GY[6][2] = 555; 	GY[6][3] = 624; 	GY[6][4] = 555; 	GY[6][5] = 348; 	GY[6][6] = 3; 
	};
};

template<class Img, int Size = 3>
struct Mask1
{
public:
typedef typename Img			Img;
typedef typename Img::Coord		Coord;
typedef typename Img::IndexType	IndexType;
protected:
	IndexType Mk[Size][Size];
	Img* m;
	Mask1(Img* _m)
	{		m = _m;	}
public:
	inline double Convolution(Coord c)
	{
		double sum = 0;
		Img::IndexType i,j,ii,jj,xi,yi,sm = Size/2;
		xi = c.x()-sm;		yi = c.y()-sm;

		for ( ii = xi, i = 0; i < Size; i++, ii++ )
			for ( jj = yi, j = 0; j < Size; j++, jj++ )
				sum += (double)(*m)(ii,jj)*Mk[i][j];
		return sum;
	}
};

//http://www.cee.hw.ac.uk/hipr/html/log.html
template<class Img>
struct CLaplacian33 : public Mask1<Img>
{
	CLaplacian33(Img* _m=0): Mask1<Img>(_m)
	{
		Mk[0][0] = 0; Mk[0][1] =  1; Mk[0][2] =  0;
		Mk[1][0] = 1; Mk[1][1] = -4; Mk[1][2] =  1;
		Mk[2][0] = 0; Mk[2][1] =  1; Mk[2][2] =  0;
	};
};

#endif // !defined(AFX_SpatialGradientMask_H__6E1EB856_7D6B_49BA_925A_4705BD5D91C9__INCLUDED_)