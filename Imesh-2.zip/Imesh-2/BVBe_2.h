// BVBe_2.h: interface for the CBVBe_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BVBe_2_H__E394B6A1_5739_46AD_BC8B_71292EB50CB8__INCLUDED_)
#define AFX_BVBe_2_H__E394B6A1_5739_46AD_BC8B_71292EB50CB8__INCLUDED_

#include "VBe_2.h"
#include "Writer_2.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tni>	class CBVBe_2;
template<class Tni>
class CViolatorPoint : public Tni::Tn::Point
{
public:
typedef Tni::Tn				Tn;
typedef CBVBe_2<Tni>		BVBe;		friend typename	BVBe;
typedef Tn::Face_handle		Cell_handle;
typedef Tn::Point			_Point;
	CViolatorPoint(_Point p = _Point(0,0), Cell_handle ch = NULL, BVBe* be = NULL)
	{	
		*((_Point*)this) = p; 
		m_cell  = ch;	m_bedge = be;
	}
	inline Cell_handle&	cell()	{	return m_cell;		}
	inline BVBe*& bedge()	{	return m_bedge;		}

private:
	Cell_handle m_cell; //for rapid location
	BVBe* m_bedge;	//for an on_edge test
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tni>
class CBVVEPoint : public Tni::Tn::Point
{
public:
typedef Tni::Tn				Tn;
typedef CBVBe_2<Tni>		BVBe;	friend typename	BVBe;
typedef Tn::Point			_Point;
typedef Tn::Geom_traits		Gt;
typedef Gt::FT				FT;
typedef Tn::Vertex_handle	Vh;
private:
	CBVVEPoint(_Point p = _Point(0,0), FT	dist = 0.0, Vh vh = NULL)
	{	
		*((_Point*)this) = p; 
		m_dist = dist; m_vh = vh;	
	}
	inline FT&	dist()			{	return m_dist;			 }
public:	
	inline Vh&	vh()			{	return m_vh;			 }
private:
	FT	m_dist;
	Vh	m_vh;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tni>
class CBVBe_2  
{//Breaking Vertex-to-Vertex Edge -> Edge created to be broke
public:
typedef Tni::Tn						Tn;
typedef CWriter_2<Tni>				Writer;
typedef CBVBe_2<Tni>				Self;
typedef CVBe_2<Tn>				VBe;
typedef CVertexEdgeNode_2<Tn>		VENode;
typedef Tn::Geom_traits				Gt;
typedef Gt::FT						FT;
typedef Tn::Vertex_handle			Vh;
typedef Tn::Face_handle				Cell_handle;
typedef Tn::Point					Point;
typedef CBVVEPoint<Tni>				EPoint;
typedef list<EPoint>				EPoint_list;
typedef CViolatorPoint<Tni>			ViolatorPoint;
typedef list<ViolatorPoint>			ViolatorPoint_list;

	CBVBe_2(Vh _vh0 = NULL, Vh _vh1 = NULL);

	inline void Insert_radius_point(Vh vh, FT radius);
	inline void Insert_point(Point p);
	inline bool Has_on(ViolatorPoint* vp);
	void CommitBreaks(Tn* pTn, Writer* w);
	void Attack(ViolatorPoint* violator, ViolatorPoint_list* vpl);
	EPoint_list* EPointsList();

	void GetAllViolatorPoints(ViolatorPoint_list* vpl);
	Point Middle_point(Point a, Point b);
	Vh GetFirstMiddleVertexFrom(Vh v);
	void SelectBreakPoints(Writer* w);

	bool operator< (Self& mr);
	typedef /*const*/ Self*		SCPtr;	
	struct LessPtr 	{	bool operator() (const SCPtr& c1, const SCPtr& c2) const {	return (*c1 < *c2);	}	};

	inline EPoint&	start();
	inline EPoint&	final();
	inline int		start_id();
	inline int		final_id();

private:
	EPoint_list	m_epoints;
};

template<class Tni>
CBVBe_2<Tni>::CBVBe_2(Vh vh0, Vh vh1)
{
	assert(vh0 != vh1);
	bool bOrientation = vh0->info().ID() < vh1->info().ID();
	Point p0 = vh0->point(), p1 = vh1->point();
	double dist = squared_distance(p0, p1);
	if ( bOrientation )		{	m_epoints.push_back(EPoint(p0, 0,	 vh0));	
								m_epoints.push_back(EPoint(p1, dist, vh1));	}
	else					{	m_epoints.push_back(EPoint(p1, 0,	 vh1));	
								m_epoints.push_back(EPoint(p0, dist, vh0));	}
}

template<class Tni>
CBVBe_2<Tni>::EPoint_list* CBVBe_2<Tni>::EPointsList()
{
	return &m_epoints;
}

template<class Tni>
CBVBe_2<Tni>::Vh CBVBe_2<Tni>::GetFirstMiddleVertexFrom(Vh v)
{
	assert( m_epoints.size() > 2 );
	EPoint	*s = &start(), *f = &final();
	if ( v == s->vh() )
	{
		EPoint_list::iterator it = m_epoints.begin();
		++it;
		return it->vh();
	}
	else if ( v == f->vh() )
	{
		EPoint_list::reverse_iterator it = m_epoints.rbegin();
		++it;
		return it->vh();
	}

	assert(0);
	return NULL;
}

template<class Tni>
CBVBe_2<Tni>::Point CBVBe_2<Tni>::Middle_point(Point a, Point b)
{
	return Point( ( a.x() + b.x() ) / 2.0, ( a.y() + b.y() ) / 2.0 );
}

template<class Tni>
void CBVBe_2<Tni>::Attack(ViolatorPoint* violator, ViolatorPoint_list* vpl)
{
	if ( Has_on(violator) )		
		return;
	Cell_handle cell = start().vh()->face();
	Point a,b, middle;
	EPoint_list::iterator i, ii, _ii, _end;
	ii = i = m_epoints.begin();
	++ii;
	_end = m_epoints.end();
	for ( ; ii != _end; )
	{
		a = *i;	b = *ii;
		if ( VBe::IsViolated(a,b,*violator) )
		{
			middle = Middle_point(a, b);
			_ii = m_epoints.insert(ii, EPoint(middle) );
			vpl->push_back( ViolatorPoint(middle, cell, this) );
			_end = ii;	++_end;			
			ii = _ii;
		}
		else	
		{	++i; ++ii;	}
	}
}

template<class Tni>
void CBVBe_2<Tni>::GetAllViolatorPoints(ViolatorPoint_list* vpl)
{
	Cell_handle cell = start().vh()->face();
	int i = 1, size = m_epoints.size()-1;
	EPoint_list::iterator it = m_epoints.begin();
	for ( ++it; i < size; i++, ++it )
		vpl->push_back( ViolatorPoint(*it, cell, this) );
}

template<class Tni>
void CBVBe_2<Tni>::Insert_radius_point(Vh v, FT radius)
{//Insert a new point from a distance "radius" from the vertex v
 //assert(radius < |final()-start()| );
	Vh vs, vf;
	Point s, f, p;
	vs = final().vh();	vf = start().vh();
	if		( v == vs )		{	s = vs->point();	f = vf->point();	}
	else if ( v == vf )		{	s = vf->point();	f = vs->point();	}
	else					assert(0);

	FT t = radius/::sqrt(final().dist());
	p = Point( s.x() + t*(f.x() - s.x()), s.y() + t*(f.y() - s.y()) );
	Insert_point(p);
}

template<class Tni>
void CBVBe_2<Tni>::Insert_point(Point p)
{
	//assert(p is collinear and is on the segment vh0_vh1);
	EPoint new_middle(p, squared_distance(p, start()), NULL );
	
	int size = m_epoints.size();
	if ( !size )
	{
		m_epoints.push_back(new_middle);
		return;
	}

	EPoint_list::iterator it;
	for( it = m_epoints.begin(); it != m_epoints.end(); ++it )
		if ( new_middle.dist() < it->dist() )
			break;
	m_epoints.insert(it, new_middle);
}

template<class Tni>
bool CBVBe_2<Tni>::Has_on(ViolatorPoint* vp)
{	return vp->bedge() == this;		}

template<class Tni>
void CBVBe_2<Tni>::CommitBreaks(Tn* pTn, Writer* w)
{
	if (m_epoints.size() < 3)
	{
		printf("-- ? --");
		return;
	}
	VBe(m_epoints.begin()->vh(), m_epoints.rbegin()->vh()).Unmount();
	int k=1, size = m_epoints.size()-1;
	EPoint_list::iterator it = m_epoints.begin();

	Vh vh = start().vh();
	for ( ++it; k < size; k++, ++it )
		it->vh() = pTn->insert(*it, vh->face());

	EPoint_list::iterator i, ii;
	i = ii = m_epoints.begin();
	for ( ++ii; ii != m_epoints.end(); ++i, ++ii )
		VBe(i->vh(), ii->vh()).Mount();
}

template<class Tni>
void CBVBe_2<Tni>::SelectBreakPoints(Writer* w)
{
	assert(m_epoints.size() >= 3);
	VBe(m_epoints.begin()->vh(), m_epoints.rbegin()->vh()).Unmount();
	int k=1, size = m_epoints.size()-1;
	EPoint_list::iterator it = m_epoints.begin();
	Vh vh = start().vh();
	for ( ++it; k < size; k++, ++it )
		w->SelectPoint(*it, .2);
}

template<class Tni>
bool CBVBe_2<Tni>::operator< (Self& r)
{
	if ( start_id() == r.start_id() )		
		return final_id() < r.final_id();
	return start_id() < r.start_id();
}

template<class Tni>	CBVBe_2<Tni>::EPoint& CBVBe_2<Tni>::start()		 { return *(m_epoints.begin());			}
template<class Tni>	CBVBe_2<Tni>::EPoint& CBVBe_2<Tni>::final()		 { return *(m_epoints.rbegin());		}
template<class Tni>	int CBVBe_2<Tni>::start_id()						 { return start().vh()->info().ID();	}
template<class Tni>	int CBVBe_2<Tni>::final_id()						 { return final().vh()->info().ID();	}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tni>
class CBVBeGroup_2 : public set<CBVBe_2<Tni>::SCPtr, CBVBe_2<Tni>::LessPtr >
{
public:
typedef Tni::Tn						Tn;
typedef CWriter_2<Tni>				Writer;
typedef CBVBeGroup_2<Tni>			Self;
typedef CVBe_2<Tn>					VBe;
typedef CBVBe_2<Tni>				BVBe;
typedef BVBe::ViolatorPoint			ViolatorPoint;	
typedef BVBe::ViolatorPoint_list	ViolatorPoint_list;
typedef Tn::Point					Point;
typedef Tn::Vertex_handle			Vh;
typedef Tn::Face_handle				Cell_handle;
typedef Tn::Edge					Edge;


	CBVBeGroup_2();
	~CBVBeGroup_2();
	void Create(Tn* pTn, Writer* w);
	void Free();
	BVBe* GetAllocBEdge(Vh _vh0, Vh _vh1);
	bool ComputeViolations(ViolatorPoint violator, bool& bPeakEdge);
	bool LoadViolatedBVBes(ViolatorPoint violator, ViolatorPoint_list* vpl, bool& bPeakEdge);
	void PropagateViolation(Edge e, ViolatorPoint violator, ViolatorPoint_list* vpl, bool& bPeakEdge);
	void CommitBreaks();

	void SelectViolatorPoints(ViolatorPoint_list* vl);
	void SelectAllBreakPoints();

private:
	Tn* m_pTn;
	Writer* m_w;
};

template<class Tni>	
CBVBeGroup_2<Tni>::CBVBeGroup_2()		{	m_pTn = NULL; m_w = NULL;	}
template<class Tni>	
CBVBeGroup_2<Tni>::~CBVBeGroup_2()		{	Free();		}

template<class Tni>
void CBVBeGroup_2<Tni>::Create(Tn* pTn, Writer* w)	{	m_pTn = pTn; m_w = w;	}

template<class Tni>
void CBVBeGroup_2<Tni>::Free()
{
	for ( iterator i = begin(); i != end(); ++i )
		delete *i;
	clear();
}

template<class Tni>
CBVBeGroup_2<Tni>::BVBe* CBVBeGroup_2<Tni>::GetAllocBEdge(Vh vh0, Vh vh1)
{
	BVBe* bEgde = new BVBe(vh0, vh1);
	pair<iterator, bool> ret;
	ret = insert(bEgde);
	if( !ret.second )	
		delete bEgde;
	return *ret.first;
}

template<class Tni>
void CBVBeGroup_2<Tni>::CommitBreaks()
{
	for ( iterator i = begin(); i != end(); ++i )
		(*i)->CommitBreaks(m_pTn, m_w);		
}

template<class Tni>
bool CBVBeGroup_2<Tni>::ComputeViolations(ViolatorPoint violator, bool& bPeakEdge)
{
	ViolatorPoint_list vpl;
	ViolatorPoint vp;
	
	bPeakEdge = false;
	Free();
	vpl.push_back(violator);
	while(vpl.size())
	{
		vp = vpl.front(); vpl.pop_front();
		LoadViolatedBVBes(vp, &vpl, bPeakEdge);
	}
	return !!size() || bPeakEdge;
}

template <class Tni>
bool CBVBeGroup_2<Tni>::LoadViolatedBVBes(ViolatorPoint violator, ViolatorPoint_list* vpl, bool& bPeakEdge)
{
	Cell_handle ni, cell = m_pTn->locate(violator, violator.cell());
	for ( int i = 0; i < 3; i++ )
		PropagateViolation(Edge(cell, i), violator, vpl, bPeakEdge);
	return !!size();
}

template <class Tni>
void CBVBeGroup_2<Tni>::PropagateViolation(Edge e, ViolatorPoint violator, ViolatorPoint_list* vpl, bool& bPeakEdge)
{
	if ( bPeakEdge )
		return;
	//Verifying violations
	VBe vve(e);
	
	bool  b1,b2;
	b1 = vve.IsViolated(violator);
	if ( !b1)		return;
	b2 = vve.IsBorderElement();
	if ( b2 )
	{
		if ( vve.IsPeakEdge() )	{ bPeakEdge = true; return; }

		BVBe* bedge = GetAllocBEdge(vve.v0(), vve.v1());
		bedge->Attack(&violator, vpl);
	}

	//Propagating violation
	Cell_handle cell = e.first, ni;
	int k, i = e.second;
	ni = cell->neighbor(i);
	for ( k = 0; k < 3; k++ )
		if ( ni->neighbor(k) != cell )
			PropagateViolation(Edge(ni, k), violator, vpl, bPeakEdge);
}

template<class Tni>
void CBVBeGroup_2<Tni>::SelectViolatorPoints(ViolatorPoint_list* vl)
{
	ViolatorPoint_list::iterator ii;
	m_w->UnselectAll();	
	for( ii = vl->begin(); ii != vl->end(); ++ii)
		m_w->SelectPoint(*ii, 0.2);
	m_w->Refresh();
	printf("(%d)", vl->size());
}

template<class Tni>
void CBVBeGroup_2<Tni>::SelectAllBreakPoints()
{
	for ( iterator i = begin(); i != end(); ++i )
		(*i)->SelectBreakPoints(m_w);
}

#endif // !defined(AFX_BVBe_2_H__E394B6A1_5739_46AD_BC8B_71292EB50CB8__INCLUDED_)
