// TniU_2.h: interface for the CMeshGeneratorX2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TniU_2_H__9002750C_B179_468A_B3E4_2D85F9EC928C__INCLUDED_)
#define AFX_TniU_2_H__9002750C_B179_468A_B3E4_2D85F9EC928C__INCLUDED_

#include <CGAL/basic.h>
#include <CGAL/Cartesian.h>
#include "MGIntTraits.h"

typedef CMGIntTraits::INT			INT;
typedef CMGIntTraits::PointI_2		PointI_2;
typedef CMGIntTraits::RectangleI_2	RectangleI_2;	
typedef CMGIntTraits::SegmentI_2	SegmentI_2;
typedef CMGIntTraits::TriangleI_2	TriangleI_2;
typedef CMGIntTraits::PointI_3		PointI_3;

///////////////////////////////////////////////////////////////////////////////////////

class CTniU{};
namespace TniU
{
//Math	
	const double PI = 3.1415926535897932384626433832795;
	inline double RadiansToDegrees(double ang){ return ang*180/PI; }
	inline double DegreesToRadians(double ang){ return ang*PI/180; }
	inline double MaxDouble() {return 1.7E+308;}
	template<class FT>	
	inline double Round(FT x) { return (FT)(long)(x+0.5); }

//Point
	template<class _Gt>	//PointI_2FromPoint_2
	inline PointI_2 FtoI(_Gt::Point_2 pf)
	{
		PointI_2 point(pf.x(), pf.y());
		//PointI_2 point( Round<_Gt::FT>(pf.x()), Round<_Gt::FT>(pf.y()) );
		return point;
	}

	template<class Point_2, class PointI_2>	//PointI_2FromPoint_2
	inline PointI_2 Point_FtoI(Point_2 pf)
	{
		PointI_2 point(pf.x(), pf.y());
		//PointI_2 point( Round<_Gt::FT>(pf.x()), Round<_Gt::FT>(pf.y()) );
		return point;
	}

	template<class _Point_2, class _Window>
	inline void DrawBigPoint(_Point_2 point, color c, _Window w, int radius = 7)
	{
		CGAL::Point_2<CGAL::Cartesian<double> > cc_point(point.x(), point.y());
		CGAL::Circle_2<CGAL::Cartesian<double> > circ(cc_point, radius);			
		w->set_color(c);
		w->set_fill_color(c);
		*w<<cc_point<<circ;
	}

//Segment

	template<class _Triangulation>		
	inline _Triangulation::Vertex_handle 
	StarVertexFromStarEdge(_Triangulation::Edge_circulator ec, _Triangulation::Vertex_handle StarCenterVertex)
	{
		_Triangulation::Face_handle fh = ec->first; 		int iv = ec->second;
		_Triangulation::Vertex_handle vh1, vh2;
		vh1 = fh->vertex( (iv+1)%3 );		vh2 = fh->vertex( (iv+2)%3 );
		return (StarCenterVertex != vh1) ? vh1 : vh2;
	}
	
	template<class _Triangulation>		
	inline _Triangulation::Face_handle
	StarFaceFromStarEdge(_Triangulation::Edge_circulator ec, _Triangulation::Vertex_handle NeighborVertex)
	{
		_Triangulation::Face_handle tfh = ec->first;		int iv = ec->second;
		return (tfh->vertex(iv) == NeighborVertex)? tfh : tfh->neighbor(iv); //fh is a star face
	}

//Triangle
	template<class _Gt>
	inline double GetAngle(_Gt::Triangle_2 t, _Gt::Point_2 p)
	{
		int ip0,ip1,ip2;
		double	a,b,c, angle;
		for ( ip1 = 0; ip1 < 3; ip1++ )	if ( t[ip1] == p ) break;		assert(ip1 != 3);
		ip2 = (ip1+1)%3;		ip0 = (ip1+2)%3;
		a = ::sqrt(squared_distance(t[ip0], t[ip2]));
		b = ::sqrt(squared_distance(t[ip1], t[ip0]));
		c = ::sqrt(squared_distance(t[ip2], t[ip1]));
		angle = ::acos( (a*a - b*b - c*c) / (-2*b*c) );
		return angle;
	}

	template<class _Gt, class _Face_2> //TriangleI_2FromFace_2
	inline TriangleI_2 FaceToTriangleI(_Face_2 f)
	{
		PointI_2	c0 = FtoI<_Gt>(f->vertex(0)->point()),
					c1 = FtoI<_Gt>(f->vertex(1)->point()),
					c2 = FtoI<_Gt>(f->vertex(2)->point());
		TriangleI_2 t(c0,c1,c2);
		return t;
	}

	template<class Gt>
	inline Gt::Circle_2 RCircle(Gt::Point_2 a, Gt::Point_2 b, Gt::Point_2 c)
	{
		Gt::Point_2 cc = circumcenter(a,b,c);		
		Gt::FT sradius = squared_distance(cc, a);
		Gt::Circle_2 s(cc, sradius);
		return AssertCircle<Gt>(s);
	}

	template<class Gt>
	inline Gt::Circle_2& AssertCircle(Gt::Circle_2& s)
	{	assert(	s.oriented_side(s.center()) == ON_POSITIVE_SIDE );	
		return s;
	}

};

///////////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_TniU_2_H__9002750C_B179_468A_B3E4_2D85F9EC928C__INCLUDED_)