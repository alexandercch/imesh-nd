// PPMAsciiImageReader.h: interface for the CPPMAsciiImageReader_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PPMAsciiImageReader_H__B7892D4B_910A_4470_9CE9_B70C7F11F7F4__INCLUDED_)
#define AFX_PPMAsciiImageReader_H__B7892D4B_910A_4470_9CE9_B70C7F11F7F4__INCLUDED_

#include <stdio.h>
#include <string>
#include <assert.h>
#include "Matrix_2.h"

using namespace std;

template <typename IE, typename IT>
class CPPMAsciiImageReader_2
{
public:
typedef typename IE									ImageElement;
typedef typename IT									IntTraits;
typedef typename IntTraits::INT						IndexType;
typedef typename CMatrix_2<ImageElement,IT>			Matrix_2;

	CPPMAsciiImageReader_2();
	void Init(string strFileName, Matrix_2* pMatrix, int nXYOffset = 0);
	int Load();
	Matrix_2& Matrix();

private:	
	string m_strImageName;
	Matrix_2* m_pMatrix;
	int m_nXYOffset;
};

template <typename IE, typename IT>
CPPMAsciiImageReader_2<IE,IT>::CPPMAsciiImageReader_2()
{
	m_nXYOffset = 0;
	m_pMatrix = NULL;
}

template <typename IE, typename IT>
void CPPMAsciiImageReader_2<IE,IT>::Init(string strFileName, Matrix_2* pMatrix, int nXYOffset)
{	
	m_strImageName = strFileName;	
	m_pMatrix = pMatrix;
	m_nXYOffset = nXYOffset;
}

template <typename IE, typename IT>
inline CMatrix_2<IE,IT>& CPPMAsciiImageReader_2<IE,IT>::Matrix()
{	return m_Matrix;		}

template <typename IE, typename IT>
int CPPMAsciiImageReader_2<IE,IT>::Load()
{
	assert(!m_strImageName.empty());

	FILE* pf = ::fopen(m_strImageName.c_str(), "r");
	if(!pf)
	{
//		printf("no-image");
		return 0;
	}
	//reading head...
	char dim[255];
	::fscanf(pf, "%s%*c", dim);
	if ( strcmp(dim, "P3") )
		return 0; // n recognized image!!!
	
	char comment[1024];
	::fgets(comment, 1024, pf);

	unsigned xmax, ymax;
	::fscanf(pf, "%d %d %*d", &xmax, &ymax);
	
	m_pMatrix->Resize(xmax + 2*m_nXYOffset, ymax + 2*m_nXYOffset);
	
	unsigned i, j;
	for ( j = 0; j < ymax; j++)
	{	
		for ( i = 0; i < xmax; i++)
		{
			ImageElement &ie = (*m_pMatrix)(i + m_nXYOffset, ymax-j-1 + m_nXYOffset);
			::fscanf(pf, "%d %d %d", &ie[0], &ie[1], &ie[2] );
		}
	}
	
	::fclose(pf);
	return 1;
}

#endif // !defined(AFX_PPMAsciiImageReader_H__B7892D4B_910A_4470_9CE9_B70C7F11F7F4__INCLUDED_)

