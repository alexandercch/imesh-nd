// GOp_d.h: interface for the CGOp_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GOp_d_H__7D68DA52_C6A9_4190_BADC_78E0A75F618B__INCLUDED_)
#define AFX_GOp_d_H__7D68DA52_C6A9_4190_BADC_78E0A75F618B__INCLUDED_

//////////////////////////////////////////////////////////////////////////////////////////

template<class Mask>
class CGOp_d  
{
public:
typedef typename Mask::Img		Img;
typedef typename Img::Coord		Coord;
typedef typename list<float>	FList;
typedef typename vector<float>	FVector;

public:
	CGOp_d();	
	virtual ~CGOp_d();
	void Init(Img* pImg);
	inline void operator()(Coord c);
	void GetValues(FList* pIvl);
	void FPrint();
private:
	Img* m_pImg;
	FList m_IvList;
	FVector m_CHisto; //Cumulative Histogram
	Mask* m_pMask;
	int m_Threshold;
};

template<class Mask>
CGOp_d<Mask>::CGOp_d()	
{	m_pImg = NULL;	m_pMask = NULL; }

template<class Mask>
CGOp_d<Mask>::~CGOp_d()	
{	
	m_pImg = NULL;	
	if ( m_pMask ) delete m_pMask;
}

template<class Mask>
void CGOp_d<Mask>::GetValues(FList* pIvl)	
{	
	pIvl->clear();
	for ( int T = 0; T <= 255; T++ )
		pIvl->push_back( -m_CHisto[T] );
}

template<class Mask>
void CGOp_d<Mask>::Init(Img* pImg)			
{	
	m_pImg = pImg;	
	m_CHisto.clear();
	m_CHisto.resize(255);
	m_pMask = new Mask(m_pImg);
	cout<<"Threshold?"; cin>>m_Threshold;
}

template<class Mask>
void CGOp_d<Mask>::operator()(Coord c)
{
	float grad = m_pMask->Convolution(c);
	int gray = (*m_pImg)(c);

	if ( grad >= m_Threshold )
		m_CHisto[gray]++;
}

template<class Mask>
void CGOp_d<Mask>::FPrint()
{
	ofstream os;
	os.open("histo.txt", ofstream::out );	
	for ( int T = 0; T <= 255; T++ )
		os << -m_CHisto[T] << endl;
	os.close();
}


#endif // !defined(AFX_GOp_d_H__7D68DA52_C6A9_4190_BADC_78E0A75F618B__INCLUDED_)
