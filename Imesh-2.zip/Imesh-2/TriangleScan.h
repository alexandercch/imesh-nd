// TriangleScan.h: interface for the CTriangleScan class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRIANGLESCAN_H__7C854D2E_49DD_4E15_8639_2E9C3DF22472__INCLUDED_)
#define AFX_TRIANGLESCAN_H__7C854D2E_49DD_4E15_8639_2E9C3DF22472__INCLUDED_

#include <math.h>
/*	
COMMENT!
	We thought initially about the creation of a Triangle iterator class, 
	but soon we saw that he was going to be slow.  
	Then we decided to scan a triangle using a function object class. 
*/

template <class _FO, class IT>
class CTriangleScan  
{
public:
typedef typename IT::PointI_2		PointI_2;
typedef typename IT::SegmentI_2		SegmentI_2;
typedef typename IT::TriangleI_2	TriangleI_2;

	void operator()(TriangleI_2* t, _FO* fo);

private:
	void GetExtremes(TriangleI_2* tri, 
						int &b, int & l, int &r, int &t, int &m);

	int bottom, left, right, top, middle;
	double ml, mr, xl, xr;
	int j, bj, i, x, y, ybegin, yend, xbegin, xend, jmax;
	bool bFirstMiddleFilled;
};

template <class _FO, class IT>
void CTriangleScan<_FO,IT>::operator()(TriangleI_2* tri, _FO* pFunctionObject)
{
	GetExtremes(tri, bottom, left, right, top, middle);
	y = (*tri)[bottom].y();	bj = 1;
	bFirstMiddleFilled = false;
	for(; bj ; )
	{
		if (y == (*tri)[middle].y())
		{
			if (middle == left)
			{
				ml = ((*tri)[top].y() - (*tri)[left].y())/((*tri)[top].x() - (*tri)[left].x()+0.0);
				mr = ((*tri)[top].y() - (*tri)[bottom].y())/((*tri)[top].x() - (*tri)[bottom].x()+0.0);
				xl = (*tri)[left].x();
				xr = bFirstMiddleFilled? xr : (*tri)[bottom].x();
			}
			else
			{
				ml = ((*tri)[top].y() - (*tri)[bottom].y())/((*tri)[top].x() - (*tri)[bottom].x()+0.0);
				mr = ((*tri)[top].y() - (*tri)[right].y())/((*tri)[top].x() - (*tri)[right].x()+0.0);
				xl = bFirstMiddleFilled? xl : (*tri)[bottom].x();
				xr = (*tri)[right].x();
			}
			ybegin = y;
			yend = (*tri)[top].y();
			bj = 0;
		}
		else
		{
			mr = ((*tri)[right].y() - (*tri)[bottom].y())/((*tri)[right].x() - (*tri)[bottom].x()+0.0);
			ml = ((*tri)[left].y() - (*tri)[bottom].y())/((*tri)[left].x() - (*tri)[bottom].x()+0.0);
			xl = xr = (*tri)[bottom].x();
			ybegin = (*tri)[bottom].y();
			yend = (*tri)[middle].y();
			bj = 1;
			bFirstMiddleFilled = true;
		}
		for ( yend -= bj, y = ybegin; y <= yend ; y++ )
		{
			xbegin	= int(xl+0.5);
			xend	= int(xr+0.5);

			for (x = xbegin; x <= xend; x++)
			{
				(*pFunctionObject)(PointI_2(x,y));
			}
			xr = xr + 1/mr;
			xl = xl + 1/ml;
		}
	}	
}

template <class _FO, class IT>
void CTriangleScan<_FO,IT>::GetExtremes(TriangleI_2* tri, 
						int &b, int & l, int &r, int &t, int &m)
{
	bool f[3] = {false};
	//Getting the bottom point
	int i, j, k;
	if ( (*tri)[0].y() == (*tri)[1].y() )
		i = !( (*tri)[0].x() < (*tri)[1].x() ); 
	else
		i = !( (*tri)[0].y() < (*tri)[1].y() );	
	
	if ( (*tri)[2].y() == (*tri)[i].y() )
		if ( (*tri)[2].x() < (*tri)[i].x() ) 
			i = 2;
	if ( (*tri)[2].y() < (*tri)[i].y() )
		i = 2;
	
	f[i] = true;
	b = i;

	//Getting the left point
	
	bool ft = 1;
	for ( k = 0; k < 3; k++ )
	{
		if (f[k]) continue;
		if (ft)	{ ft = 0; i = k; continue; }
		j = k;
	}
	
	double ati, atj;
	
	ati = atan2( (*tri)[i].y() - (*tri)[b].y(), (*tri)[i].x() - (*tri)[b].x() );
	atj = atan2( (*tri)[j].y() - (*tri)[b].y(), (*tri)[j].x() - (*tri)[b].x() );
	
	if (ati < atj)							{	r = i;	l = j;	}
	else									{	r = j;	l = i;	}

	if ( (*tri)[r].y() > (*tri)[l].y() )	{	t = r;	m = l;	}
	else									{	t = l;	m = r;	}
}

#endif // !defined(AFX_TRIANGLESCAN_H__7C854D2E_49DD_4E15_8639_2E9C3DF22472__INCLUDED_)
