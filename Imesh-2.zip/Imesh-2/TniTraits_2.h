// TniTraits_2.h: interface for the CTniTraits_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TniTraits_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)
#define AFX_TniTraits_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_

#include "Mat_d.h"
#include "FI_2.h"

template <class Tnd,class Img,class RGBImg>
class CTniTraits_2
{
public:
static const int Dim;
typedef typename CTniTraits_2<Tnd,Img,RGBImg>	Self;
typedef typename Tnd							Tnd;
typedef typename Tnd::Tn						Tn;
typedef typename Tn::Geom_traits				Gt;
typedef typename Gt::FT							FT;
typedef typename Tn::Face_handle				Ch;
typedef typename Tn::Edge						Be;
typedef typename Tn::Vertex_handle				Vh;
typedef typename Img							Img;
typedef typename Img::IntTraits					IT;
typedef typename IT::INT						INT;
typedef typename RGBImg							RGBImg;
typedef typename CFI_2<Tn,IT>					FI;
typedef typename CMat_d<FT,INT>					Mat;
typedef typename Window_stream					Ws;
typedef typename Tn::Point						Point;

};
template <class Tn,class Img,class RGBImg>
const int CTniTraits_2<Tn,Img,RGBImg>::Dim = 2;

#define WRITER_H "Writer_2.h"
#define WRITER_CLASS CWriter_2

#endif // !defined(AFX_TniTraits_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)

/*public:
	CTniTraits_2(Tn* pTn = NULL, Img* pImg = NULL)
	{	m_pTn = pTn; m_pImg = m_pImg;	}
	
	static Self Make(Tn* pTn = NULL, Img* pImg = NULL)
	{	return Self(pTn; m_pImg); }
public:
	Tn* m_pTn;
	Img* m_pImg;*/