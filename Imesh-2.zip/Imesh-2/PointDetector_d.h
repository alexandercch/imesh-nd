// PointDetector_d.h: interface for the CPointDetector_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PointDetector_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
#define AFX_PointDetector_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_

template <class Tni, class PrePoint = Tni::Tn::Point>
class CPointDetector_d  
{
public:
typedef typename Tni::Tn		Tn;
typedef typename Tni::FT		FT;
typedef typename PrePoint		PrePoint;
typedef typename Tni::Ch		Ch;
typedef typename Tni::Img		Img;
typedef typename Img::Coord		Coord;
typedef typename Tni::FI		FI;
typedef typename Tn::Point		Point;
typedef typename Tni::Ws		Ws;
public:
	CPointDetector_d();
	virtual ~CPointDetector_d(){};
	virtual void Init(Img* m, Tn* pTn, Ws* pWs = NULL);
	virtual void ReadParams(){};
	virtual inline bool operator()(Coord c) { return 0; };
	virtual inline bool PointError(PrePoint c, FT& Tnior) { return 0; };
	virtual inline Point FinalPoint(PrePoint& p);
	inline void SetCurrCell(Ch ch);
	inline void begin();
	inline void end();
	inline PrePoint LastDetectedCoord();
	inline bool HasMeshBorderDetectorInterface();
	virtual inline void TestImg(Ws* ws=0){};
protected:
	Img* m_pImg;
	Tn* m_pTn;
	Ws* m_pWs;
	Ch m_CurrCell;
	PrePoint m_LastDetectedCoord;
	int m_nTime;
};

template <class Tni, class PrePoint>
CPointDetector_d<Tni, PrePoint>::CPointDetector_d()
{	m_nTime = 0;	m_pImg = NULL;	m_CurrCell = NULL;}


template <class Tni, class PrePoint>
void CPointDetector_d<Tni, PrePoint>::Init(Img* m, Tn* pTn, Ws* pWs)
{	m_pImg = m;	m_pTn = pTn; m_pWs = pWs; }
	
template <class Tni, class PrePoint>
inline bool CPointDetector_d<Tni, PrePoint>::HasMeshBorderDetectorInterface()
{	return false;	}

template <class Tni, class PrePoint>
void CPointDetector_d<Tni, PrePoint>::SetCurrCell(Ch ch)
{	m_CurrCell = ch;	}

template <class Tni, class PrePoint>
inline CPointDetector_d<Tni, PrePoint>::PrePoint 
CPointDetector_d<Tni, PrePoint>::LastDetectedCoord()	
{ return m_LastDetectedCoord;	}

template <class Tni, class PrePoint>
inline void CPointDetector_d<Tni, PrePoint>::begin()	
{	m_nTime = 0;	}

template <class Tni, class PrePoint>
inline void CPointDetector_d<Tni, PrePoint>::end()	
{}

template <class Tni, class PrePoint>
inline CPointDetector_d<Tni, PrePoint>::Point  
CPointDetector_d<Tni, PrePoint>::FinalPoint(PrePoint& p)
{	Point rp;	return rp;	}


#endif // !defined(AFX_PointDetector_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
