// ThreeAreasTest_2.h: interface for the CThreeAreasTest_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ThreeAreasTest_2_H__2775539F_92CB_40C2_AD90_59B4B3B4B6FA__INCLUDED_)
#define AFX_ThreeAreasTest_2_H__2775539F_92CB_40C2_AD90_59B4B3B4B6FA__INCLUDED_

template <class Tni>
class CThreeAreasTest_2
{
public:
typedef typename Tni				Tni;	
typedef typename Tni::Tn			Tn;
typedef typename Tni::Ch			Ch; 
typedef typename Tn::Geom_traits	Gt;
typedef typename Gt::FT				FT;
typedef typename Tn::Point			Point;

public:
	void ReadParams();
	inline bool operator()(Point bp, Ch fh, FT& error);
private:
	FT m_fMinArea;
};

template <class Tni>
void CThreeAreasTest_2<Tni>::ReadParams()
{
	U_TCIN("Min-Area: ", m_fMinArea);				
}

template <class Tni>
bool CThreeAreasTest_2<Tni>::operator()(Point bp, Ch fh, FT& error)
{
	Gt::Point_2 p0 = fh->vertex(0)->point(), p1 = fh->vertex(1)->point(), p2 = fh->vertex(2)->point();
	Gt::Triangle_2 t(p0,p1,p2);
	if ( t.has_on_unbounded_side(bp) )
		return false;
	Gt::Triangle_2	t0(p0,p1,bp), t1(p1,p2,bp), t2(p2,p0,bp);
	FT a0 = fabs(t0.area()), a1 = fabs(t1.area()), a2 = fabs(t2.area());
	error = a0 < a1 ? a0 : a1;
	if ( a2 < error ) error = a2;
	return error > m_fMinArea;
}

#endif // !defined(AFX_ThreeAreasTest_2_H__2775539F_92CB_40C2_AD90_59B4B3B4B6FA__INCLUDED_)

/*template <class Traits>
bool CImgCellError_2<Traits>::DistanceTest(Point bp, Cell_handle fh, Cell_handle& loc_sh)
{
	loc_sh = m_pTn->locate(bp, fh);
	Vh vh = m_pTn->nearest_vertex(bp, loc_sh);
	FT dist = MGU::Distance(bp, vh->point());	
	return dist > m_nMinError;
}
*/