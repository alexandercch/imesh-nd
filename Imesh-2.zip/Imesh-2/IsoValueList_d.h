// IsoValueList_d.h: interface for the CIsoValueList_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IsoValueList_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
#define AFX_IsoValueList_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_

template <class Tni>
class CIsoValueList_d
{
public:
typedef typename Tni::Tn	Tn;
typedef typename Tn::Point	Point;
typedef typename Tni::Img	Img;
typedef typename Img::Coord	Coord;
typedef typename float		Iv;
typedef typename list<Iv>	IvList;
typedef typename Tni::FI	FI;
public:
	virtual void ReadParams();
	inline void Clear();
	virtual inline operator string();
	inline bool operator()(Iv a, Iv b, Coord& ca, Coord& cb, Point& p, float& iv);
	inline bool operator()(Iv a, Iv b);
protected:
	IvList m_ivl;
};

template <class Tni>
inline void CIsoValueList_d<Tni>::Clear()
{	m_ivl.clear();	}

template <class Tni>
void CIsoValueList_d<Tni>::ReadParams()
{
	Iv value;	int i = 0;	char str[255];
	U_ENT; Clear();
	do
	{	sprintf(str, "Iso-value%d: ", ++i);
		U_TCIN(str, value);
		m_ivl.push_back(value);
	}while(!U_OK_ASK);
}

template <class Tni>
inline CIsoValueList_d<Tni>::operator string()
{	
	if ( !m_ivl.size() )
		return "";
	string s;
	char str[255];
	
	s = "vs =";
	IvList::iterator i;
	for ( i = m_ivl.begin();; )
	{	
		sprintf(str, " %.1lf", *i);	s += str;
		if (++i != m_ivl.end() )	s += ",";
		else						break;
	}
	return s;
}

template <class Tni>
inline bool CIsoValueList_d<Tni>::operator()(Iv a, Iv b, Coord& ca, Coord& cb, Point& p, float& iv)
{
	if ( b < a ) swap(a,b);
	for ( IvList::iterator i = m_ivl.begin(); i != m_ivl.end(); ++i )
	{
		if ( a == *i )	
		{	
			p = FI::ItoF(ca); iv = *i; 
			return true;	
		}
		if ( b == *i )	
		{	
			p = FI::ItoF(cb); iv = *i; 
			return true;	
		}
		if ( a < *i && *i < b )
		{	
			p = FI::Median(FI::ItoF(ca),FI::ItoF(cb)); iv = *i; 
			return true; 
		}
	}
	return false;
}

template <class Tni>
inline bool CIsoValueList_d<Tni>::operator()(Iv a, Iv b)
{
	if ( b < a ) swap(a,b);
	for ( IvList::iterator i = m_ivl.begin(); i != m_ivl.end(); ++i )
		if ( a <= *i && *i <= b )
			return true;
	return false;
}

#endif // !defined(AFX_IsoValueList_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
