// RGBPatternMeasurement_d.h: interface for the CMGFunctionObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RGBPatternMeasurement_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_)
#define AFX_RGBPatternMeasurement_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_

template <class _Image>
class CRGBMedian_d
{
public:
typedef typename _Image::Coord		Coord;
typedef typename _Image::IndexType	IdxT;
	CRGBMedian_d(_Image* m)	{	Reset(); matrix = m;	}
	int Area()				{	return N;				}
	void Reset()			{	sum[0] = sum[1] = sum[2] =0; N = 0;			}

	CRGBImageElement Result()	
	{	return CRGBImageElement(sum[0]/(N+0.0), sum[1]/(N+0.0), sum[2]/(N+0.0));	}
	
	inline void operator()(Coord c)
	{	N++; sum[0] += (*matrix)(c)[0];	sum[1] += (*matrix)(c)[1];	sum[2] += (*matrix)(c)[2];	}
private:
	unsigned long sum[3];	
	int N;	
	_Image* matrix;
};

#endif // !defined(AFX_RGBPatternMeasurement_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_)
