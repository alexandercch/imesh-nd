// TnCellMultimap_d.h: interface for the CTnCellMultimap_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TnCellMultimap_d_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)
#define AFX_TnCellMultimap_d_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_

template <class Tni, class Ord>
class CTnCellMultimap_d
{
public:
typedef typename Tni					Tni;
typedef typename Tni::Tn				Tn;
typedef typename Tn::Geom_traits		Gt;
typedef typename Gt::FT					FT;
typedef typename Tni::Ch				Ch;
typedef typename Tn::Vertex_handle		Vh;
typedef typename Ord::Key				MKey;
typedef typename multimap<MKey,Ch>		Cm;
typedef typename Cm::value_type			MValue;
typedef typename Cm::iterator			CmIt;
typedef typename Ord::PrePoint			PrePoint;
typedef typename pair<CmIt,PrePoint>	ItPoint;

public:
	CTnCellMultimap_d();
	virtual ~CTnCellMultimap_d();
	void Init(Tn* pTn, Ord* pOrd);
	inline bool PopFront(Ch& ch, PrePoint& bp);
	inline void FirstRegCell(Ch ch);
	inline int	Size();
	inline void Clear();
	inline void UpdateStarOp(Ch ch, long last_cell_id);
	virtual inline void UpdateStar(Vh& vh, long last_cell_id);
protected:
	virtual inline bool TryRegCell(Ch ch);
	virtual inline void UnregCell(Ch ch);
protected:
	Cm m_cm;
	Tn* m_pTn;
	Ord* m_pOrd;
};

template <class Tni, class Ord>
CTnCellMultimap_d<Tni,Ord>::CTnCellMultimap_d()
{	m_pTn = NULL;	m_pOrd = NULL;	}

template <class Tni, class Ord>
CTnCellMultimap_d<Tni,Ord>::~CTnCellMultimap_d()
{}

template <class Tni, class Ord>
void CTnCellMultimap_d<Tni,Ord>::Init(Tn* pTn, Ord* pOrd)
{	m_pTn = pTn; m_pOrd = pOrd;		}

template <class Tni, class Ord>
int	CTnCellMultimap_d<Tni,Ord>::Size()
{	return m_cm.size();	}

template <class Tni, class Ord>
void CTnCellMultimap_d<Tni,Ord>::Clear()
{
	for ( CmIt i = m_cm.begin(); i != m_cm.end(); ++i )
		UnregCell(i->second);
	m_cm.clear();
}

template <class Tni, class Ord>
bool CTnCellMultimap_d<Tni,Ord>::PopFront(Ch& ch, PrePoint& bp)
{
	if ( m_cm.empty() )
		return false;
	Cm::reverse_iterator ri;
	ri = m_cm.rbegin(); 
	ch = ri->second;
	ch->info().Flag() = 1;
	bp = ((ItPoint*)(ch->info().VoidPtr()))->second;
	UnregCell(ch);
	return true;
}

template <class Tni, class Ord>
void CTnCellMultimap_d<Tni,Ord>::FirstRegCell(Ch ch)
{
	TryRegCell(ch);// the first cell registration affair can be optimized
}

template <class Tni, class Ord>
bool CTnCellMultimap_d<Tni,Ord>::TryRegCell(Ch ch)
{
	assert(ch->info().VoidPtr() == NULL);
	PrePoint bp;
	MKey key;
	bool b = (*m_pOrd)(ch, bp, key);
	ch->info().Flag() = !b;
	if ( !b )
		return false;
	//reg
	Cm::iterator mi;
	mi = m_cm.insert(MValue(key, ch));
	ItPoint* pitpt = new ItPoint(mi,bp);
	void*& vp = mi->second->info().VoidPtr();
	assert(vp == NULL);
	vp = (void*)pitpt;
	return true;
}

template <class Tni, class Ord>
void CTnCellMultimap_d<Tni,Ord>::UnregCell(Ch ch)
{
	void*& vp = ch->info().VoidPtr();
	assert(vp != NULL);
	ItPoint* pitpt = (ItPoint*)vp;
	m_cm.erase(pitpt->first);
	delete pitpt;
	vp = NULL; 
}

template <class Tni, class Ord>
void CTnCellMultimap_d<Tni,Ord>::UpdateStarOp(Ch ch, long last_cell_id)
{
	if ( m_pTn->is_infinite(ch) )
	{	if ( ch->info().VoidPtr() )
			UnregCell(ch);
		return;
	}
	if ( ch->info().ID() >= last_cell_id )	//new faces
	{	if ( !ch->info().VoidPtr() )
			TryRegCell(ch);
	}
	else									//old faces and no tested faces 
	{	if ( ch->info().VoidPtr() )
			UnregCell(ch);
		TryRegCell(ch);
	}
}

template <class Tni, class Ord>
void CTnCellMultimap_d<Tni,Ord>::UpdateStar(Vh& vh, long last_cell_id)
{}

#endif // !defined(AFX_TnCellMultimap_d_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)
