// MeshBorderDetector_d.h: interface for the CMeshBorderDetector_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MeshBorderDetector_d_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_)
#define AFX_MeshBorderDetector_d_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_

template <class Tni>
class CMeshBorderDetector_d  
{
public:
typedef typename Tni					Tni;
typedef typename Tni::Be				Be;
typedef typename Tni::Tn				Tn;
typedef typename Tni::Img				Img;

public:
	enum EMeshBorder {be_no_border, be_border, be_extern_border};
	CMeshBorderDetector_d();
	virtual void Init(Tn* pTn, Img* pImg, Window_stream* ws);
	virtual inline EMeshBorder operator()(Be be) = 0;
protected:
	Tn* m_pTn;
	Img* m_pImg;
	Window_stream* m_ws;
};

template <class Tni>
CMeshBorderDetector_d<Tni>::CMeshBorderDetector_d()
{	m_pTn = NULL;	m_pImg = NULL; }

template <class Tni>
void CMeshBorderDetector_d<Tni>::Init(Tn* pTn, Img* pImg, Window_stream* ws)
{	m_pTn = pTn;	m_pImg = pImg; m_ws = ws;}


#endif // !defined(AFX_MeshBorderDetector_d_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_)
