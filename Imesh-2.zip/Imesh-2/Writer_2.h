// Writer_2.h: interface for the CMGVtkGroupWriter2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MGVTKGROUPWRITER2_H__9A6BABED_EAA7_47F5_A33B_51A4AE934688__INCLUDED_)
#define AFX_MGVTKGROUPWRITER2_H__9A6BABED_EAA7_47F5_A33B_51A4AE934688__INCLUDED_

#include "MeshRegion_d.h"
#include "GrayWriter.h"
#include "PGMWriter.h"
#include "assert.h"

#include "UMacros_d.h"
using namespace CGAL;

template<class Tni>
class CWriter_2  
{
typedef Tni										Tni;
typedef CMeshRegion_d<Tni>						Mr;
typedef Tni::Tn									Tn;
typedef Tni::Gt									Gt;
typedef Tni::Ch									Ch;	
typedef Tni::Img								Img;
typedef Tni::RGBImg								RGBImg;
typedef list<Ch>								Cell_list;
typedef Tn::Vertex_handle						Vertex_handle;
typedef list<Vertex_handle>						VertexList;
typedef Gt::Point_2								Point;
typedef Tn::Edge								Edge;
typedef pair<Point,double>						SelectedPoint;
typedef list<SelectedPoint>						SelectedPoint_list;
typedef Tn::Segment								Segment;
typedef list<Segment>							Segment_list;
typedef Mr::MeshRegionVector					MeshRegionVector;
typedef pair<Vertex_handle, Vertex_handle>		LVVEdge;
typedef list<LVVEdge>							LVVEdgeList;
typedef Img::IntTraits							IT;
typedef Gt::Sphere_3							Sphere;
typedef Gt::Circle_2							Circle;
typedef list<Sphere>							Sphere_list;

public:
	CWriter_2();
	void Create(Tn* pTn, Img* pImg, RGBImg* pRGBImg, Img* pImgHeight, 
				MeshRegionVector* pMeshRegionVector, LVVEdgeList* pLVVEdgeList);
	void SetOutDir(string out);
	virtual ~CWriter_2();
	void Refresh();
	string GroupStartStr();
private:
	enum EMeshData	{MD_NO_DATA = -1, MD_GRAY_CELL, MD_GRAY_VERTEX, MD_RGB_CELL, MD_RGB_VERTEX, MD_LAST_GRAY_VERTEX};
	bool RGBData();	
	void Write();
	void LoadFacesFromMG();
	void WriteMesh(Cell_list* pCell_list, string str_file, EMeshData data_type = MD_NO_DATA);
	void WriteMeshData(FILE* pf, Cell_list* cl, VertexList* vl, EMeshData type);
	bool WriteBorderSegments(string strEdges);//, Segment_list* sl
	void WriteSegments(string strEdges, Segment_list* sl);
	void WriteSelPoints(string strSelPoints);
	void WriteSelSpheres(string strSelSpheres);
	double PointHeight(Point p);
	bool WriteBorderEdges(string strEdges);
	void WriteMeshEdges(string strEdges);

	int  EnumerateVertices(Cell_list* pCell_list);
	void LoadVerticeCListFromCell_list(Cell_list* fl, VertexList* vl);
	void WriteCellData(FILE* pf, Cell_list* pCell_list);
	void WriteColorData(FILE* pf, Cell_list* pCell_list);
	void WriteVertexStrip(string strName, VertexList* vl);
	void WriteRawVertexStrip(string strName, VertexList* vl);
	void WritePGMSegImage(string strSegImage);

	void OpenGroup(string file);
	void AddItemGroup(string item, CGAL::Color color = CGAL::Color(0,0,0), float op = 1.0, bool shrink = 1);
	void CloseGroup(string file);

public:	
	void WriteRGBMesh(int i);
	void UnselectAll();
	void SelectPoint(Point p, double radius=2);
	void UnselectAllPoints();
	void SelectSegment(Segment s);
	void UnselectAllSegments();
	void SelectSegmentList(Segment_list *sl);
	void SelectCell(Ch c);
	void SelCircleSphere(Circle s);
	void SelSphere(Sphere s);
	void SelSphere(Point p, float r = 1.0);
	void SelSphere(Ch ch);
	void UnselectAllSpheres();			
	void UnselectAllCells();

private:
	CGAL::Color m_CurrentDataColor;

	Tn* m_pTn;
	Img* m_pImg, *m_pImgHeight;
	RGBImg* m_pRGBImg;

	MeshRegionVector* m_mrv;
	LVVEdgeList* m_pLVVEdgeList;

	string m_strOutPath, m_strOutAniPath;
	string m_strName, m_group, m_img_name;
	Cell_list			m_AllFaceCList;
	SelectedPoint_list	m_SelPoints;
	Segment_list		m_SelSegments;
	Cell_list			m_SelCells;
	Sphere_list			m_SelSpheres;

	FILE* m_pfGroup;
};

template<class Tni>
CWriter_2<Tni>::CWriter_2()
{
	m_strOutPath = "..\\out\\";
	m_strOutAniPath = "F:\\imesh_out\\ani\\";
	m_pTn = NULL;
	m_pImg = m_pImgHeight = NULL;
	m_pRGBImg = NULL;
	m_mrv	= NULL;
	m_pLVVEdgeList = NULL;
}

template<class Tni>
CWriter_2<Tni>::~CWriter_2()
{}

template<class Tni>
void CWriter_2<Tni>::SetOutDir(string out)
{	m_strOutPath = out; }

template<class Tni>
void CWriter_2<Tni>::Create(Tn* pTn, Img* pImg, RGBImg* pRGBImg, Img* pImgHeight,
							MeshRegionVector* pMeshRegionVector, LVVEdgeList* pLVVEdgeList)
{
	m_pTn = pTn;	
	m_pImg = pImg;
	m_pRGBImg = pRGBImg;
	m_pImgHeight = pImgHeight;
	m_img_name = m_pImg->ImageName();
	m_group = m_strOutPath + m_img_name + string("\\");
	m_mrv = pMeshRegionVector;
	m_pLVVEdgeList = pLVVEdgeList;
}

template<class Tni>
string CWriter_2<Tni>::GroupStartStr()
{
	return m_group;
}

template<class Tni>
void CWriter_2<Tni>::LoadVerticeCListFromCell_list(Cell_list* fl, VertexList* vl)
{
	int i, k = 0;
	Cell_list::iterator fi;
	for ( fi = fl->begin(); fi != fl->end(); ++fi )
		for ( i = 0; i < 3; i++ )
			(*fi)->vertex(i)->info().WID() = -1;

	for ( fi = fl->begin(); fi != fl->end(); ++fi )
		for ( i = 0; i < 3; i++ )
		{
			Vertex_handle vh = (*fi)->vertex(i);
			int &id = vh->info().WID();
			if ( id == -1 ) 
			{
				id = k++;
				vl->push_back(vh);
			}
		}
}

template<class Tni>
double CWriter_2<Tni>::PointHeight(Point p)
{
	double height = 1.0;
	Img::ImageElement	ie;
	ie = (*(m_pImgHeight->IsLoaded() ? m_pImgHeight:m_pImg))(p.x(), p.y());
	return ie*height/255.0;
}

template<class Tni>
void CWriter_2<Tni>::WriteMeshData(FILE* pf, Cell_list* cl, VertexList* vl, EMeshData type)
{
//{MD_NO_DATA = -1, MD_GRAY_CELL, MD_GRAY_VERTEX, MD_RGB_CELL, MD_RGB_VERTEX}


	Cell_list::iterator ci;	
	VertexList::iterator vi;
	double inc, idx = 0, value = 0;
	int r,g,b;
	int nColors = 255, k;
	Img::ImageElement ie;
	RGBImg::ImageElement rgb;
	switch(type)
	{
		case MD_GRAY_CELL:
			inc = 1.0/(double)(cl->size()-1);
			::fprintf(pf, "\n\nCELL_DATA %d\n", cl->size());
			::fprintf(pf, "SCALARS scalars float 1\n");
			::fprintf(pf, "LOOKUP_TABLE lut\n");
			for (ci = cl->begin(); ci != cl->end(); ++ci, idx += inc) 
				::fprintf(pf, "%.10lf\n", idx);
			
			::fprintf(pf, "\nLOOKUP_TABLE lut %d\n", cl->size());
			for (ci = cl->begin(); ci != cl->end(); ++ci) 
			{	value = (*ci)->info().Pattern()/255.0;
				::fprintf(pf,"%.2lf %.2lf %.2lf 1.0\n", value, value, value);
			}
		break;

		case MD_GRAY_VERTEX:
			inc = 1.0/(double)(vl->size()-1);
			::fprintf(pf, "\n\nPOINT_DATA %d\n", vl->size());
			::fprintf(pf, "SCALARS scalars float 1\n");
			::fprintf(pf, "LOOKUP_TABLE lut\n");
			for (vi = vl->begin(); vi != vl->end(); ++vi, idx += inc)
				::fprintf(pf, "%.10lf\n", idx);
			
			::fprintf(pf, "\nLOOKUP_TABLE lut %d\n", vl->size());
			for (vi = vl->begin(); vi != vl->end(); ++vi) 
			{	
				((color)((*m_pImg)((*vi)->point().x(), (*vi)->point().y()))).get_rgb(r,g,b);
				::fprintf(pf,"%.2lf %.2lf %.2lf 1.00\n", r/255.0, g/255.0, b/255.0);
			}
		break;
		
		case MD_RGB_CELL:
			inc = 1.0/(double)(cl->size()-1);
			::fprintf(pf, "\n\nCELL_DATA %d\n", cl->size());
			::fprintf(pf, "SCALARS scalars float 1\n");
			::fprintf(pf, "LOOKUP_TABLE lut\n");
			for (ci = cl->begin(); ci != cl->end(); ++ci, idx += inc) 
				::fprintf(pf, "%.10lf\n", idx);
			
			::fprintf(pf, "\nLOOKUP_TABLE lut %d\n", cl->size());
			for (ci = cl->begin(); ci != cl->end(); ++ci) 
			{	
				rgb = (*ci)->info().RGB();
				::fprintf(pf,"%.2lf %.2lf %.2lf 1.0\n", rgb[0]/255.0, rgb[1]/255.0, rgb[2]/255.0);
			}

		break;
		
		case MD_RGB_VERTEX:
			inc = 1.0/(double)(vl->size()-1);
			::fprintf(pf, "\n\nPOINT_DATA %d\n", vl->size());
			::fprintf(pf, "SCALARS scalars float 1\n");
			::fprintf(pf, "LOOKUP_TABLE lut\n");
			for (vi = vl->begin(); vi != vl->end(); ++vi, idx += inc)
				::fprintf(pf, "%.10lf\n", idx);
			
			::fprintf(pf, "\nLOOKUP_TABLE lut %d\n", vl->size());
			for (vi = vl->begin(); vi != vl->end(); ++vi) 
			{	
				rgb = (*m_pRGBImg)((*vi)->point().x(), (*vi)->point().y());
				::fprintf(pf,"%.2lf %.2lf %.2lf 1.00\n", rgb[0]/255.0, rgb[1]/255.0, rgb[2]/255.0);
			}

		break;

		case MD_LAST_GRAY_VERTEX:			

			::fprintf(pf, "\n\nPOINT_DATA %d\n", vl->size());
			::fprintf(pf, "SCALARS scalars float 1\n");
			::fprintf(pf, "LOOKUP_TABLE gray_colors\n");
			for ( vi = vl->begin(); vi != vl->end(); ++vi )
			{
				ie = (*m_pImg)((*vi)->point().x(), (*vi)->point().y());
				::fprintf(pf, "%.2lf\n", ie/255.0 );
			}
			inc = 1/(nColors-1.0), value = 0.0;
			::fprintf(pf, "LOOKUP_TABLE gray_colors %d\n", nColors);
			for (k = 0; k < nColors; k++, value += inc)
				::fprintf(pf,"%.2lf %.2lf %.2lf 1.0\n", value, value, value);
		break;
	}
}

template<class Tni>
void CWriter_2<Tni>::WriteMesh(Cell_list* cl, string file, EMeshData data_type)
{
	FILE* pf;
	pf = ::fopen(file.c_str(), "w"); assert(pf);

		::fprintf(pf,	"# vtk DataFile Version 2.0\n"
						"grid description\n"
						"ASCII\n"
						"DATASET UNSTRUCTURED_GRID\n\n");
		
		//points	
		VertexList vl;
		VertexList::iterator vi;
		LoadVerticeCListFromCell_list(cl, &vl);
		::fprintf(pf, "POINTS %d double\n", vl.size());
		for ( vi = vl.begin(); vi != vl.end(); ++vi )
			::fprintf(pf, "%lf\t%lf\t%lf\n",  (double)((*vi)->point().x()), (double)((*vi)->point().y()), PointHeight((*vi)->point()));

		//cells
		Cell_list::iterator ci;
		int nfc = cl->size();
		::fprintf(pf, "\nCELLS %d %d\n", nfc, 4*nfc );
		for (ci = cl->begin(); ci != cl->end(); ++ci) 
			::fprintf(pf, "3 %d %d %d\n",	(*ci)->vertex(0)->info().WID(), 
											(*ci)->vertex(1)->info().WID(), 
											(*ci)->vertex(2)->info().WID() );

		//cell types
		::fprintf(pf, "\nCELL_TYPES %d \n", nfc);
		for (ci = cl->begin(); ci != cl->end(); ++ci) 
			::fprintf(pf, "5 "); 
		
		//data 
		WriteMeshData(pf, cl, &vl, data_type);

	::fclose(pf);
}

template<class Tni>
void CWriter_2<Tni>::LoadFacesFromMG()
{
	m_AllFaceCList.clear();
	Tn::Finite_faces_iterator fi;
	for( fi = m_pTn->finite_faces_begin(); fi != m_pTn->finite_faces_end(); ++fi )	
		m_AllFaceCList.push_back(fi);
}

template<class Tni>
void CWriter_2<Tni>::Refresh()
{
	Write();	::printf(" [r] ");
}

template<class Tni>
bool CWriter_2<Tni>::RGBData()
{
	Tn::Finite_faces_iterator fi;
	fi = m_pTn->finite_faces_begin();
	RGBImg::ImageElement pixel = fi->info().RGB();

	return ( m_pRGBImg && m_pRGBImg->IsLoaded() && pixel[0] != -1);
}

template<class Tni>
void CWriter_2<Tni>::WriteRGBMesh(int i)
{
//	assert(RGBData());
	static int nFirstTime = 0;
	LoadFacesFromMG();
	char str[1024], dir[1024];
	sprintf(dir, "%s%s\\vtks\\", m_strOutAniPath.c_str(), m_img_name.c_str());
	if ( nFirstTime++ == 0 )
		CMGUtility::CreateDirectory(dir);
	sprintf(str, "%s%s%d.vtk", dir, m_img_name.c_str(), i);
	WriteMesh(&m_AllFaceCList, str, MD_RGB_CELL);
}

template<class Tni>
void CWriter_2<Tni>::Write()
{
	char _str[1024]; 
	int i;
	string str, mesh_region_i, strg, str_border_edges, str_sel_points, str_sel_spheres, str_sel_segments, str_sel_cells, str_mesh_edges;
	Color	color_sel_points	= GREEN,
			color_border_edges	= YELLOW,
			color_sel_segments	= VIOLET,
			color_sel_cells		= RED,
			color_mesh_edges	= WHITE;

	MeshRegionVector::iterator mrli;
	CMGUtility::CreateDirectory(m_group);
	//Parameters and history
	U_CPY_OUT_REOPEN_2(m_group.c_str());
	
	//Writing files... stringstream
	{
		//mesh edges
		::sprintf(_str, "_mesh_edges.vtk");
		str_mesh_edges = m_img_name + string(_str);
		str = m_group + str_mesh_edges;
		WriteMeshEdges(str);

		//mesh like image 
		//{
			LoadFacesFromMG();
			//gray cell data
			string mesh_image_gray_cell_data = m_img_name + string("_mesh_image_gray_cell_data.vtk");
			str = m_group + mesh_image_gray_cell_data;
			WriteMesh(&m_AllFaceCList, str, MD_GRAY_CELL);

			//gray Vertex data
			string mesh_image_gray_vertex_data = m_img_name + string("_mesh_image_gray_vertex_data.vtk");
			str = m_group + mesh_image_gray_vertex_data;
			WriteMesh(&m_AllFaceCList, str, MD_GRAY_VERTEX);

			//rgb cell data
			if ( RGBData() )
			{
				string mesh_image_rgb_cell_data = m_img_name + string("_mesh_image_rgb_cell_data.vtk");
				str = m_group + mesh_image_rgb_cell_data;
				WriteMesh(&m_AllFaceCList, str, MD_RGB_CELL);

				//rgb vertex data
				string mesh_image_rgb_vertex_data = m_img_name + string("_mesh_image_rgb_vertex_data.vtk");
				str = m_group + mesh_image_rgb_vertex_data;
				WriteMesh(&m_AllFaceCList, str, MD_RGB_VERTEX);
			}
		//}

/*		//control strip points
		int seqs_size = m_pTn->Border_strip_points_list.size();
		if ( seqs_size )
		{
			string strip_points_i;
			strg = m_group + m_img_name + string("control_strip_points.vtkg");
			OpenGroup(strg);
				AddItemGroup(mesh_like_image, CGAL::Color(255,255, 0), 1, 0);
				Tn::Vertex_handle_list_list::iterator lli;
				i = 0;
				for (	lli =	m_pTn->Border_strip_points_list.begin();
						lli !=  m_pTn->Border_strip_points_list.end();
						++lli,  i++ )
				{
					::sprintf(_str, "_ctrl_strip_points_%d.vtk", i);
					strip_points_i = m_img_name + string(_str);
					str = m_group + strip_points_i;			
					WriteVertexStrip(str, &(*lli));
					AddItemGroup(strip_points_i, CGAL::Color(255,255, 0), 1, 0);

					::sprintf(_str, "_ctrl_strip_points_%d.ctrl", i);
					strip_points_i = m_img_name + string(_str);
					str = m_group + strip_points_i;			
					WriteRawVertexStrip(str, &(*lli));
				}

			CloseGroup(strg);
		}
*/
		//selected points
		if ( m_SelPoints.size() )
		{
			::sprintf(_str, "_sel_points.pcg");
			str_sel_points = m_img_name + string(_str);
			str = m_group + str_sel_points;
			WriteSelPoints(str);
		}

		//selected spheres
		if ( m_SelSpheres.size() )
		{
			str_sel_spheres = m_img_name + string("_sel_spheres.psg");			
			str = m_group + str_sel_spheres;
			WriteSelSpheres(str);
		}

		//selected segments
		if ( m_SelSegments.size() )
		{
			::sprintf(_str, "_sel_segments.vtk");
			str_sel_segments = m_img_name + string(_str);
			str = m_group + str_sel_segments;
			WriteSegments(str, &m_SelSegments);
		}

		//selected cells
		if ( m_SelCells.size() )
		{
			::sprintf(_str, "_sel_cells.vtk");
			str_sel_cells = m_img_name + string(_str);
			str = m_group + str_sel_cells;
			WriteMesh(&m_SelCells, str);			
		}

		//border edges
		{
			::sprintf(_str, "_border_edges.vtk");
			str_border_edges = m_img_name + string(_str);
			str = m_group + str_border_edges;
			if( !WriteBorderEdges(str) )
				str_border_edges = "";
		}

		//image details
		{
			strg = m_group + m_img_name + string("_img_details.vtkg");
			OpenGroup(strg);
				AddItemGroup(mesh_image_gray_cell_data);
				AddItemGroup(mesh_image_gray_vertex_data);
													//AddItemGroup(str_mesh_edges,	color_mesh_edges);
				if ( m_SelCells.size() )			AddItemGroup(str_sel_cells	,	color_sel_cells);
				if ( !str_border_edges.empty() )	AddItemGroup(str_border_edges,	color_border_edges);
				if ( m_SelSegments.size() )			AddItemGroup(str_sel_segments,	color_sel_segments);
				if ( m_SelPoints.size() )			AddItemGroup(str_sel_points,	color_sel_points, 0, 0);

			CloseGroup(strg);
		}

/*		//each region like image
		{
			strg = m_group + m_img_name + string("_image_region.vtkg");
			OpenGroup(strg);
			
			for ( i = 0, mrli = m_mrv->begin(); mrli != m_mrv->end(); ++mrli )
			{
				if ( (*mrli)->Id() == -1 )
					continue;
				::sprintf(_str, "_image_region_%d.vtk", (*mrli)->Id());
				mesh_region_i = m_img_name + string(_str);
				str = m_group + mesh_region_i;			
				WriteMesh(&((*mrli)->CList()), str);
				AddItemGroup(mesh_region_i);
			}
			if ( !str_border_edges.empty() )	AddItemGroup(str_border_edges,	color_border_edges);
			if ( m_SelPoints.size() )			AddItemGroup(str_sel_points,	color_sel_points, 1, 0);
			
			CloseGroup(strg);
		}

		//median regions
		{
			strg = m_group + m_img_name + string("_median_region.vtkg");
			OpenGroup(strg);

			for ( i = 0, mrli = m_mrv->begin(); mrli != m_mrv->end(); ++mrli )
			{
				if ( (*mrli)->Id() == -1 )
					continue;

				::sprintf(_str, "_median_region_%d.vtk", (*mrli)->Id());
				mesh_region_i = m_img_name + string(_str);
				str = m_group + mesh_region_i;
				WriteMesh(&((*mrli)->CList()), str);
				AddItemGroup(mesh_region_i, CGAL::Color((*mrli)->Pattern(), (*mrli)->Pattern(), (*mrli)->Pattern()));
			}
				if ( !str_border_edges.empty() )	AddItemGroup(str_border_edges,	color_border_edges);
				if ( m_SelPoints.size() )			AddItemGroup(str_sel_points,	color_sel_points, 1, 0);
			CloseGroup(strg);
		}*/

		//color regions
		{
			strg = m_group + m_img_name + string("_color_region.vtkg");
			OpenGroup(strg);

			for ( i = 0, mrli = m_mrv->begin(); mrli != m_mrv->end(); ++mrli )
			{
				if ( !*mrli || (*mrli)->Id() == -1 )
					continue;

				::sprintf(_str, "_color_region_%d.vtk", (*mrli)->Id());
				mesh_region_i = m_img_name + string(_str);
				str = m_group + mesh_region_i;
				m_CurrentDataColor = (*mrli)->Color();			
				WriteMesh(&((*mrli)->CList()), str);
				AddItemGroup(mesh_region_i, m_CurrentDataColor);
			}
			if ( !str_border_edges.empty() )	AddItemGroup(str_border_edges,	color_border_edges);
			if ( m_SelPoints.size() )			AddItemGroup(str_sel_points,	color_sel_points, 1, 0);
			if ( m_SelCells.size() )			AddItemGroup(str_sel_cells	,	color_sel_cells);
			if ( m_SelSpheres.size() )			AddItemGroup(str_sel_spheres, CGAL::GREEN);
			CloseGroup(strg);
		}
		
		//write segmented image
		{
			string segmented_image = m_img_name + string("segmented_image.pgm");
			str = m_group + segmented_image;
			WritePGMSegImage(str); 
		}
	}
}

template<class Tni>
void CWriter_2<Tni>::OpenGroup(string file)
{
	m_pfGroup = ::fopen(file.c_str(), "w");
	assert(m_pfGroup);
		//header
		fprintf(m_pfGroup, "FileName r g b op shrink tube\n");
}

template<class Tni>
void CWriter_2<Tni>::AddItemGroup(string item, CGAL::Color color, float op, bool shrink)
{
	//FileName r g b op shrink tube	
	fprintf(m_pfGroup, "%s %.1lf %.1lf %.1lf %.1f %d 0\n", 
		item.c_str(), color.red()/255.0, color.green()/255.0, color.blue()/255.0, op, shrink);		
}

template<class Tni>
void CWriter_2<Tni>::CloseGroup(string file)
{
	::fclose(m_pfGroup);
	CMGUtility::WriteUpdateFile(file);
}

template <class Tni>
void CWriter_2<Tni>::WriteSelPoints(string strSelPoints)
{
	FILE* pfSelPoints = ::fopen(strSelPoints.c_str(), "w");
		fprintf(pfSelPoints, "x	 y	z	r	res\n");
		list<SelectedPoint>::iterator i;
		for ( i = m_SelPoints.begin(); i != m_SelPoints.end(); ++i )
			fprintf(pfSelPoints, "%.1lf %.1lf 0.0 %.1lf 0\n", i->first.x(), i->first.y(), i->second);	
	::fclose(pfSelPoints);
}

template <class Tni>
void CWriter_2<Tni>::WriteSelSpheres(string strSelSpheres)
{
	FILE* pfSelSpheres = ::fopen(strSelSpheres.c_str(), "w");
		fprintf(pfSelSpheres, "x	 y	z	r	res\n");
		Sphere_list::iterator i;
		for ( i = m_SelSpheres.begin(); i != m_SelSpheres.end(); ++i )
			fprintf(pfSelSpheres, "%.1lf %.1lf %.1lf %.1lf 20\n", 
									i->center().x(), i->center().y(), i->center().z(), CGAL::sqrt(i->squared_radius()) );	
	::fclose(pfSelSpheres);
}

template <class Tni>
void CWriter_2<Tni>::WriteRawVertexStrip(string strName, VertexList* vl)
{
	FILE* pfEdges = ::fopen(strName.c_str(), "w");	

	int size = vl->size();
	::fprintf(pfEdges, "%d\n\n", size);
	VertexList::iterator li;
	for ( li = vl->begin(); li != vl->end(); ++li )
		::fprintf(pfEdges, "%d\n", (*li)->info().WID());
	
	::fclose(pfEdges);
}

template <class Tni>
void CWriter_2<Tni>::WriteVertexStrip(string strName, VertexList* vl)
{
	FILE* pfEdges = ::fopen(strName.c_str(), "w");
	
	int i, nEdges = vl->size()-1;

	//header
	::fprintf(pfEdges,	"# vtk DataFile Version 2.0\n"
						"eddes\n"
						"ASCII\n"
						"DATASET UNSTRUCTURED_GRID\n");
	
	//points
	::fprintf(pfEdges, "POINTS %d float\n", 2*nEdges);
	VertexList::iterator li, last_li;
	last_li = li = vl->begin(); ++li;
	for ( ; li != vl->end(); ++li )
	{
		Tn::Gt::Segment_2 seg( (*last_li)->point(), (*li)->point() );
		::fprintf(pfEdges, "%.2lf\t%.2lf\t 0.0\n", seg[0].x(), seg[0].y());
		::fprintf(pfEdges, "%.2lf\t%.2lf\t 0.0\n", seg[1].x(), seg[1].y());
		last_li = li;
	}

	//edges
	::fprintf(pfEdges, "CELLS %d %d\n", nEdges, 3*nEdges);
	for ( i = 0; i < nEdges; i++ )
		::fprintf(pfEdges, "2 %d %d\n", 2*i, 2*i+1);
	
	::fprintf(pfEdges, "CELL_TYPES %d\n", nEdges);
	for ( i = 0; i < nEdges; i++ )
		::fprintf(pfEdges, "3 ");
			
	::fclose(pfEdges);
}


template <class Tni>
bool CWriter_2<Tni>::WriteBorderEdges(string strEdges)
{
	if ( !m_pLVVEdgeList->size() )
		return false;

	Segment_list sl;
	LVVEdgeList::iterator li;
	for ( li = m_pLVVEdgeList->begin(); li != m_pLVVEdgeList->end(); ++li )
		sl.push_back(Segment(li->first->point(), li->second->point()));
	WriteSegments(strEdges, &sl);
	return true;
}

template <class Tni>
void CWriter_2<Tni>::WriteMeshEdges(string strEdges)
{
	Segment_list sl;	
	Tn::Finite_edges_iterator it = m_pTn->finite_edges_begin();
	for( ;it != m_pTn->finite_edges_end() ; ++it) 
		sl.push_back(m_pTn->segment(it));
	WriteSegments(strEdges, &sl);	
}

template <class Tni>
void CWriter_2<Tni>::WriteSegments(string strEdges, Segment_list* sl)
{
	FILE* pfEdges = ::fopen(strEdges.c_str(), "w");
	
	int i, nEdges = sl->size();

	//header
	::fprintf(pfEdges,	"# vtk DataFile Version 2.0\n"
						"eddes\n"
						"ASCII\n"
						"DATASET UNSTRUCTURED_GRID\n");
	
	//points
	::fprintf(pfEdges, "POINTS %d float\n", 2*nEdges);
	Segment_list::iterator li;
	for ( li = sl->begin(); li != sl->end(); ++li )
	{
		Segment seg(*li);
		::fprintf(pfEdges, "%.2lf\t%.2lf\t%.2lf\n", seg[0].x(), seg[0].y(), PointHeight(seg[0]) );
		::fprintf(pfEdges, "%.2lf\t%.2lf\t%.2lf\n", seg[1].x(), seg[1].y(), PointHeight(seg[1]) );
	}

	//edges
	::fprintf(pfEdges, "CELLS %d %d\n", nEdges, 3*nEdges);
	for ( i = 0; i < nEdges; i++ )
		::fprintf(pfEdges, "2 %d %d\n", 2*i, 2*i+1);
	
	::fprintf(pfEdges, "CELL_TYPES %d\n", nEdges);
	for ( i = 0; i < nEdges; i++ )
		::fprintf(pfEdges, "3 ");
			
	::fclose(pfEdges);
}

template<class Tni>
bool CWriter_2<Tni>::WriteBorderSegments(string strEdges)
{
	Segment_list sl;
	for ( Tn::Finite_edges_iterator fei = m_pTn->finite_edges_begin(); fei != m_pTn->finite_edges_end(); ++fei )
		if ( VVEdge(*fei).IsBorderEdge() )
			sl.push_back(m_pTn->segment(fei));
	WriteSegments(strEdges, &sl);
	return !!sl.size();
}

template<class Tni>
void CWriter_2<Tni>::WriteCellData(FILE* pf, Cell_list* fl)
{
	//cell data
	::fprintf(pf, "CELL_DATA %d\n", fl->size());
	::fprintf(pf, "SCALARS scalars float 1\n");
	::fprintf(pf, "LOOKUP_TABLE gray_colors\n");
		
	Cell_list::iterator fi;	
	for (fi = fl->begin(); fi != fl->end(); ++fi) 
	{ 
		double mr = (*fi)->info().Pattern();
		::fprintf(pf, "%.2lf\n", mr/255.0 );
	}

	//gray lookup table
	int nColors = 255, k;
	float inc = 1/(nColors-1.0), value = 0.0;
	::fprintf(pf, "LOOKUP_TABLE gray_colors %d\n", nColors);
	for (k = 0; k < nColors; k++, value += inc)
		::fprintf(pf,"%.2lf %.2lf %.2lf 1.0\n", value, value, value);
}

template<class Tni>
void CWriter_2<Tni>::WritePGMSegImage(string strSegImage)
{
	Img img(*m_pImg);
	CGrayWriter<Tn,Img> gw(&img);
	CTriangleScan<CGrayWriter<Tn,Img>, IT> ts;

	Tn::Finite_faces_iterator fi;
	for( fi = m_pTn->finite_faces_begin(); fi != m_pTn->finite_faces_end(); ++fi )	
	{
		TriangleI_2 tI = TniU::FaceToTriangleI<Gt>(fi);			
		gw.SetCurrCell(fi);
		ts(&tI, &gw);
	}
	CPGMWriter<Img> wr(&img);
	wr.Write(strSegImage);
}

////////////////////////////////////////////////////////////////////////////////////////

template<class Tni>
void CWriter_2<Tni>::UnselectAll()				{	UnselectAllCells();		UnselectAllSegments();
													UnselectAllPoints();	UnselectAllSpheres();				}
template<class Tni>
void CWriter_2<Tni>::SelectCell(Ch c)				{	m_SelCells.push_back(c);			}
template<class Tni>
void CWriter_2<Tni>::UnselectAllCells()					{	m_SelCells.clear();					}
template<class Tni>
void CWriter_2<Tni>::SelectSegment(Segment s)				{	m_SelSegments.push_back(s);			}
template<class Tni>
void CWriter_2<Tni>::UnselectAllSegments()					{	m_SelSegments.clear();								}
template<class Tni>
void CWriter_2<Tni>::SelectPoint(Point p, double radius)	{	m_SelPoints.push_back(SelectedPoint(p, radius));	}
template <class Tni>								
void CWriter_2<Tni>::SelCircleSphere(Circle s)
{
	Sphere ss(Gt::Point_3(s.center().x(), s.center().y(), 0.0), s.squared_radius());
	SelSphere(ss);
}
template <class Tni>								
void CWriter_2<Tni>::SelSphere(Sphere s)			{	m_SelSpheres.push_back(s);			}
template <class Tni>								
void CWriter_2<Tni>::SelSphere(Point p, float r)	{	m_SelSpheres.push_back(Sphere(p,r*r)); }
template<class Tni>
void CWriter_2<Tni>::UnselectAllSpheres()			{	m_SelSpheres.clear();					}
template<class Tni>
void CWriter_2<Tni>::UnselectAllPoints()			{	m_SelPoints.clear();				}
template<class Tni>
void CWriter_2<Tni>::SelectSegmentList(Segment_list *sl)
{
	UnselectAllSegments(); 
	for ( Segment_list::iterator sli = sl->begin(); sli != sl->begin(); ++sli )
		SelectSegment(*sli);
}

#endif // !defined(AFX_MGVTKGROUPWRITER2_H__9A6BABED_EAA7_47F5_A33B_51A4AE934688__INCLUDED_)

/*template<class Tni>
double CWriter_2<Tni>::PointHeight(Vertex_handle vh)
{
	Tn::Edge_circulator ec, done;
	double m = 0, k = 0, d, factor = 3;
	ec = done = m_pTn->incident_edges(vh);
	int i;
	Ch fh;
	Vertex_handle v1, v2;

	do
	{
		if ( m_pTn->is_infinite(ec) )
			continue;
		i = ec->second;
		fh = ec->first;
		v1 = fh->vertex((i+1)%3);
		v2 = fh->vertex((i+2)%3);
		m += d = MGPoint::Distance(v1->point(), v2->point());
		k++; 
	}while(done != --ec);

	return factor * (m/k);
}
*/