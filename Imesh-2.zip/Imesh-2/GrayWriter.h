// GrayWriter.h: interface for the CGrayWriter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GrayWriter_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_)
#define AFX_GrayWriter_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_

template <class  Tn, class Image>
class CGrayWriter
{
public:
typedef typename Image::Coord		Coord;
typedef typename Image::IndexType	IdxT;
typedef typename Tn::Face_handle	Ch;
typedef typename map<int, int>		ColorTable;

public:
	CGrayWriter(Image* m);
	inline void SetCurrCell(Ch ch);
	inline void operator()(Coord c);
private:
	Image* matrix;
	Ch m_ch;
	int m_cur_color, color_count;
	ColorTable m_table;
};

template <class  Tn, class Image>
CGrayWriter<Tn,Image>::CGrayWriter(Image* m)	
{ 
	matrix = m;	
	m_cur_color = -1;
	color_count = 10;
}

template <class  Tn, class Image>
void CGrayWriter<Tn,Image>::SetCurrCell(Ch ch)	
{ 
	m_ch = ch;	
	int rgn = m_ch->info().Region();
	m_cur_color = m_table[rgn];
	if ( !m_cur_color )
	{
		m_cur_color = m_table[rgn] = color_count;
		color_count += 20;
	}
}

template <class  Tn, class Image>
void CGrayWriter<Tn,Image>::operator()(Coord c)
{	
	(*matrix)(c) = m_cur_color;
}


#endif // !defined(AFX_GrayWriter_H__EAEAA258_FD23_4D1E_84BD_ACAC53112F21__INCLUDED_)
