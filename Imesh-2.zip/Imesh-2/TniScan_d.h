//	: interface for the CTniScan_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTniScan_d_H__052DE00B_4A38_4FB6_9CD5_D395A5F7A611__INCLUDED_)
#define AFX_CTniScan_d_H__052DE00B_4A38_4FB6_9CD5_D395A5F7A611__INCLUDED_

/*----------------------------------------------------------------------------------------
	CImgScan_2,3
	CCellMediansScan_2,3
*///--------------------------------------------------------------------------------------

template <class Tni, class Op>
class CTniScan_d
{
public:
typedef typename Op			Op;
typedef typename Tni::Img	Img;
typedef typename Img::Coord	Coord;
typedef typename Tni::IT	IT;
typedef typename Tni::Tn	Tn;
public:
	CTniScan_d();	//virtual ~CTniScan_d();
	void Init(Tn* pTn, Img* pImg);
	virtual int Run(Op* pOp) = 0;
protected:
	Tn* m_pTn; Img* m_pImg;
};

template <class Tni, class Op>
CTniScan_d<Tni,Op>::CTniScan_d()					{	m_pTn = NULL; m_pImg = NULL; }
template <class Tni, class Op>
void CTniScan_d<Tni,Op>::Init(Tn* pTn, Img* pImg)	{	m_pTn = pTn; m_pImg = pImg;	}

#endif // !defined(AFX_CTniScan_d_H__052DE00B_4A38_4FB6_9CD5_D395A5F7A611__INCLUDED_)
