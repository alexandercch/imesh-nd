// Image.h: interface for the CImage_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMAGE_H__19E32535_6233_433B_AB58_47BCF2436360__INCLUDED_)
#define AFX_IMAGE_H__19E32535_6233_433B_AB58_47BCF2436360__INCLUDED_

#include <stdio.h>
#include <string>
#include <assert.h>
#include "Matrix_2.h"
#include <CGAL/basic.h>
#include <CGAL/IO/Window_stream.h>
using namespace CGAL;

template <class IR>
class CImage_2 : public CMatrix_2<IR::ImageElement, IR::IntTraits>
{
public:
typedef typename CImage_2<IR>				Self;
typedef typename IR							ImageReader;
typedef typename IR::ImageElement			ImageElement;
typedef typename IR::IntTraits				IntTraits;	
typedef typename IR::IndexType				IndexType;
typedef typename IntTraits::RectangleI_2	RectangleI_2;	
typedef typename IntTraits::PointI_2		PointI_2;	
typedef typename PointI_2					Coord;

	CImage_2(IndexType xmax = 0, IndexType ymax = 0, IndexType border_size = 10);
	CImage_2(Self& simg);
	virtual ~CImage_2();
	void SetImageName(string strFileName);
	int LoadImage();
	RectangleI_2& RectI();
	IndexType BorderSize();
	string ImageCompleteName();
	string ImageName();
	string ImageDir();
	inline unsigned long Area();
	bool IsLoaded();

private:
	string m_strDir, m_strImageName;	
	IndexType m_border_size;
	RectangleI_2 m_RectangleI;
	bool m_bLoaded;
};

template <class IR>
CImage_2<IR>::CImage_2(IndexType xmax, IndexType ymax, IndexType border_size)
			 :CMatrix_2<IR::ImageElement,IR::IntTraits>(xmax+2*border_size, ymax+2*border_size)
{
	m_border_size = border_size;
	m_bLoaded = 0; 
}

template <class IR>
CImage_2<IR>::CImage_2(Self& simg)
 			 :CMatrix_2<IR::ImageElement,IR::IntTraits>(simg)
{
	m_border_size = simg.m_border_size;
	m_RectangleI  = simg.m_RectangleI;
	m_bLoaded = 1;
}

template <class IR>
CImage_2<IR>::~CImage_2(){}

template <class IR>
bool CImage_2<IR>::IsLoaded()							{	return m_bLoaded;	}

template <class IR>
void CImage_2<IR>::SetImageName(string strFileName)		{	m_strImageName = strFileName;	}

template <class IR>
string CImage_2<IR>::ImageName()	{	return CMGUtility::GetFileName(m_strImageName); }

template <class IR>// complete image name dir + name + ext
string CImage_2<IR>::ImageCompleteName()	{	return m_strImageName; }

template <class IR>
string CImage_2<IR>::ImageDir()		{	return CMGUtility::GetDirName(m_strImageName); }

template <class IR>
inline CImage_2<IR>::RectangleI_2& CImage_2<IR>::RectI()	{	return m_RectangleI;	}

template <class IR>
inline CImage_2<IR>::IndexType CImage_2<IR>::BorderSize()	{	return m_border_size; }

template <class IR>
inline unsigned long CImage_2<IR>::Area()
{	return abs((m_RectangleI.xmax() - m_RectangleI.xmin()) * (m_RectangleI.ymax() - m_RectangleI.ymin()));	}

template <class IR>
int CImage_2<IR>::LoadImage()
{
	assert(!m_strImageName.empty());
	ImageReader IOImage;
	IOImage.Init(m_strImageName, this, m_border_size);
	m_bLoaded = !!IOImage.Load();
	if (!m_bLoaded)
		return 0;

	IndexType i,j, h, k, 
			  _x = m_XMax-m_border_size-1, _y = m_YMax-m_border_size-1;

	//generating borders (y)		
	for ( j = m_border_size; j <= _y; j++ )
		for ( k = 0; k < m_border_size; k++ )
		{
			(*this)(k,		j)	= (*this)(m_border_size,j);
			(*this)(_x+k+1,	j)	= (*this)(_x,j);
		}

	//generating borders (x)		
	for ( i = m_border_size; i <= _x; i++ )
	{	
		for ( k = 0; k < m_border_size; k++ )	
		{
			(*this)(i,k)		= (*this)(i,m_border_size);
			(*this)(i,_y+k+1)	= (*this)(i,_y);
		}
	}

	//generating corners
	//left top corner
	ImageElement pixel;
	pixel = (*this)(m_border_size,m_border_size);
	for ( h = 0; h < m_border_size; h++ )
		for ( k = 0; k < m_border_size; k++ )
			(*this)(h,k) = pixel;
	//left bottom corner
	pixel = (*this)(m_border_size,_y);
	for ( h = 0; h < m_border_size; h++ )
		for ( k = _y+1; k < m_YMax; k++ )
			(*this)(h,k) = pixel;
	//right bottom corner
	pixel = (*this)(_x,_y);
	for ( h = _x+1; h < m_XMax; h++ )
		for ( k = _y+1; k < m_YMax; k++ )
			(*this)(h,k) = pixel;
	//right top corner
	pixel = (*this)(_x,_y);
	for ( h = _x+1; h < m_XMax; h++ )
		for ( k = 0; k < m_border_size; k++ )
			(*this)(h,k) = pixel;

	m_RectangleI = RectangleI_2(m_border_size, m_border_size, _x, _y);
	m_bLoaded = 1;
	return 1;
}

template <class IR>
Window_stream& operator<<(Window_stream& ws, CImage_2<IR> &image )
{
	for ( unsigned j = 0 ; j < image.YMax(); j++ )
		for ( unsigned i = 0 ; i < image.XMax(); i++ )
			ws.draw_pixel(i, j, image(i,j));
	return ws;
}

#endif // !defined(AFX_IMAGE_H__19E32535_6233_433B_AB58_47BCF2436360__INCLUDED_)