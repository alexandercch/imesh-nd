// VBe_2.h: interface for the BreakingEdge_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BREAKINGEDGE_2_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_)
#define AFX_BREAKINGEDGE_2_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <list>
using namespace std;

template<class Tn>
class CVertexEdgeNode_2 : public list<Tn::Vertex_handle>
{
typedef CVertexEdgeNode_2<Tn>	Self;
typedef Tn::Vertex_handle		Vh;
public:
	CVertexEdgeNode_2()	{ m_bFlag = false; m_nPeakIdentifier = -1; }
	inline void AddEdgeWith(Vh vh);
	inline void RemoveEdgeWith(Vh vh);
	inline bool IsEdgeWith(Vh vh);
	static inline Self* GetAllocVENode(Vh vh);
	static inline Self* GetVENode(Vh vh);
	static inline void FreeVENode(Vh vh);
	inline bool& Flag() { return m_bFlag; } 
	inline int&  PeakIdentifier() { return m_nPeakIdentifier; }
private:
	bool m_bFlag;
	int  m_nPeakIdentifier;
};

template<class Tn>
void CVertexEdgeNode_2<Tn>::AddEdgeWith(Vh vh)
{	push_back(vh);	}

template<class Tn>
void CVertexEdgeNode_2<Tn>::RemoveEdgeWith(Vh vh)
{
	for ( iterator i = begin(); i != end(); )
		if ( *i == vh )		{	iterator r = i;	++i; erase(r);	}
		else				++i;
}

template<class Tn>
bool CVertexEdgeNode_2<Tn>::IsEdgeWith(Vh vh)
{
	for ( iterator i = begin(); i != end(); ++i )
		if ( *i == vh )		return true;
	return false;
}

template<class Tn>
CVertexEdgeNode_2<Tn>::Self* CVertexEdgeNode_2<Tn>::GetAllocVENode(Vh vh)
{
	void*& vp =	vh->info().VoidPtr();
	if ( !vp )	vp = new Self;
	return (Self*)vp;
}

template<class Tn>
CVertexEdgeNode_2<Tn>::Self* CVertexEdgeNode_2<Tn>::GetVENode(Vh vh)
{	return (Self*)(vh->info().VoidPtr());	}

template<class Tn>
void CVertexEdgeNode_2<Tn>::FreeVENode(Vh vh)
{
	Self*& p = (Self*&)(vh->info().VoidPtr());
	if ( p ) {	delete p; p = NULL; }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tni>	class CViolatorPoint;
template<class Tn>
class CVBe_2
{// Vertex to Vertex Edge -> Edge represented by two handles to vertices
typedef Tn::Geom_traits			Gt;
typedef Tn::Point				Point;
typedef Tn::Edge				Edge;
typedef Tn::Segment				Segment;
typedef Tn::Vertex_handle		Vh;
typedef Tn::Face_handle			Cell_handle;
typedef CVertexEdgeNode_2<Tn>	VENode;
typedef pair<Vh,Vh>				LVBe; //light-VBe; 

public:
	CVBe_2();
	CVBe_2(Vh vh1, Vh vh2);
	CVBe_2(LVBe e);
	CVBe_2(Edge e);
	Vh v0() { return vh0; }
	Vh v1() { return vh1; }
	operator Segment()  { return Segment(vh0->point(), vh1->point()); };

	inline void Mount();
	inline void Unmount();
	inline bool IsViolated(Point cc);
	inline bool IsBorderElement();
	inline bool IsPeakEdge();
	inline bool IsEncroached(Tn* pTn);
	inline bool IsInTn(Tn* pTn);
	static inline bool IsViolated(Point a, Point b, Point cc);

private:
	Vh vh0, vh1;
};

template <class Tn>
CVBe_2<Tn>::CVBe_2()
{
	vh0 = vh1 = NULL;
}

template <class Tn>
CVBe_2<Tn>::CVBe_2(Vh _vh0, Vh _vh1)
{
	vh0 = _vh0;	vh1 = _vh1;
}

template <class Tn>
CVBe_2<Tn>::CVBe_2(Edge e)
{			 
	vh0 = e.first->vertex(e.first->cw(e.second)); 
	vh1 = e.first->vertex(e.first->ccw(e.second));
}

template <class Tn>
CVBe_2<Tn>::CVBe_2(LVBe e)
{			 
	vh0 = e.first;	vh1 = e.second;	
}

template <class Tn>
void CVBe_2<Tn>::Mount()
{
	VENode::GetAllocVENode(vh0)->AddEdgeWith(vh1);
	VENode::GetAllocVENode(vh1)->AddEdgeWith(vh0);
}

template <class Tn>
void CVBe_2<Tn>::Unmount()
{
	VENode::GetVENode(vh0)->RemoveEdgeWith(vh1);
	VENode::GetVENode(vh1)->RemoveEdgeWith(vh0);
}

template <class Tn>
bool CVBe_2<Tn>::IsViolated(Point a, Point b, Point cc)
{
	return Gt::Circle_2(a, b).oriented_side(cc) == ON_POSITIVE_SIDE;
}

template <class Tn>
bool CVBe_2<Tn>::IsViolated(Point cc)
{
	return IsViolated(vh0->point(), vh1->point(), cc);
}

template <class Tn>
bool CVBe_2<Tn>::IsBorderElement()
{
	VENode *ven0 = VENode::GetVENode(vh0), *ven1 = VENode::GetVENode(vh1);
	return ven0 && ven1 ? ven0->IsEdgeWith(vh1) : false;
}

template<class Tn>
bool CVBe_2<Tn>::IsPeakEdge()
{
	int a = VENode::GetVENode(vh0)->PeakIdentifier();
	if ( a == -1 ) return false;
	int b = VENode::GetVENode(vh1)->PeakIdentifier();
	if ( b == -1 ) return false;

	return a == b;
}

template <class Tn>
bool CVBe_2<Tn>::IsInTn(Tn* pTn)
{
	return pTn->is_edge(vh0, vh1);
}

template <class Tn>
bool CVBe_2<Tn>::IsEncroached(Tn* pTn)
{
	Cell_handle fh1, fh2;
	int i, j;
	if ( !pTn->is_edge(vh0, vh1, fh1, i) )
		return true;

	if ( !pTn->is_infinite(fh1) )
		if ( IsViolated( fh1->vertex(i)->point() ) )
			return true;	
	fh2 = fh1->neighbor(i);
	if ( !pTn->is_infinite(fh2) )
	{
		j = fh2->index(fh1);	
		if ( IsViolated( fh2->vertex(j)->point() ) )
			return true;
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_BREAKINGEDGE_2_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_)


