// IsoValue_2.h: interface for the CIsoValue_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IsoValue_2_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
#define AFX_IsoValue_2_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_

#include "IsoValue_d.h"

template <class Err,class AIv,class Pro>
class CIsoValue_2  : public CIsoValue_d<Err,AIv,Pro>
{
public:
typedef typename CIsoValue_d<Err,AIv,Pro>	Parent;
typedef typename Err::Tni				Tni;
typedef typename Tni::IT				IT;	
typedef typename Tni::Img				Img;	
typedef typename CPGMWriter<Img>		PGMWriter;	
public:
	void TestImg();
	void ReadParams();
};

template <class Err,class AIv,class Pro>
void CIsoValue_2<Err,AIv,Pro>::ReadParams()
{
	AutoIv();
	TestImg();
	Parent::ReadParams();
}

template <class Err,class AIv,class Pro>
void CIsoValue_2<Err,AIv,Pro>::TestImg()
{
	if ( !U_BEGIN_PROC_ASK(img-isovalue-test) )
		return;

	double iso_value;
	FT x,y;
	int i, j, a, b, v1, v2, *vmin, *vmax;
	
	IT::RectangleI_2 r = m_pImg->RectI();
	Img iimg(*m_pImg);
//	iimg.Resize(m_pImg->XMax(), m_pImg->YMax());
	(*m_pWs)<<*m_pImg;
	do
	{
		cout<<"\niso_value: "; cin>>iso_value;
		for ( i = r.xmin(); i <= r.xmax(); i++ )
			for ( j = r.ymin(); j <= r.ymax(); j++ )
				iimg(i, j) = 0;
	
		for ( i = r.xmin()+1; i <= r.xmax()-1; i++ )
			for ( j = r.ymin()+1; j <= r.ymax()-1; j++ )
				for ( a = i-1; a <= i+1; a++ )
					for ( b = j-1; b <= j+1; b++ )
					{
						if ( a == b ) 
							continue;
						v1 = (int)((*m_pImg)(i,j));
						v2 = (int)((*m_pImg)(a,b));
						if ( v1 <= v2 )	{	vmin = &v1; vmax = &v2; }
						else			{	vmin = &v2; vmax = &v1; }
						if ( *vmin <= iso_value && iso_value <= *vmax )
						{
							x = (i+a)/2.0;	y = (j+b)/2.0;
							iimg((int)x, (int)y) = 255;
						}
					}
				
		m_pWs->clear();
		(*m_pWs)<<iimg;
		//PGMWriter wr(&iimg);
		//wr.Write("xxx.pgm");
	}while( ! U_OK_ASK2("ok") );
}

#endif // !defined(AFX_IsoValue_2_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)



