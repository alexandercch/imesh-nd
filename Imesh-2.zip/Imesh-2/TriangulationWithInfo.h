// TriangulationWithInfo.h: interface for the CTriangulationWithInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRIANGULATIONWITHINFO_H__BFB04C6E_D0D8_4A46_A9F7_90C831ED2CAC__INCLUDED_)
#define AFX_TRIANGULATIONWITHINFO_H__BFB04C6E_D0D8_4A46_A9F7_90C831ED2CAC__INCLUDED_

////////////////////////////////////////////////////////////////////////////////////////////////

template <class _VertexInfo>
class CVertexWithInfo : public CGAL::Triangulation_vertex_base_2<_VertexInfo::Gt>
{
public:
	inline _VertexInfo& info()			{	return _info;	};
	inline _VertexInfo* operator->()	{	return &_info;	};
private:	
	_VertexInfo _info;
};

template <class _FaceInfo>
class CFaceWithInfo : public CGAL::Triangulation_face_base_2<_FaceInfo::Gt>
{
public:
	inline _FaceInfo& info()		{	return _info;	};
	inline _FaceInfo* operator->()	{	return &_info;	};
private:	
	_FaceInfo _info;
};

////////////////////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_TRIANGULATIONWITHINFO_H__BFB04C6E_D0D8_4A46_A9F7_90C831ED2CAC__INCLUDED_)