// PointNearest_d.h: interface for the CPointNearest_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PointNearest_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_)
#define AFX_PointNearest_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_

#include "PointSelector_d.h" 

template <class PD>
class CPointNearest_d  : public CPointSelector_d<PD>
{
public:
typedef typename CPointSelector_d<PD>	Parent;
typedef typename PD::Tni				Tni;
typedef typename Tni::Tn				Tn;
typedef typename Tni::Ch				Ch;
typedef typename Tni::FT				FT;
typedef typename Tn::Point				Point;
typedef typename Tni::Mat				Mat;
typedef typename PD::PrePoint			PrePoint;
										
public:
	inline void SetCurrCell(Ch ch);
	inline bool operator()(PrePoint c);
private:	
	Point m_GoalPoint;
	FT m_NearestDistance;
};

template <class PD>
void CPointNearest_d<PD>::SetCurrCell(Ch ch)
{
	Parent::SetCurrCell(ch);
	m_GoalPoint = m_pTn->dual(ch);
	m_NearestDistance = Mat::MaxDouble(); 
}

template <class PD>
inline bool CPointNearest_d<PD>::operator()(PrePoint c)
{
	FT dist = /*::sqrt(*/squared_distance(c, m_GoalPoint)/*)*/;
	if ( dist < m_NearestDistance )
	{
		m_bSelectedCoord = true;
		m_NearestDistance = dist;
		m_SelectedCoord = c;
		return true;
	}
	return false;
}

#endif // !defined(AFX_PointNearest_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_)
