// Mat_d.h: interface for the CMat_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Mat_d_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)
#define AFX_Mat_d_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_

template <class FT, class INT>
class CMat_d
{
public:
	static inline const FT PI()
	{	return 3.1415926535897932384626433832795;	}
	static inline FT RadiansToDegrees(FT ang)
	{	return ang*180/PI(); }
	static inline FT DegreesToRadians(FT ang)
	{	return ang*PI()/180; }
	static inline FT MaxDouble() 
	{	return 1.7E+308;	}
	static inline INT MaxInt32() 
	{	return 2147483647;	}
	static inline FT Round(FT x) 
	{ return (FT)(INT)(x+0.5); }
};

#endif // !defined(AFX_Mat_d_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)