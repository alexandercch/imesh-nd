// VBeGroup_2.h: interface for the BreakingEdge_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VBeGroup_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_)
#define AFX_VBeGroup_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_

#include "VBe_2.h"
#include "Writer_2.h"

template<class Tni>
class CVBeGroup_2
{
public:
typedef Tni						Tni;
typedef CWriter_2<Tni>			Writer;
typedef Tni::Tn					Tn;
typedef Tni::Img				Img;
typedef Tn::Geom_traits			Gt;
typedef Gt::FT					FT;
typedef Tn::Vertex_handle		Vh;
typedef Tn::Face_handle			Cell_handle;
typedef Tn::Segment				Segment;
typedef Tn::Point				Point;
typedef CVertexEdgeNode_2<Tn>	VENode;
typedef CVBe_2<Tn>				VBe;
typedef pair<Vh,Vh>				LVBe; //light-VBe; 
typedef list<LVBe>				LVBe_list;

public:
	
	CVBeGroup_2();
	~CVBeGroup_2();
	void Init(Tn* pTn, Img* pImg, Writer* w, Window_stream* ws);
	void LoadInTnFromSegmentation();
//	void LoadEdgesInTnFromBorderDetector();
//	void TestBorderRestriction(Window_stream* ws, Writer* w);
	void LoadEdgesFromTnInList();
	void RecoverEncroachedEdges();
	void InitBordesEdgesForWalk();
	void AssertValidInTn();
	void Draw(Window_stream* ws, bool bLoad, bool bClear, bool bCirlcles);
	bool IsLoad() { return m_bLoad; }
	LVBe_list* List() { return &m_LVBe_list; }
	void Clear();
	inline LVBe_list* operator->();

private:
	Tn* m_pTn;
	bool m_bLoad;
	Writer* m_w;
	LVBe_list m_LVBe_list;
};

template <class Tni>
CVBeGroup_2<Tni>::CVBeGroup_2()
{	m_pTn = NULL;
	m_bLoad = false;
}

template <class Tni>
CVBeGroup_2<Tni>::~CVBeGroup_2()
{	Clear();	}

template <class Tni>
void CVBeGroup_2<Tni>::Init(Tn* pTn, Img* pImg, Writer* w, Window_stream* ws)
{	m_pTn = pTn;	m_w = w;	
}

template <class Tni>
void CVBeGroup_2<Tni>::Clear()
{
	Tn::Finite_vertices_iterator vi;
	for ( vi = m_pTn->finite_vertices_begin(); vi != m_pTn->finite_vertices_end();  ++vi )
		VENode::FreeVENode(vi);
	m_LVBe_list.clear();
}

template <class Tni>
inline CVBeGroup_2<Tni>::LVBe_list* CVBeGroup_2<Tni>::operator->()
{	return &m_LVBe_list;	}

template <class Tni>
void CVBeGroup_2<Tni>::LoadInTnFromSegmentation()
{
	Tn::Finite_edges_iterator ei;
	Cell_handle ch1, ch2;
	Vh v1, v2;
	int i;
	Clear();
	for ( ei = m_pTn->finite_edges_begin(); ei != m_pTn->finite_edges_end();  ++ei )
	{
		ch1 = ei->first;
		i = ei->second;
		ch2 = ch1->neighbor(i);
		if ( m_pTn->is_infinite(ch1) || m_pTn->is_infinite(ch2) ||
			 ch1->info().Region() != ch2->info().Region() )
		{
			VBe edge(ch1->vertex((i+1)%3), ch1->vertex((i+2)%3));
			edge.Mount();
			m_LVBe_list.push_back(LVBe(edge.v0(), edge.v1()));
		}
	}
	m_bLoad = true;
}

template <class Tni>
void CVBeGroup_2<Tni>::RecoverEncroachedEdges()
{
	U_BEGIN_SUB_PROC_T_(Recover-Encroached);	
	LoadEdgesFromTnInList();
	LVBe_list::iterator i;
	bool b;
	do
	{
		b = true;		
		for ( i = m_LVBe_list.begin(); i != m_LVBe_list.end(); )
		{
			VBe e(*i);
			if ( e.IsEncroached(m_pTn) )
			{
				b = false;
				e.Unmount();
				Point middle(	(e.v0()->point().x() + e.v1()->point().x() ) / (FT)(2),
								(e.v0()->point().y() + e.v1()->point().y() ) / (FT)(2) );
				Vh mvh = m_pTn->insert(middle, e.v0()->face());
				VBe  e1(e.v0(), mvh), e2(mvh, e.v1());
				e1.Mount();	e2.Mount();
				
				m_LVBe_list.push_back(LVBe(e1.v0(), e1.v1())); 
				m_LVBe_list.push_back(LVBe(e2.v0(), e2.v1())); 
				
				LVBe_list::iterator del = i;
				++i;
				m_LVBe_list.erase(del);
			}
			else	++i;
		}
		if ( !b ) printf("~");
		printf("|");
	}while(!b);
	U_END_SUB_PROC_T_E;
}

/*template <class Tni>
void CVBeGroup_2<Tni>::LoadEdgesInTnFromBorderDetector()
{
	U_BEGIN_PROC(mesh-restriction);

	Clear();
	Tn::Finite_edges_iterator ei;
	Mbd::EMeshBorder bMeshBorder;
	Cell_handle ch;
	int i;

	m_pMbd->ReadParams();

	for(ei = m_pTn->finite_edges_begin(); ei != m_pTn->finite_edges_end(); ++ei) 
	{
		ch = ei->first;
		i = ei->second;
		bMeshBorder = (*m_pMbd)(*ei);
		if ( bMeshBorder == Mbd::be_border )
		{
			VBe edge(ch->vertex((i+1)%3), ch->vertex((i+2)%3));
			edge.Mount();
			m_LVBe_list.push_back(LVBe(edge.v0(), edge.v1()));
		}
	}
}*/

template <class Tni>
void CVBeGroup_2<Tni>::LoadEdgesFromTnInList()
{
	//Nodes initialization to walk
	Tn::Finite_vertices_iterator fvi;
	VENode *pNode, *pNodeLink;
	for ( fvi = m_pTn->finite_vertices_begin(); fvi != m_pTn->finite_vertices_end(); ++fvi )
	{
		pNode = VENode::GetVENode(fvi);
		if ( pNode )
			pNode->Flag() = false;
	}

	//Loading VBes
	m_LVBe_list.clear();
	VENode::iterator ni;
	for ( fvi = m_pTn->finite_vertices_begin(); fvi != m_pTn->finite_vertices_end(); ++fvi )
	{
		pNode = VENode::GetVENode(fvi);
		if ( pNode )
		{
			pNode->Flag() = true;
			for ( ni = pNode->begin(); ni != pNode->end(); ++ni )
			{
				pNodeLink = VENode::GetVENode(*ni);
				if ( !pNodeLink->Flag() )
				{
					m_LVBe_list.push_back(LVBe(fvi, *ni));			
				}
			}
		}
	}
}

template <class Tni>
void CVBeGroup_2<Tni>::AssertValidInTn()
{
	LoadEdgesFromTnInList();
	for ( LVBe_list::iterator i = m_LVBe_list.begin(); i != m_LVBe_list.end(); ++i )
		if ( ! VBe(*i).IsInTn(m_pTn) )
			printf("!e");
}

template <class Tni>
void CVBeGroup_2<Tni>::Draw(Window_stream* ws, bool bLoad, bool bClear, bool bCircles)
{
	if ( bLoad )	LoadEdgesFromTnInList();
	if ( bClear )	ws->clear();

	ws->set_fill_color(invisible);
	ws->set_color(green);
	*ws<<*m_pTn;

	ws->set_color(blue);
	ws->set_line_width(2);
	LVBe_list::iterator i;
	for ( i = m_LVBe_list.begin(); i != m_LVBe_list.end(); ++i )
		*ws<<Segment(i->first->point(), i->second->point());
	
	ws->set_line_width(1);
	if ( bCircles )
	{
		ws->set_color(orange);
		for ( i = m_LVBe_list.begin(); i != m_LVBe_list.end(); ++i )
			*ws<<Gt::Circle_2(i->first->point(), i->second->point());
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_VBeGroup_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_)

/*
template <class Tni>
void CVBeGroup_2<Tni>::TestBorderRestriction(Window_stream* ws, Writer* w )
{
	U_BEGIN_PROC(mesh-restriction-test);

	Mbd::EMeshBorder bMeshBorder;
	Tn::Finite_faces_iterator fi;
	Tn::Finite_edges_iterator ei;
	do
	{
		cout<<"\n- - - - -";
		m_pMbd->ReadParams();
		w->UnselectAllSegments();
		ws->clear();
		
		//gray mesh
		for(fi = m_pTn->finite_faces_begin(); fi != m_pTn->finite_faces_end(); ++fi)
		{	
			double g = fi->info().Pattern();
			ws->set_fill_color(color(g,g,g));
			ws->set_color(color(g,g,g));
			*ws<<m_pTn->triangle(fi);
		}

		//edges
		ws->set_color(green);
		ws->set_line_width(2);
		for(ei = m_pTn->finite_edges_begin(); ei != m_pTn->finite_edges_end() ; ++ei) 
		{
			bMeshBorder = (*m_pMbd)(*ei);
			if ( bMeshBorder == Mbd::be_border )
			{
				w->SelectSegment(m_pTn->segment(ei));
				*ws<<m_pTn->segment(ei);
			}
		}
		w->Refresh();
	}while( ! U_OK_ASK2("ok") );
	m_pMbd->Clear();
}
*/

