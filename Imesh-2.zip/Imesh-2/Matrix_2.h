// Matrix_2.h: interface for the CMatrix_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATRIX_H__C79359DF_1E08_49C2_B58E_A15A43E70E4A__INCLUDED_)
#define AFX_MATRIX_H__C79359DF_1E08_49C2_B58E_A15A43E70E4A__INCLUDED_

#include <vector>
using namespace std;

template <class _T, class IT>
class CMatrix_2  : public vector<_T>
{
public:
typedef typename CMatrix_2<_T, IT>		Self;
typedef typename IT						IntTraits;
typedef typename IT::INT				IndexType;
typedef typename IT::PointI_2			PointI_2;
typedef typename PointI_2				Coord;

	CMatrix_2(IndexType xmax = 0, IndexType ymax = 0);
	void Resize(IndexType XMax, IndexType YMax);
	inline _T& operator()(IndexType x, IndexType y);
	inline _T& operator()(Coord p);
	inline void SetWith(_T e);
	inline IndexType XMax();
	inline IndexType YMax();

protected:
	IndexType m_XMax, m_YMax;
};

template <class _T, class IT>
CMatrix_2<_T,IT>::CMatrix_2(IndexType xmax, IndexType ymax)
{	Resize(xmax, ymax);		}

template <class _T, class IT>
void CMatrix_2<_T,IT>::Resize(IndexType XMax, IndexType YMax)
{
	m_XMax = XMax;	m_YMax = YMax;
	resize(m_XMax*m_YMax);
}

template <class _T, class IT>
inline void CMatrix_2<_T,IT>::SetWith(_T e)
{
	for ( iterator z = begin(); z != end(); ++z ) 
		*z = e;
}

template <class _T, class IT>
inline _T& CMatrix_2<_T,IT>::operator()(IndexType x, IndexType y)
{	
	return vector<_T>::operator[](y*m_XMax +  x);		
}

template <class _T, class IT>
inline _T& CMatrix_2<_T,IT>::operator()(Coord p)
{	return vector<_T>::operator[](p.y()*m_XMax +  p.x());		}

template <class _T, class IT>
inline CMatrix_2<_T,IT>::IndexType CMatrix_2<_T,IT>::XMax()
{	return m_XMax;		}

template <class _T, class IT>
inline CMatrix_2<_T,IT>::IndexType CMatrix_2<_T,IT>::YMax()
{	return m_YMax;		}

#endif // !defined(AFX_MATRIX_H__C79359DF_1E08_49C2_B58E_A15A43E70E4A__INCLUDED_)