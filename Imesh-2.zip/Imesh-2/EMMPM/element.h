/**
  element.h
  CEMMPM element definition class library
  nov/2005
  Leandro Cavaleri Gerhardinger
**/
#ifndef ELEMENT_H
#define ELEMENT_H


#include "define.h"



/** structure for one pixel, triangule or whatever **/
typedef struct TElem_
{
  int y; // graylevel (0..GRAYLEVELS-1)
  int x; // label (0..L-1)
  
  TElem_ **neighbor; // array of neighbors index
  int nn;            // number of neighbors
  
  // for multiresolution only
  TElem_ *m_neighbor; // coarser resolution neighbor
  
  // auxiliar variables
  float *time; // time that the element was on label k after one iteration
  
  // geometrical parameters for each neighbor
  float *neighbor_edge;
  
  float area; // geometrical area value
  
} TEMMPMElem;



/** class that helps to mount a TEMMPMElem structure **/
class CElements
{
  public:
    /** Elements **/
    TEMMPMElem **element; // array of elements for each resolution (FER)
    int         *N;       // number of elements FER
    
    
    /** Auxiliar variables - Image **/
    unsigned char **img;        // graylevel FER
    unsigned char **img_labels; // label map FER
    int **img_elem; // gives element index by image index FER
    int **elem_img; // gives image index by element index FER
    int **img_GR;   // gives coarser resolution neighbor FER
    int  *img_N;    // number of pixels in image FER
    int  *img_w;    // width FER
    int  *img_h;    // heidth FER
    int   img_res;  // number of resolutions
    
    
    /** Methods - Image **/
    // constructor by image
    // (*img, w, h, g, L, min, max, img_res)
    CElements(unsigned char *, int, int, int, int, int, int, int);
    
    // getLabels - get pixels label
    // (resolution)
    unsigned char *getLabels(int);
    
    // destructor
    ~CElements();
};
#endif
