/**
  label.h
  CEMMPM label parameters definition class library
  nov/2005
  Leandro Cavaleri Gerhardinger
 **/
#ifndef LABEL_H
#define LABEL_H


#include "define.h"



/** class for the label parameters **/
class CLabelParameters
{
  public:
    /** Parameters **/
    float mu;     // mean
    float sigma2; // variance
    
    
    /** Auxiliar variables **/
    float term1;             // 1/sqrt(2*PI*sigma2)
    float term2[GRAYLEVELS]; // -(y-mu)^2/2*sigma2, (y=0..GRAYLEVELS-1)
    
    
    /** Methods **/
    // CLabel - constructor
    // (mu. sigma)
    CLabelParameters(float, float);
    CLabelParameters(){};
    
    // set - set parameters
    // (mu. sigma)
    void set(float, float);
    
    
    /** Multiresolution **/
    float a1;       // autoregressive parameter for previous pixel
    float a2;       // autoregressive parameter for coaser pixel
    float term3;    // mu*(1 + a1 + a2)
    float sigma2x2; // sigma2*2
    
    // CLabel - constructor
    // (mu. sigma, a1, a2)
    CLabelParameters(float, float, float, float);
    
    // m_set - set parameters for multiresolution
    // (mu, sigma, a1, a2)
    void m_set(float, float, float, float);
};
#endif
