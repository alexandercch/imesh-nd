/**
  define.h
  EM/MPM constants and rands declaration
  nov/2005
  Leandro Cavaleri Gerhardinger
**/
#ifndef DEFINE_H
#define DEFINE_H



#define TWOPI 6.2831852
#define GRAYLEVELS 256
#define RANDS 14121977
#define RANDOM ((rands *= 134775813)/4294967296.0)
#define SIGMA2 700
#define MAXNEIGHBORS 8



static unsigned int rands = RANDS;  // for linear randomize

#endif
