/**
  emmpm.cpp
  EM/MPM "element" segmentation class implementation
  nov/2005
  Leandro Cavaleri Gerhardinger
**/

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include "emmpm.h"
using namespace std;

/** run - iterates once
**/
void CEMMPM::run()
{
  if (levels==1){ // one resolution
    MPM(); // calcule X and P_Xs|Y_(k|y,theta)
    EM();  // estime theta by P_Xs|Y_(k|y,theta)
  }else{ // multiresolution
    M_MPM();
    M_EM();
  }
  
  // annealing
  if (annealing>0.)
    Annealing();
}


/** MPM - Maximization of the Posterior Marginal: segment the elements
**/
void CEMMPM::MPM()
{
#define MPM_VARIABLES\
  int s, t, k, g, y, nn;\
  float z, acpmf, random, *aux;\
  TEMMPMElem *current, **neighbor;\
  CLabelParameters *label;
  MPM_VARIABLES;
  
  // initialize P_Xs|Y_(k|y,theta)
#define MPM_INITIALIZE_PIXEL_TIME\
  for (s=0; s<N; s++)\
    for (k=0; k<L; k++)\
      element[s].time[k] = 0.;
  MPM_INITIALIZE_PIXEL_TIME;
  
  // initialize cpmf_arr
#define MPM_INITIALIZE_CPMF_ARR\
  for (k=0; k<L; k++)\
    for (y=0; y<GRAYLEVELS; y++)\
      for (g=0; g<MAXNEIGHBORS+1; g++)\
        cpmf_arr[k][y][g] = -1.;
  MPM_INITIALIZE_CPMF_ARR;
  
  for (t=0; t<T; t++){ // visit each element once
    for (s=0; s<N; s++){ // visit one element
      // get element properties
#define MPM_ELEMENT_PROPERTIES\
      current  = &element[s];\
      y        = current->y;\
      neighbor = current->neighbor;\
      nn       = current->nn;
      MPM_ELEMENT_PROPERTIES;
      
      // count different neighbors number if k=0..L-1 (dnn)
#define MPM_COUNT_DIFFERENT_NEIGHBORS\
      for (k=0; k<L; k++) dnn[k] = nn;\
      for (g=0; g<nn; g++)\
        dnn[neighbor[g]->x]--;
      MPM_COUNT_DIFFERENT_NEIGHBORS;
      
      // calculate the cpmf (condicional probability mass function)
      // that indicates the probability of the current element be the
      // label k giving y and theta, with k=0..L-1
      // P_Xs|Y,Xg,g=neighborsOfS,theta_(k|y,xg,theta)
      // z is the normalization factor
#define MPM_CPMF_CALCULATE\
      for (z=0, k=0; k<L; k++){\
        aux = cpmf_arr[k][y] + dnn[k];\
        if (*aux<0.){\
          label = theta + k;\
          *aux = label->term1*exp(label->term2[y] - beta_x_dnn[dnn[k]]);\
        }\
        z += cpmf[k] = *aux;\
      }
      MPM_CPMF_CALCULATE;
      
      // generates the new label k for the current element randomicaly
      // with the mcpf just calculated by examining the accumulated mcpf
#define MPM_GENERATES_FROM_CPMF\
      k=0;\
      acpmf = cpmf[0];\
      random = RANDOM*z;\
      while (random>acpmf)\
        acpmf += cpmf[++k];\
      current->x = k;\
      current->time[k] += 1;
      MPM_GENERATES_FROM_CPMF;
    }
  }
}


/** M_MPM - Multiresolution MPM algorithm
**/
void CEMMPM::M_MPM()
{
  MPM_VARIABLES;
  int r, m_x, p_y, m_y;
  TEMMPMElem *m_neighbor;
  
  // initialize cpmf_arr and pixels time
  for (r=levels-1; r>=0; r--){
    element = m_element[r];
    N       = m_N[r];
    if (r==levels-1) MPM_INITIALIZE_CPMF_ARR;
    MPM_INITIALIZE_PIXEL_TIME;
  }
  
  for (t=0; t<T; t++){ // visit each element once
    for (r=levels-1; r>=0; r--){ // visit each resolution once
      element = m_element[r];
      N       = m_N[r];
      theta   = m_theta[r];
      
      if (r==levels-1){ // coarsest resolution, normal MPM
        for (s=0; s<N; s++){ // visit one element
          MPM_ELEMENT_PROPERTIES;
          MPM_COUNT_DIFFERENT_NEIGHBORS;
          MPM_CPMF_CALCULATE;
          MPM_GENERATES_FROM_CPMF;
        }
      }else{ // finer resolutions, multiresolution MPM
        // initialize previous pixel gray-level
        p_y = m_element[levels-1][m_N[levels-1]-1].y;
        
        for (s=0; s<N; s++){ // visit one element
          MPM_ELEMENT_PROPERTIES;
          m_neighbor = current->m_neighbor;
          m_y        = m_neighbor->y;
          m_x        = m_neighbor->x;
          
          MPM_COUNT_DIFFERENT_NEIGHBORS;
          for (k=0; k<L; k++) dnn[k] = nn;
            for (g=0; g<nn; g++)
              dnn[neighbor[g]->x]--;
                
          // verify the upper neighbor label
          for (k=0; k<L; k++)
            alfa_x_dnn[k] = alfa;
          alfa_x_dnn[m_x] = 0.;
          
          // calculate the cpmf
/*          for (z=0, k=0; k<L; k++){
            label = theta + k;
            y_ = label->term3 + y + label->a1*p_y + label->a2*m_y;
            z += cpmf[k] =
              label->term1*
                exp(
                  -pow(y_,2.)/label->sigma2x2)
                  -beta_x_dnn[dnn[k]]
                  -alfa_x_dnn[k]
                );
          }*/
          for (z=0, k=0; k<L; k++){
            label = theta + k;
            z += cpmf[k] =
              label->term1*exp(
                 label->term2[y]
                -beta_x_dnn[dnn[k]]
                -alfa_x_dnn[k]
              );
          }
          
          MPM_GENERATES_FROM_CPMF;
          
          // get next
          p_y = y;
        }
      }
    }
  }
}


/** M_MPM - MPM algorithm with geometrical issues
 **/
void CEMMPM::MPM_Geometrical_1()
{
  int s, t, k, g, y, nn;
  float z, acpmf, random;
  TEMMPMElem *current, **neighbor;
  CLabelParameters *label;

  float *edge;
  
  MPM_INITIALIZE_PIXEL_TIME;
  
  for (t=0; t<T; t++){ // visit each element once
    for (s=0; s<N; s++){ // visit one element
      MPM_ELEMENT_PROPERTIES;
      edge = current->neighbor_edge;
      
      // count different neighbors distance
      for (k=0; k<L; k++) f_dnn[k] = 1.;
      for (g=0; g<nn; g++)
        f_dnn[neighbor[g]->x] -= edge[g];
      
      // cpmf calculate
      for (z=0, k=0; k<L; k++){
        label = theta + k;
        z += cpmf[k] = label->term1*exp(label->term2[y] -beta*f_dnn[k]*nn);
      }
      
      MPM_GENERATES_FROM_CPMF;
    }
  }
}


/** EM - Expectation Maximization: estime label parameters
**/
void CEMMPM::EM()
{
  int k, s;
  float mu, sigma2, aux1, aux2, aux3;
  TEMMPMElem *current;
  
  for (k=0; k<L; k++){
    // mean calculation (mu)
    aux2 = 0;
    aux3 = 0;
    for (s=0; s<N; s++){
      current = &element[s];
      aux1 = current->time[k];
      aux2 += current->y*aux1;
      aux3 += aux1;
    }
    mu = aux2/aux3;
    
    // variance calcutation (sigma2)
    aux2 = 0;
//    aux3 = 0;
    for (s=0; s<N; s++){
      current = &element[s];
      aux1 = current->time[k];
      aux2 += pow(current->y-mu,2)*aux1;
//      aux3 += aux1;
    }
    sigma2 = aux2/aux3;
    if (sigma2<=80.)
      sigma2 = 80.;
    
     theta[k].set(mu,sigma2);
  }
}


/** M_EM - Multiresolution EM algorithm
 **/
void CEMMPM::M_EM()
{
  int r;
  
  for (r=levels-1; r>=0; r--){
    element = m_element[r];
    N       = m_N[r];
    theta   = m_theta[r];
    
    EM();
  }
}


/** EM_Geometrical - EM algorithm with geometrical issues
 **/
void CEMMPM::EM_Geometrical()
{
  int k, s;
  TEMMPMElem *current;
  
  for (k=0; k<L; k++){
    for (s=0; s<N; s++){
      current = &element[s];
      current->time[k] *= current->area;
    }
  }
  
  EM();
}


/** Annealing - cools the system
 **/
void CEMMPM::Annealing()
{
  int n;
  
  // increases beta
  beta += annealing;
  if (beta>beta_max)
    beta = beta_max;
  
  // set auxiliar parameter
  for (n=0; n<MAXNEIGHBORS+1; n++)
    beta_x_dnn[n] = beta*n;
}


/** CEMMPM - contructor
  @param TEMMPMElem *elem_: array of elements
  @param int         N_   : number of elements
  @param int         L_   : number of labels
  @param float       beta_: spacial interaction parameter
  @param float       annea: increases beta parameter
  @param float       betam: maximum beta value
  @param int            T_: visits per pixel for each iteration
**/
CEMMPM::CEMMPM
  (TEMMPMElem *elem_, int N_, int L_, float beta_, float annea, float betam, int T_)
{
  int s, k, y;

  // set variables and parameters
  element = elem_;
  N       = N_;
  L       = L_;
  levels  = 1;
  
  beta      = beta_;
  annealing = annea;
  beta_max  = betam;
  
  T = T_;
  
  // allocation
  theta = new CLabelParameters[L];
  dnn   = new int[L];
  cpmf  = new float[L];
  f_dnn = new float[L];
  
  for (s=0; s<N; s++)
    element[s].time = new float[L];
  
  cpmf_arr = new float**[L];
  for (k=0; k<L; k++){
    cpmf_arr[k] = new float*[GRAYLEVELS];
    for (y=0; y<GRAYLEVELS; y++)
      cpmf_arr[k][y] = new float[MAXNEIGHBORS+1];
  }
  
  // initialize theta
  for (k=0; k<L; k++)
    theta[k].set((255.*k)/(float)L + 128./(float)L, SIGMA2);
  
  // initialize beta_x_dnn
  beta -= annealing;
  Annealing();
}


/** CEMMPM - contructor (multiresolution)
  @param TEMMPMElem **elem_: array of array of elements
  @param int         *N_   : array of number of elements
  @param int          lev_ : number of levels
  @param int          L_   : number of label
  @param float        beta_: spacial interaction parameter
  @param float        annea: increases beta parameter
  @param float        betam: maximum beta value
  @param float        alfa_: multiresolution interaction parameter
  @param int            T_: visits per pixel for each iteration
 **/
CEMMPM::CEMMPM
    (TEMMPMElem **elem_, int *N_, int lev_, int L_, float beta_, float annea, float betam, float alfa_, int T_)
{
  int r, s, k, y;

  // set variables and parameters
  m_element = elem_;
  m_N       = N_;
  levels    = lev_;
  L         = L_;
  
  beta      = beta_;
  annealing = annea;
  beta_max  = betam;
  alfa      = alfa_;
  
  T = T_;
  
  // allocation
  m_theta = new CLabelParameters*[levels];
  for (r=levels-1; r>=0; r--)
    m_theta[r] = new CLabelParameters[L];
  
  dnn = new int[L];
  cpmf = new float[L];
  alfa_x_dnn = new float[L];
  
  for (r=levels-1; r>=0; r--)
    for (s=0; s<m_N[r]; s++)
      m_element[r][s].time = new float[L];
  
  cpmf_arr = new float**[L];
  for (k=0; k<L; k++){
    cpmf_arr[k] = new float*[GRAYLEVELS];
    for (y=0; y<GRAYLEVELS; y++)
      cpmf_arr[k][y] = new float[MAXNEIGHBORS+1];
  }
  
  // initialize theta
  for (r=levels-1; r>=0; r--)
    for (k=0; k<L; k++)
      m_theta[r][k].set((255.*k)/(float)L + 128./(float)L, SIGMA2);

  // initialize beta_x_dnn
  beta -= annealing;
  Annealing();
}


/** ~CEMMPM - destructor
 **/
CEMMPM::~CEMMPM()
{
  int k, y;
  
  free(cpmf);
  free(dnn);
  if (levels==1)
    for (k=0; k<L; k++){
      for (y=0; y<GRAYLEVELS; y++)
        free(cpmf_arr[k][y]);
      free(cpmf_arr[k]);
    }
  free(cpmf_arr);
}


/** fileWithTheta - Make a file with theta values and distribuiton
  @param char[] filename: the file name
**/
void CEMMPM::fileWithTheta(char *filename)
{
  int k, s, y;
  float *kn, **hist;
  ofstream file;
  
  kn = new float[L];
  hist = new float*[L];
  for (k=0; k<L; k++) hist[k] = new float[GRAYLEVELS];
  
  file.open(filename, ofstream::out);
  
  // calcule histograms
  for (k=0; k<L; k++) kn[k] = 0.;
  for (s=0; s<N; s++) kn[element[s].x] += element[s].area;
  for (k=0; k<L; k++) for (y=0; y<GRAYLEVELS; y++) hist[k][y] = 0.;
  for (s=0; s<N; s++)
    hist[element[s].x][element[s].y] += element[s].area/kn[element[s].x];
  
  for (y=0; y<GRAYLEVELS; y++){
    for (k=0; k<L; k++){
      file << hist[k][y]                            << "\t"
           << theta[k].term1*exp(theta[k].term2[y]) << "\t"
           << theta[k].term2[y]                     << "\t";
    }
    file << endl;
  }
  
  // print mu and sigma2
  file << endl;
  for (k=0; k<L; k++)
    file << theta[k].mu << "\t";
  file << endl;
  for (k=0; k<L; k++)
    file << theta[k].sigma2 << "\t";
  
  file.close();
  
  free(kn);
  for (k=0; k<L; k++)
    free(hist[k]);
  free(hist);
}
