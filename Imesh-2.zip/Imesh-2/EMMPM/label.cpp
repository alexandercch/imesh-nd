/**
  label.cpp
  CEMMPM label parameters definition class implementation
  nov/2005
  Leandro Cavaleri Gerhardinger
**/



#include <math.h>
#include "label.h"



/** CLabelParameters - constructor
  @param float mu_    : mean
  @param float sigma2_: variance
 **/
CLabelParameters::CLabelParameters(float mu_, float sigma2_)
{
  set(mu_, sigma2_);
}


/** set - set parameters for one resolution
  @param float mu_    : mean
  @param float sigma2_: variance
 **/
void CLabelParameters::set(float mu_, float sigma2_)
{
  int y;
  
  // parameters
  mu = mu_;
  sigma2 = sigma2_;
  
  // auxiliar variables
  term1 = 1/sqrt(TWOPI*sigma2);
  sigma2x2 = 2*sigma2;
  for (y=0; y<GRAYLEVELS; y++)
    term2[y] = -pow(y-mu,2)/sigma2x2;
}


/** CLabelParameters - constructor (multiresolution)
  @param float mu_    : mean
  @param float sigma2_: variance
  @param float a1_    : autoregressive parameter for previous pixel
  @param float a2_    : autoregressive parameter for coaser pixel
 **/
CLabelParameters::CLabelParameters(float mu_, float sigma2_,
                                   float a1_, float a2_)
{
  m_set(mu_, sigma2_, a1_, a2_);
}


/** m_set - set parameters for one resolution (multiresolution)
  @param float mu_    : mean
  @param float sigma2_: variance
  @param float a1_    : autoregressive parameter for previous pixel
  @param float a2_    : autoregressive parameter for coaser pixel
 **/
void CLabelParameters::m_set(float mu_, float sigma2_,
                             float a1_, float a2_)
{
  // parameters
  mu = mu_;
  sigma2 = sigma2_;
  a1 = a1_;
  a2 = a2_;
  
  // auxiliar variables
  term1 = 1/sqrt(TWOPI*sigma2);
  sigma2x2 = sigma2*2.;
}
