/**
  element.cpp
  CEMMPM element definition class implementation
  nov/2005
  Leandro Cavaleri Gerhardinger
**/



#include <stdlib.h>
#include <stdio.h>
#include "element.h"



/** CElements - constructor by image
  @param unsigned_char *img_: array of pixels
  @param int            w   : width  of the image in pixels
  @param int            h   : heigth of the image in pixels
  @param int            g   : neighborhood (4 or 8)
  @param int            L   : number of labels
  @param int            min : minimum gray level
  @param int            max : maximum gray level
  @param int            res : number of resolutions
 **/
CElements::CElements
  (unsigned char *img_, int w, int h, int g, int L, int min, int max, int res)
{
  int r, u, i, s, j, x, y, s1, s2, s3, s4, gs, gcalc[8];
  TEMMPMElem *neighbor[8];
  
  // set variable
  img_res = res;
  
  // allocation
  element    = new         TEMMPMElem*[img_res];
  N          = new           int [img_res];
  img        = new unsigned char*[img_res];
  img_labels = new unsigned char*[img_res];
  img_elem   = new           int*[img_res];
  elem_img   = new           int*[img_res];
  img_N      = new           int [img_res];
  img_w      = new           int [img_res];
  img_h      = new           int [img_res];
  if (img_res>1) img_GR = new int*[img_res-1];
  
  // set finest resolution dimension and alloc
  img_N[0] = w*h;
  img_w[0] = w;
  img_h[0] = h;
  img[0]        = img_;
  img_labels[0] = new unsigned char[img_N[0]];
  img_elem  [0] = new           int[img_N[0]];
  if (img_res>1) img_GR    [0] = new           int[img_N[0]];
  
  // set coarser resolutions dimensions and alloc
  for (r=1; r<img_res; r++){
    u = r-1;
    img_w[r] = (img_w[u]%2==0)?img_w[u]/2:(img_w[u]+1)/2;
    img_h[r] = (img_h[u]%2==0)?img_h[u]/2:(img_h[u]+1)/2;
    img_N[r] = img_w[r]*img_h[r];
    
    img[r]        = new unsigned char[img_N[r]];
    img_labels[r] = new unsigned char[img_N[r]];
    img_elem  [r] = new           int[img_N[r]];
    if (r<img_res-1)
      img_GR  [r] = new           int[img_N[r]];
  }
  
  // set coarser resolutions pixels
  for (r=1, u=0; r<img_res; r++, u++){
    i = j = 0;
    for (y=0; y<img_h[u]; y+=2){
      i = img_w[u]*y;
      for (x=0; x<img_w[u]; x+=2){
        if (x+1<img_w[u]){
          s1 = i+x;      s2 = s1+1;
          s3 = s1+img_w[u]; s4 = s3+1;
        }else{
          s1 = s2 = i+x;
          s3 = s4 = s1+img_w[u];
        }
        if (i+img_w[u]>=img_N[u]){
          s3 = s1; s4 = s2;
        }
        img[r][j] = (img[u][s1] + img[u][s2] + img[u][s3] + img[u][s4])/4;
        img_GR[u][s1] = img_GR[u][s2] = img_GR[u][s3] = img_GR[u][s4] = j++;
      }
    }
  }
  
  // alloc the number of elements for each resolution
  for (r=img_res-1; r>=0; r--){
    for (i=0, s=0; s<img_N[r]; s++){
      u = (r==img_res-1)?
          (img[r][s]>=min && img[r][s]<=max):  // pixels between min and max
          (img_elem[r+1][img_GR[r][s]] != -1); // coarser resolution exist
      if (u)
        img_elem[r][s] = i++;
      else
        img_elem[r][s] = -1;
    }
    N[r] = i;
    element [r] = new TEMMPMElem[N[r]];
    elem_img[r] = new   int[N[r]];
  }
  
  // set element gray levels and initialize labels values;
  for (r=img_res-1; r>=0; r--)
    for (s=0; s<img_N[r]; s++){
      i = img_elem[r][s];
      img_labels[r][s] = L;
      if (i != -1){
        elem_img[r][i] = s;
        element[r][i].y = img[r][s];
        element[r][i].x = RANDOM*L;
        element[r][i].m_neighbor = (r==img_res-1)?NULL:
          element[r+1] + img_elem[r+1][img_GR[r][s]];
        element[r][i].area = 1.;
      }
    }
  
    // set neighborhood
    for (r=0; r<img_res; r++){
      gcalc[0] =  1 + 0;          //
      gcalc[1] = -1 + 0;          // |7|3|5|
      gcalc[2] =  0 + img_w[r];   // |1|s|0|
      gcalc[3] =  0 - img_w[r];   // |6|2|4|
      gcalc[4] =  1 + img_w[r];   //
      gcalc[5] =  1 - img_w[r];
      gcalc[6] = -1 + img_w[r];
      gcalc[7] = -1 - img_w[r];
      for (i=0; i<N[r]; i++){
        j = 0;
        s = elem_img[r][i];
        for (u=0; u<g; u++){
          gs = s+gcalc[u];
          if (((gs<img_N[r] && gs>=0) && gs%img_w[r])&&(img_elem[r][gs]!=-1))
            neighbor[j++] = element[r]+img_elem[r][gs];
          else
            neighbor[j++] = element[r]+i;
        }
        element[r][i].neighbor = new TEMMPMElem *[j];
        element[r][i].nn = j;
        for (u=0; u<j; u++)
          element[r][i].neighbor[u] = neighbor[u];
      }
    }
}


/** getLabels - get pixels label
  @param  int         r: resolution number
  @return unsigned_char: label array
 **/
unsigned char *CElements::getLabels(int r)
{
  int i;
  
  for (i=0; i<N[r]; i++)
    img_labels[r][elem_img[r][i]] = element[r][i].x;
  
  return img_labels[r];
}


/** ~CElements - destructor
  **/
CElements::~CElements()
{
  int r, s;
 
  for (r=0; r<img_res; r++){
    for (s=0; s<element[r][s].nn; s++)
      free(element[r][s].neighbor);
    free(element[r]);
    if (r>0) free(img[r]);
    free(img_labels[r]);
    free(img_elem[r]);
    free(elem_img[r]);
    if (r>img_res) free(img_GR[r]);
  }
  free(element);
  free(img);
  free(img_labels);
  free(img_elem);
  free(elem_img);
  if (img_res>1) free(img_GR);
  free(img_N);
  free(img_w);
  free(img_h);
}
