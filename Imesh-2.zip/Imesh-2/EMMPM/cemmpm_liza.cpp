/**
  TESTE CEMMPM
**/


#include <liza.h>
#include "../src/cemmpm.h"


extern "C" const char NAME[] = "teste EM/MPM";

extern "C" void
module ()
{
  LizaWin win = LizaWinDefault;
  uint8 *img;
  uint8   colorTable[48] =
            {255,   0,   0,
               0, 255,   0,
               0,   0, 255,
             255, 255,   0,
             255,   0, 255,
               0, 255, 255,
             255, 255, 255,
               0, 127, 255,
             127,   0,   0,
               0, 127,   0,
               0,   0, 127,
             127, 127,   0,
             127,   0, 127,
               0, 127, 127,
             127, 127, 127,
               0,   0,   0};

  
  lizaGetImage ((void **) (&img), &win, UInt8, Grayscale);
  win.num = -1;
  
  CElements pixels(img,win.w,win.h,4,5,0,255);
  CEMMPM mrf(pixels.element,pixels.N,5,2.4);
  
  
  for (int p=1; p<=50; p++){
    
    mrf.run();
    
    lizaAddIndexedImage (pixels.getLabels(), colorTable, 16, &win);
    lizaRepaint(&win);
    
    if (lizaStop())
      break;
  }
}
