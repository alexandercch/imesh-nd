/**
  emmpm.h
  EM/MPM "element" segmentation class library
  nov/2005
  Leandro Cavaleri Gerhardinger
**/
#ifndef EMMPM_H
#define EMMPM_H


#include "element.h"
#include "label.h"
#include "define.h"
#include "otsu.h"



/** class for the element segmentation **/
class CEMMPM
{
  public:
    /** Elements **/
    TEMMPMElem *element; // array of elements
    int    N;            // number of elements
    
    
    /** Parameters **/
    int               T;     // number of visits for each element
    int               L;     // number of labels
    CLabelParameters *theta; // parameters for each label
    float             beta;  // spacial interaction parameter
    float             annealing; // increases beta parameter
    float             beta_max;  // maximum beta value
    
    
    /** Auxiliar variables **/
    int     *dnn; // number of different neighbors if element class is k
    float   *cpmf;     // condicional probability mass function
    float ***cpmf_arr; // cpmf[k][y][dnn]
    float    beta_x_dnn[MAXNEIGHBORS+1]; // beta * dnn[k]
    float   *f_dnn; // edge sum of different neighbors if element class is k
    
    
    /** Multiresolution Variables and Parameters**/
    TEMMPMElem       **m_element;
    int               *m_N;
    int                levels;
    CLabelParameters **m_theta;
    float              alfa;
    float             *alfa_x_dnn;
    
    
    /** Methods **/
    // run - iterates once
    void run();
    
    // MPM - Maximization of the Posterior Marginal: segment the elements
    void MPM();
    
    // EM - Expectation Maximization: estime label parameters
    void EM();
    
    // Annealing - cools the system
    void Annealing();
    
    // CEMMPM - constructor
    // (Elem, N, L, beta, annealing, beta_max, T)
    CEMMPM(TEMMPMElem*, int, int, float, float, float, int);
    
    // CEMMPM - constructor (multiresolution)
    // (Elem, N, L, levels, beta, annealing, beta_max, alfa, T)
    CEMMPM(TEMMPMElem**, int*, int, int, float, float, float, float, int);
    
    // ~CEMMPM - destructor
    ~CEMMPM();
    
    
    /** Multiresolution Methods **/
    // Multiresolution MPM algorithm
    void M_MPM();
    
    // Multiresolution EM algorithm
    void M_EM();
    
    
    /** Methods with geometrical issues **/
    // using edge and perimeter
    void MPM_Geometrical_1();
    
    // using area
    void EM_Geometrical();
    
    // make a file with theta values and distribuiton
    void fileWithTheta(char*);
};
#endif
