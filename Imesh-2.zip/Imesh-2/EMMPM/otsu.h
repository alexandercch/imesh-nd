/**
  otsu.h
  Otsu algorithm for EMMPM initial parameters estimation
  nov/2005
  Leandro Cavaleri Gerhardinger
 **/
#ifndef OTSU_H
#define OTSU_H



#include "element.h"
//#include "label.h"



struct TTheta
{
  float mu;
  float sigma2;
};


// estrutura para �rvore de threshold
struct TNode
{
  float T;
  float fmin;
  
  TTheta PLeft;
  TTheta PRight;
  int mink;
  int level;
  
  int start;
  int end;
  float f[GRAYLEVELS];
  
  TNode *NLeft;
  TNode *NRight;
};



/** COtsu - classe para estima��o do theta[0] para a segmenta��o EM/MPM
**/
class COtsu
{
  public:
    TEMMPMElem *element; // array of elements
    int         N;       // number of elements
    
    TNode *root;   // raiz da �rvore de threshold
    TNode ***auxn; // vetor de vetor de nodes (�rvore vista por n�vel)
    int *cont; // contador para auxn
     
    //CLabelParameters **thetas;
    TTheta **thetas;
    
    float  p[GRAYLEVELS];   // histograma
    float  pa[GRAYLEVELS];  // histograma acumulado
    float  f[GRAYLEVELS];   // vari�ncia inter-classes
    float  auxm[GRAYLEVELS]; // auxiliar para a m�dia
    int   *thresholds;      // pontos de thresholds
    int    L;      // n� m�ximo de classes
    float  d[GRAYLEVELS];      // derivada
    
    int levels;
    
    // construtor (e_, N_, l_, ge)
    COtsu(TEMMPMElem *, int, int, int);
    
    // cria estimativas iniciais para n� de classes diferentes
    void run();
    
    // fun��o recursiva para cria��o da �rvore de multi-threshold
    // (start, end, level)
    TNode *recursiveTree(int, int, int);
    
    // cria theta buscando na �rvore recursivamente
    // (node, k, c, theta)
    void recursiveTheta(TNode *, int k, int &, TTheta *);
    
    // executa o algoritmo de Otsu para uma faixa do histograma
    // (start, end, fmin)
    int getOtsuThreshold(int, int, float &);
    
    // filtro no histograma
    // (mask)
    void filter1(int);
};
#endif
