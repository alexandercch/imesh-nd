/**
  otsu.cpp
  Otsu algorithm for EM/MPM initial parameters estimation
  nov/2005
  Leandro Cavaleri Gerhardinger
**/



#include <math.h>
#include <stdio.h>
#include "otsu.h"



/** COTsu - Construtor
  @param TEMMPMElem *e_ : array of elements
  @param int    N_ : n� de pixels da imagem
  @param int    l_ : n� de niveis da recurs�o
  @param int    ge : there is geometrical issues (0 no, 1 yes)
 **/
COtsu::COtsu(TEMMPMElem *e_, int N_, int l_, int ge)
{
  int i;
  float max;
  
  element = e_;
  N = N_;
  
  levels = l_;
  
  cont = new int[levels];
  
  L = (int) pow(2.,(float)levels);
  
  
  // aloca vetor de thresholds
  thresholds = new int[L-1];
  
  // calcula histograma
  for (i=0; i<GRAYLEVELS; i++) p[i] = 0; // zerar
  if (ge){
    for (i=0; i<N; i++) p[element[i].y]+=element[i].area;
  }else{
    for (i=0; i<N; i++) p[element[i].y]++;
  }

  // escala logaritmica
  max = 0.;
  for (i=0; i<GRAYLEVELS; i++)
    if (p[i]>0){
      //p[i] = log(p[i]);
      if (p[i]>max) max = p[i];
    }
  for (i=0; i<GRAYLEVELS; i++) p[i] /= max;
  
  // calcula histograma acumulado
  pa[0] = p[0];
  for (i=1; i<GRAYLEVELS; i++)
    pa[i] = pa[i-1] + p[i];
  
  filter1(11);
  
  // calcula auxiliar para m�dia
  auxm[0] = 0;
  for (i=1; i<GRAYLEVELS; i++) auxm[i] = auxm[i-1] + p[i]*i;
  
  // aloca thetas
  thetas = new TTheta*[L-1];
  for (i=0; i<L-1; i++)
    thetas[i] = new TTheta[i+2];
  
  // aloca auxiliar de nodes
  auxn = new TNode **[levels];
  for (i=0; i<levels; i++){
    auxn[i] = new TNode *[(int)pow(2.,(double)levels-i-1)];
    cont[i] = 0;
  }
}



/** run - cria thetas para todos os n� de classes
 **/
void COtsu::run()
{
  int l, i, j, z, k;
  TNode *aux;
  
  // cria �rvore
  root = recursiveTree(0, GRAYLEVELS-1, levels);
  
  
  // ordena auxn
  k = L;
  for (l=0; l<levels; l++){
    z = (int)pow(2.,(double)levels-l-1);
    for (i=0;  i<z; i++)
      for (j=0; j<z-i-1; j++)
        if (auxn[l][j]->fmin > auxn[l][j+1]->fmin){
          aux = auxn[l][j+1];
          auxn[l][j+1] = auxn[l][j];
          auxn[l][j]   = aux;
        }
    // determina prioridade (minima classe que o n� aceita)
    for (i=z-1; i>=0; i--)
      auxn[l][i]->mink = k--;
  }
  
  
  // monta thetas
  for (i=2; i<=L; i++){
    j = 0;
    recursiveTheta(root,i,j,thetas[i-2]);
  }
}


/** recursiveTree - cria �rvore de multi-threshold
    @param  int start : inicio da faixa do histograma
    @param  int end   : final da faixa do histograma
    @param  int level : n�mero de n�ves da �rvore
    @return TNode     : n� do threshold
 **/
TNode *COtsu::recursiveTree(int start, int end, int level)
{
  float mu, fmin;
  int i, T = this->getOtsuThreshold(start, end, fmin);
  
  TNode *node  = new TNode;
  
  // monta auxn
  auxn[level-1][cont[level-1]++] = node;
  
  // informa��es
  node->T     = T;
  node->fmin  = fmin;
  node->level = level;
  node->start = start;
  node->end   = end;
  for (i=start; i<=end; i++) node->f[i] = f[i];
//  for (i=0; i<=255; i++) node->f[i] = f[i];
  
  // theta esquerdo
  if (pa[T]==0) mu = (start+T)/2.;
  else mu = auxm[T]/pa[T];
//  sigma2 = 0;
//  for (i=start; i<=T; i++)
//    sigma2 += p[i]*pow(i-mu,2);
//  sigma2 /= pa[T];
  node->PLeft.mu     = mu;//set(mu,SIGMA2);
  node->PLeft.sigma2 = SIGMA2;
  
  // theta direito
  if (pa[end]-pa[T]==0) mu = (end+T)/2.;
  else mu = (auxm[end]-auxm[T])/(pa[end]-pa[T]);
//  sigma2 = 0;
//  for (i=T+1; i<=end; i++)
//    sigma2 += p[i]*pow(i-mu,2);
//  sigma2 /= (pa[end]-pa[T]);
  node->PRight.mu     = mu;//set(mu,SIGMA2);
  node->PRight.sigma2 = SIGMA2;
  
  // verifica n�vel
  level--;
  if (level>0){
    // arruma pa e auxm
    for (i=T+1; i<=end; i++){
      pa[i] -=  pa[T];
      auxm[i] -= auxm[T];
    }
    // chama recurs�o
    node->NLeft  = recursiveTree(start, T, level);
    node->NRight = recursiveTree(T+1, end, level);
  }else{
    // finaliza recurs�o
    node->NLeft  = NULL;
    node->NRight = NULL;
  }
  
  return node;
}



/** recursiveTheta - cria theta buscando na �rvore recursivamente
**/
void COtsu::recursiveTheta(TNode *node, int k, int &c, TTheta *theta)
{
  bool aux;
  
  // esquerda
  aux = (node->NLeft != NULL);
  if (aux)
    aux = (node->NLeft->mink <= k);
  if (aux)
    recursiveTheta(node->NLeft, k, c, theta);
  else
    theta[c++] = node->PLeft;
    
  // direita
  aux = (node->NRight != NULL);
  if (aux)
    aux = (node->NRight->mink <= k);
  if (aux)
    recursiveTheta(node->NRight, k, c, theta);
  else
    theta[c++] = node->PRight;
}



/** getOtsuThreshold - executa o algoritmo de Otsu para uma faixa do histograma
    @param  int start : inicio da faixa do histograma
    @param  int end   : final da faixa do histograma
    @return int       : n�vel de cinza para threshold
 **/
int COtsu::getOtsuThreshold(int start, int end, float &fmin)
{
  int i, T;
  float w1, w2, m1, m2;
  
  // calcula funcao de vari�ncia inter-classes
  for (i=start; i<end; i++){
    w1 = pa[i];
    w2 = pa[end] - w1;
    if (w1==0. || w2==0.)
      f[i] = 0.;
    else{
      m1 = auxm[i]/w1;
      m2 = (auxm[end] - auxm[i])/w2;
      f[i] = -w1*w2*pow(m1-m2,2.);
    }
  } f[i] = f[i-1];
  
  // pega �ndice onde a fun��o � m�nima
  fmin = 0;
  if (start==end) T = start;
  else for (i=start; i<=end; i++)
    if (f[i] < fmin){
      T = i;
      fmin = f[i];
    }
  
  // retorna valor do threshold
  return T;
}



/** filter1 - filtro no histograma
    @param int mask : m�scara
**/
void COtsu::filter1(int mask)
{
  int i;
  int b = (int)floor(mask/2.);
  
  for (i=0; i<b; i++)
    p[i] = pa[i+b]/(mask-b+i);
  
  for (i=b+1; i<GRAYLEVELS-b; i++)
    p[i] = (pa[i+b] - pa[i-b-1])/mask;
  
  for (i=GRAYLEVELS-b; i<GRAYLEVELS; i++)
    p[i] = (pa[GRAYLEVELS-1] - pa[i-b-1])/(GRAYLEVELS-i+b);
  
  pa[0] = p[0];
  for (i=1; i<GRAYLEVELS; i++)
    pa[i] = pa[i-1] + p[i];
}
