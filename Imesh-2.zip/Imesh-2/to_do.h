class to_do
{/*

---------------------------------------------------------------------
*** isr-Mesh_2 Algorithm ***
i -> Initial mesh generation from an image
s -> Mesh-based segmentation 
r -> Mesh refinement 
---------------------------------------------------------------------
*** i ***
- About the process that walks across a 2d-line detecting maximun-points.
  The case that was considered is +++--- , and it must be cosidered also the case: +++0---
*** s ***
- It'd be good if the process of segmentation is acelerated. Right now is very slow.
...
*** r ***
- At the beginning of the refinement process--After of "SplitInvadedBorderEdges()" process
	-It's possible to create a process to eliminate internal points.
	 That is, we could begin the refinement process with only border points in the mesh.
	-It's also possible to elimite somo linear-points on the border.

*/};


/*/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///PATTERNS SMOOTHING////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <class Traits>
void CImesh_2<Traits>::PatternsSmoothing()
{
	Tn::Finite_faces_iterator fi;
	Cell_handle ni;
	int i;
	double area;
	
	//initializing nodes...
	for ( fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi )
	{
		SmoothPatternNode*& node = (SmoothPatternNode*&)(fi->Info().VoidPtr());
		node = new SmoothPatternNode;
		node->resize(4);
		(*node)[0] = make_pair(fi, FaceArea(fi) );
		for ( i = 0; i < 3; i++ )
		{
			ni = fi->neighbor(i);
			if ( !m_Tn.is_infinite(ni) )	(*node)[i+1] = make_pair(ni, FaceArea(ni) );
			else							(*node)[i+1] = make_pair(Cell_handle(NULL), 0);
		}
		area = 0;
		for ( i = 0; i < 4; i++ )	area += (*node)[i].second;
		for ( i = 0; i < 4; i++ )	(*node)[i].second /= area;
	}
	
	//Smoothing...
	for ( ;; )
	{
	for ( int j = 0; j < 100; j++ )
	{
		//new values
		for ( fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi )
		{
			SmoothPatternNode*& node = (SmoothPatternNode*&)(fi->Info().VoidPtr());
			node->NewPattern() = 0;
			for ( i = 0; i < 4; i++ )
			{
				ni = (*node)[i].first;
				if ( ni == NULL )
					continue;
				node->NewPattern() += FacePattern(ni) * (*node)[i].second;
			}
		}

		//... 
		for ( fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi )
		{
			SmoothPatternNode*& node = (SmoothPatternNode*&)(fi->Info().VoidPtr());
			for ( i = 0; i < 4; i++ )
				fi->Info().Pattern() = node->NewPattern();
		}
	}
		Refresh();
	}

	//deleting the nodes...
	for ( fi = m_Tn.finite_faces_begin(); fi != m_Tn.finite_faces_end(); ++fi )
	{
		void*& p = fi->Info().VoidPtr();
		delete p;	p = NULL;
	}
}
*/

/*

template <class Traits>
void CMeshGeneratorTwo2<Traits>::ShowMedianRegions()
{
	CPointerPriorityList<MeshRegion>::iterator pli;
	for ( pli = m_MeshRegionVector.begin(); pli != m_MeshRegionVector.end(); ++pli )
		(*pli)->DrawMedian(m_ws);
	CMGUtility::Wait(m_ws);
}

*/
/*template <class Traits>
void CMeshGeneratorTwo2<Traits>::AssertValidBorderEdges()
{
	Vertex_handle vh1, vh2, v1, v2;
	Cell_handle f;
	int i, bOk, nMiss = 0;
	BorderEdges::iterator bei;
	for ( bei = m_BorderEdges.begin(); bei != m_BorderEdges.end(); ++bei )
	{
		vh1 = bei->first;	vh2 = bei->second;

		Tn::Edge_circulator ec = vh1->incident_edges(), done_(ec);
		bOk = false;
		do
		{
			f = ec->first;
			i = ec->second;
			v1 = f->vertex(f->cw(i));
			v2 = f->vertex(f->ccw(i));
			if ( ( v1 == vh1 && v2 == vh2 ) || ( v2 == vh1 && v1 == vh2 ) )
			{
				bOk = true;
				break;
			}
		}while(--ec != done_);
		
		if ( !bOk )
		{
			nMiss++;
			Segment_2 seg(vh1->point(), vh2->point());
			m_ws->set_line_width(3);
			*m_ws<<ORANGE<<seg;
		}
	}
	if ( nMiss )
	{
		::printf("!%de ", nMiss);
		//w->Refresh();
		//assert(0);
	}
}
*/

/*template <class Traits>
void CMeshGeneratorTwo2<Traits>::ShowColorRegions(bool bFixSimplicesRegionValues, bool bWait)
{
	m_ws->clear();
	if ( bFixSimplicesRegionValues ) 
		FixSimplicesRegionValues(true);
	MeshRegionVector::iterator pli;
	
	for ( pli = m_MeshRegionVector.begin(); pli != m_MeshRegionVector.end(); ++pli )
		ShowColorRegion(*pli);

	if (bWait) CMGUtility::Wait(m_ws);
}
*/


/*//--------------------------------------------------------------------------------------------------

template <class Traits>
int CMeshGeneratorTwo2<Traits>::Imeshing2()
{
	CMGUtility::BeginProcE("Imeshing2");
	cout<<"MinFilterValue: ";		cin>>m_nMinFilterValue;
	cout<<"MinNearestDistance : ";	cin>>m_nMinNearestDistance;

	START_DEF_TIME(im2);

	SetAllFacesToBreak();
	int nv, lnv;
	do 
	{
		nv = m_Tn.number_of_vertices();
		ImeshingStep();
		lnv = m_Tn.number_of_vertices();
	}while(nv != lnv);

	STOP_PRINT_TIME(im2);
	m_ws->clear();
	*m_ws<<m_Tn;
	return 1;
}

template <class Traits>
int CMeshGeneratorTwo2<Traits>::ImeshingStep()
{
	//Finding new points
	CMGUtility::BeginSubProcT("new");
	Break_point_list break_points;	
	Tn::Finite_faces_iterator fi;
	Point bp;
	for (fi = m_Tn.finite_faces_begin(); fi != m_Tn.faces_end(); ++fi) 
	{
		if ( fi->Info().Breakable() ) 
		{
			if ( DivisionTest(bp, fi) )
			{
				Face_vertex fv;
				MGTriangle::FaceVertexFromFace<Tn>(fv, fi);
				break_points.push_back(Break_point(fv, bp));
			}
			else	fi->Info().Breakable() = false;
		}
	}
	CMGUtility::EndSubProcNT(break_points.size());
	
	//Inserting new points
	CMGUtility::BeginSubProcT("ins");
	int ins = 0;
	if ( break_points.size() )
	{
		Break_point_list::iterator li;
		Point bp;
		Face_vertex fv;
		Tn::Vertex_handle nvh;
		double dist;
		for ( li = break_points.begin(); li != break_points.end(); ++li )
		{
			fv = li->first;
			bp = li->second;
			nvh = m_Tn.nearest_vertex(bp);
			dist = MGPoint::Distance(bp, nvh->point());
			if ( dist >= m_nMinNearestDistance )
			{
				ins++;
				Vertex_handle vh = m_Tn.insert(bp);
				Tn::Face_circulator fc = m_Tn.incident_faces(vh), done(fc);
				do{
					if(m_Tn.is_infinite(fc)) continue;
					fc->Info().Breakable() = true;			
				} while(--fc != done);
			}
			else
			{
				Cell_handle sh;
				if ( m_Tn.is_face(fv.v0, fv.v1, fv.v2, sh) )
					sh->Info().Breakable() = false;							
			}
		}
	}
	CMGUtility::EndSubProcNTE(ins);

	//m_ws->clear();
	//*m_ws<<m_Tn;

	return 1;
}

//--------------------------------------------------------------------------------------------------

	int Imeshing2();
	int ImeshingStep();
	
	int Imeshing();

	inline void GetViolatedFaces(Cell_handle fh, Point bp, Cell_list* nfl);
	inline void GetStarFaces(Vertex_handle vh, Cell_list* fl);
	inline void RegFace(Cell_list* fl, Cell_handle fh);
	inline bool UnregFace(Cell_list* fl, Cell_handle fh);
	inline void RegFaces(Cell_list* fl, Cell_list* nfl);
	inline void UnregFaces(Cell_list* fl, Cell_list* nfl);
	Vertex_handle InsertDistPoint(int nMinDistance, Point break_point, Cell_handle fh = NULL);

template <class Traits>
int CMeshGeneratorTwo2<Traits>::Imeshing()
{
	CMGUtility::BeginProcE("Imeshing");
	cout<<"MinFilterValue: ";		cin>>m_nMinFilterValue;
	cout<<"MinNearestDistance : ";	cin>>m_nMinNearestDistance;
	
	START_DEF_TIME(im);	

	Cell_list fl, tmp_fl;
	Tn::Finite_faces_iterator fi;
	Cell_list::iterator fli;

	/m_time.start();
	//Registering initial faces in list
	for (fi = m_Tn.finite_faces_begin(); fi != m_Tn.faces_end(); ++fi) 
		tmp_fl.push_back(fi);	
	RegFaces(&fl, &tmp_fl);

	//Imeshing refinement...
	Cell_handle fh;
	Vertex_handle vh;
	Point bp;
	Tn::Vertex_handle nvh;
	double dist;
	long count = 0; 
	while( fl.size() )
	{
		fh = fl.front(); //fl.pop_front();

		if ( DivisionTest(bp, fh) )
		{
			nvh = m_Tn.nearest_vertex(bp);

			dist = MGPoint::Distance(bp, nvh->point());
			if ( dist >= m_nMinNearestDistance )
			{
					//m_ws->clear();	*m_ws<<CGAL::GREEN<<m_Tn;	*m_ws<<CGAL::BLUE<<bp;
				GetViolatedFaces(fh, bp, &tmp_fl);
					//ShowTriangles(&tmp_fl);
				UnregFaces(&fl, &tmp_fl); 
				vh = m_Tn.insert(bp, fh);
				if ( vh != NULL )
				{
						//m_ws->clear();	*m_ws<<CGAL::GREEN<<m_Tn;	*m_ws<<CGAL::BLUE<<bp;
					GetStarFaces(vh, &tmp_fl);
						//ShowTriangles(&tmp_fl);
					RegFaces(&fl, &tmp_fl); 
				}
			}
			else	
				if ( !UnregFace(&fl, fh) )
					fl.pop_front();
		}
		else		
			if ( !UnregFace(&fl, fh) )
				fl.pop_front();

		if ( ++count%500 == 0 )
		{
			//m_ws->clear();	*m_ws<<m_Tn;
			printf("[pts=%d,s=%d] ", m_Tn.number_of_vertices(), fl.size());		
		}
			//printf(".");		
			//printf(" %d ", fl.size());		
	}
	/m_time.stop();	printf("Imeshing() = %lf\n", m_time.time());
	
	STOP_PRINT_TIME(im);	
	
	*m_ws<<*this;
	return 1;
}

template <class Traits>
inline void CMeshGeneratorTwo2<Traits>::GetViolatedFaces(Cell_handle fh, Point bp, Cell_list* t_fl)
{//this process must be faster!!!
	Cell_handle f, ni;
	Cell_list walked_list, stack_list;
	int i;

	t_fl->clear();
	stack_list.push_back(fh); fh->Info().Bool() = 1; walked_list.push_back(fh);
			
	while( stack_list.size() )
	{
		f = stack_list.front(); stack_list.pop_front();
		Gt::Circle_2 cc( f->vertex(0)->point(),	f->vertex(1)->point(), f->vertex(2)->point() );
		if ( cc.oriented_side(bp) != ON_POSITIVE_SIDE )
			continue;

		t_fl->push_back(f);
		for ( i = 0; i < 3; i++ )
		{
			ni = f->neighbor(i);
			if ( m_Tn.is_infinite(ni) || ni->Info().Bool() )
				continue;
			stack_list.push_back(ni); ni->Info().Bool() = 1; walked_list.push_back(ni);
		}
	}
	for ( Cell_list::iterator wi = walked_list.begin(); wi != walked_list.end(); ++wi )
		(*wi)->Info().Bool() = false;
}

template <class Traits>
inline void CMeshGeneratorTwo2<Traits>::GetStarFaces(Vertex_handle vh, Cell_list* t_fl)
{
	t_fl->clear();
	Tn::Face_circulator fc = m_Tn.incident_faces(vh), done(fc);
	do
	{	if(m_Tn.is_infinite(fc))	continue;
		t_fl->push_back(fc);
	} while(--fc != done);
}

template <class Traits>
inline void CMeshGeneratorTwo2<Traits>::RegFace(Cell_list* fl, Cell_handle fh)
{
		//m_ws->clear();	*m_ws<<CGAL::GREEN<<m_Tn;	*m_ws<<CGAL::BLUE<<m_Tn.triangle(fh);
	Cell_list::iterator t_fi;
	t_fi = fl->insert(fl->end(), fh);//push_back
	void*& p = (*t_fi)->Info().VoidPtr();
	p = new Cell_list::iterator;
	*((Cell_list::iterator*)p) = t_fi;
}

template <class Traits>
inline bool CMeshGeneratorTwo2<Traits>::UnregFace(Cell_list* fl, Cell_handle fh)
{
		//m_ws->clear();	*m_ws<<CGAL::GREEN<<m_Tn;	*m_ws<<CGAL::BLACK<<m_Tn.triangle(fh);
	void*& p = fh->Info().VoidPtr();
	if ( p == (void*)((int*)1) )
		return 0 ;
	Cell_list::iterator fi = *((Cell_list::iterator*)p);
	delete p;
	p = (void*)((int*)1);
	fl->erase(fi);	
	return 1;
}

template <class Traits>
inline void CMeshGeneratorTwo2<Traits>::RegFaces(Cell_list* fl, Cell_list* t_fl)
{
	for ( Cell_list::iterator fli = t_fl->begin(); fli != t_fl->end(); ++fli )
		RegFace(fl, *fli);
} 

template <class Traits>
inline void CMeshGeneratorTwo2<Traits>::UnregFaces(Cell_list* fl, Cell_list* t_fl)
{
	for ( Cell_list::iterator fli = t_fl->begin(); fli != t_fl->end(); ++fli )
		UnregFace(fl, *fli);
} 

template <class Traits>
CMeshGeneratorTwo2<Traits>::Vertex_handle 
CMeshGeneratorTwo2<Traits>::InsertDistPoint(int nMinDistance, Point break_point, Cell_handle fh)
{
	Tn::Vertex_handle nvh;
	nvh = m_Tn.nearest_vertex(break_point);
	
	double dist = MGPoint::Distance(break_point, nvh->point());
	if ( dist >= nMinDistance )
	{
		Vertex_handle vh = m_Tn.insert(break_point, fh);
		
		Tn::Face_circulator fc = m_Tn.incident_faces(vh), done(fc);
		do
		{
			if(m_Tn.is_infinite(fc)) 
				continue;
			fc->Info().Breakable() = true;			
		} while(--fc != done);
		
		return vh;
	}
	if ( fh != NULL )
		fh->Info().Breakable() = false;
	return NULL;
}
*/


/*/*template <class Traits>
void CMeshGeneratorTwo2<Traits>::IsolatePeaks()
{//Small angles isolation

	Finite_vertices_iterator fvi;
	Edge_circulator ec;	
	Peak_list peak_list;

	for ( fvi = m_Tn.finite_vertices_begin(); fvi != m_Tn.finite_vertices_end(); ++fvi )
	{
		if ( !VariationInStartEdge(&fvi, &ec) )
			continue;
		Point_list* break_points = new Point_list;
		if ( !PeakBreakingPointsExtremes(&fvi, &ec, break_points) )
		{
			delete break_points;
			continue;
		}
//		peak_list.push_back( Peak(fvi, break_points) );
	}
	InsertPeakBreakingPoints(&peak_list);

	for ( Peak_list::iterator pi = peak_list.begin(); pi != peak_list.end(); ++pi )
		//delete pi->second;
		;
}

template <class Traits>
bool CMeshGeneratorTwo2<Traits>::VariationInStartEdge(Finite_vertices_iterator* fvi, Edge_circulator* _ec)
{//this method detect/set the beginning of some region's variation in the vertex star

	Tn::Edge_circulator ec, last_ec, ecdone, int_ec, inf_ec;	
	Cell_handle sfh, fh1, fh2;
	Tn::Vertex_handle last_svh, start_svh;
	int iv;
	int bInfinite, bFinite, bif1, bif2, nStartElem;

	bFinite = bInfinite = 0;
	nStartElem = 0;
	inf_ec = int_ec = Tn::Edge_circulator(NULL);
	ecdone = ec = last_ec = m_Tn.incident_edges(*fvi);
	do
	{
		iv = ec->second;
		fh1 = ec->first;
		fh2 = fh1->neighbor(iv);
		
		bif1 = m_Tn.is_infinite(fh1);
		bif2 = m_Tn.is_infinite(fh2);
		
		bFinite += bif1 + bif2;
		bInfinite +=  (bif1 && !bif2) || (!bif1 && bif2);

		assert(bInfinite <= 2);
		if ( bInfinite == 2 )
			inf_ec = ec;
		if ( ( !bif1 && !bif2 ) &&
			 ( fh1->Info().Region() != fh2->Info().Region() ) )
				int_ec = ec;
		nStartElem++;
	} while(--ec != ecdone);

	if ( int_ec == NULL || nStartElem == 1 ) 
		return false; // no region variation in the star || one element
	*_ec = ec = ( inf_ec != NULL )? inf_ec : int_ec; 
	return true;
}

template <class Traits>
bool CMeshGeneratorTwo2<Traits>::PeakBreakingPointsExtremes(Finite_vertices_iterator* fvi, 
															Edge_circulator* _ec, list<Point>* break_points)
{//This method gives the extremes of the edges around a vertex that contains a peak
	break_points->clear();
	Tn::Vertex_handle svh, last_svh, start_svh;	
	Tn::Edge_circulator ec = *_ec, last_ec, ecdone;
	Cell_handle sfh;
	Gt::Triangle_2 tri;
	double angle, sum_angle = 0;
	int nRegion = -2, nLastRegion = -1;
	bool bLastBreakInserted = false, bFirstTime = true;
	last_ec = ec; ecdone = --ec;
	start_svh = last_svh = MGSegment::StarVertexFromStarEdge<Tn>(last_ec, *fvi);

	for (int k = 2; k && nRegion != -1; k -= last_ec == ecdone)
	{
		svh = MGSegment::StarVertexFromStarEdge<Tn>(ec, *fvi);
		sfh = MGSegment::StarFaceFromStarEdge<Tn>(ec, last_svh);
		if ( !m_Tn.is_infinite(sfh) )
		{
			nRegion = sfh->Info().Region();
			tri = m_Tn.triangle(sfh);
			angle = MGTriangle::GetAngle<Gt>(tri, (*fvi)->point());
		}
		else	nRegion = -1;
		
		if ( !bFirstTime && nRegion != nLastRegion )
		{
			sum_angle = MGMath::RadiansToDegrees(sum_angle);
			if ( sum_angle < m_fMinAngle )
			{
				if ( !bLastBreakInserted )
					break_points->push_back(start_svh->point());
				break_points->push_back(last_svh->point()); 
				bLastBreakInserted = true;
			}
			else	bLastBreakInserted = false;
			sum_angle = 0;
			start_svh = last_svh;
		}
		sum_angle += angle;

		last_svh = svh;
		nLastRegion = nRegion;
		last_ec = ec;
		--ec;
		bFirstTime = false;
	}
	return !!(break_points->size());
}

template <class Traits>
int CMeshGeneratorTwo2<Traits>::InsertPeakBreakingPoints(Peak_list* peak_list)
{//Here we've to insert break_points mantaining the atributes in the regions.

/*	double dist, min_dist, break_dist, angle;
	Finite_vertices_iterator fvi;
	Point center, break_point;
	Point_list* point_list;
	Point_list::iterator pli;
	Peak_list::iterator pi;
	for ( pi = peak_list->be	gin(); pi != peak_list->end(); ++pi )
	{
		fvi = pi->first;
		point_list = pi->second;
		//min edge calc
		center = fvi->point();
		pli = point_list->begin();
		min_dist = MGPoint::Distance(center, *pli);
		for (; pli != point_list->end(); ++pli )
		{
			dist = MGPoint::Distance(center, *pli);
			if ( dist < min_dist )
				min_dist = dist;
		}
		break_dist = min_dist/3.0; // !!! is there exist an appropiate distance based on the min angle???
		
		//insertion
			//w->SelectPoint(center, 0.5);
		for (pli = point_list->begin(); pli != point_list->end(); ++pli )
		{
			angle = atan2(pli->y() - center.y(), pli->x() - center.x());
			break_point = Point( center.x() + break_dist*cos(angle), center.y() + break_dist*sin(angle) );
				//w->SelectPoint(break_point, 0.15);
				//w->Refresh();
				//m_Tn.insert(break_point);
				//w->Refresh();
		}
	}
		//w->Refresh();
	return 1;
}
*/

/*
	//seed points
	MeshRgnSeed_list::iterator si;
	for ( si = m_MRSeedList.begin(); si != m_MRSeedList.end(); ++si )
		MGPoint::DrawBigPoint(si->first, CGAL::BLUE, m_ws);								

*/

