// MaxPointSelector.h: interface for the CStatistics class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MaxValueInLineThree_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_)
#define AFX_MaxValueInLineThree_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_

#include <math.h>

template <class Image, class Mask>
class CMaxPointSelector
{
public:
typedef typename Image::Coord	Coord;
	CMaxPointSelector(Image* m, double fThreshold, Coord GoalPoint);
	inline void operator()(Coord c);
	inline double CoordGradient(Coord c);
	inline bool TestLastHighScalar();
	Coord GreaterCoord();
	double 	GreaterValue();
	int WalkedArea();
	void begin();
	void end();
	bool NoAction(); 
private:
	Image* m_pImage;
	Mask m_Mask;
	Coord m_GreaterCoord, m_LastCoord, m_BeginPoint, m_GoalPoint;
	double m_CurrSing, m_LastSing, m_CurrScalar, m_LastScalar, m_GreaterValue, m_fThreshold, m_GreaterDistance;
	int m_nTime;
	int m_nWalkedArea;
};

template <class Image, class Mask>
CMaxPointSelector<Image,Mask>::
CMaxPointSelector(Image* m, double fThreshold, Coord GoalPoint)
				:m_Mask(m)
{
	m_pImage = m;
	m_nTime = 0;
	m_GreaterValue = 0;
	m_GreaterDistance = MGU::MaxDouble(); //max double 
	m_fThreshold = fThreshold;
	m_GoalPoint = GoalPoint;
	m_nWalkedArea = 0;
}

template <class Image, class Mask>
void CMaxPointSelector<Image,Mask>::begin()
{		
	m_nTime = 0;
}

template <class Image, class Mask>
void CMaxPointSelector<Image,Mask>::end()
{		
//	if ( m_LastSing > 0 )		/* /+ */
//		TestLastHighScalar();
}

template <class Image, class Mask>
bool CMaxPointSelector<Image,Mask>::TestLastHighScalar()
{
	if ( m_LastScalar > m_fThreshold )
	{
		double dist = ::sqrt(squared_distance(m_LastCoord, m_GoalPoint));
		if ( dist < m_GreaterDistance )
		{
			m_GreaterDistance = dist;
			m_GreaterCoord = m_LastCoord;
			m_GreaterValue = m_LastScalar;
			return true;
		}
	}
	return false;
}

template <class Image, class Mask>
int CMaxPointSelector<Image,Mask>::WalkedArea()
{	return m_nWalkedArea;	}

template <class Image, class Mask>
inline double CMaxPointSelector<Image,Mask>::CoordGradient(Coord c)
{
	double &g = (*m_pImage)(c).Gradient();
	if ( g != -1 )
		return g;
	g = m_Mask.Convolution(c);
	return g;
}

template <class Image, class Mask>
inline void CMaxPointSelector<Image,Mask>::operator()(Coord c)
{
	m_nWalkedArea++;
	m_CurrScalar = CoordGradient(c);
	switch(m_nTime)
	{
	case 0:
		m_LastScalar = m_CurrScalar;
		m_nTime++;
		return;
	case 1:
		m_LastSing = m_CurrScalar - m_LastScalar;
		m_LastScalar = m_CurrScalar;
		m_LastCoord = c;
		m_nTime++;
		return;
	default:
		m_CurrSing = m_CurrScalar - m_LastScalar;
		if ( ( m_LastSing > 0 && m_CurrSing <= 0 ) ||		/* + /\ - */
			 ( m_LastSing = 0 && m_CurrSing < 0 )		)	/* 0 -\ - */
		{
			TestLastHighScalar();			
		}
		m_LastSing = m_CurrSing;
		m_LastScalar = m_CurrScalar;
		m_LastCoord = c;
	}
}

template <class Image, class Mask>
inline CMaxPointSelector<Image,Mask>::Coord CMaxPointSelector<Image,Mask>::GreaterCoord()
{	return m_GreaterCoord;			}

template <class Image, class Mask>
inline double CMaxPointSelector<Image,Mask>::GreaterValue()
{	return m_GreaterValue;			}

template <class Image, class Mask>
bool CMaxPointSelector<Image,Mask>::NoAction()
{	return !m_GreaterValue;			}

////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_MaxValueInLineThree_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_)

