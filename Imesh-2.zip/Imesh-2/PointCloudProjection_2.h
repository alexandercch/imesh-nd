// PointCloudProjection_2.h: interface for the CPointCloudProjection_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PointCloudProjection_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)
#define AFX_PointCloudProjection_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_

#include "IsoValueList_d.h"
#include "CloudPoint.h"

template <class Tni>
class CPointCloudProjection_2  
{
public:
typedef typename Tni::FT				FT;
typedef typename Tni::Img				Img;
typedef typename Tni::Tn				Tn;
typedef typename Tn::Point				Point;
typedef typename Tni::FI				FI;
typedef typename Tni::IT				IT;
typedef typename Img::Coord				Coord;
typedef typename CIsoValueList_d<Tni>	Ivl;

public:
	CPointCloudProjection_2();	
	virtual ~CPointCloudProjection_2();
	void Init(Img* pImg,Ivl* pIvl);
	void MakeCloud(Point& p);
	void WriteCloud(Point& p, Point& pp);
	virtual Point Project(Point& p);

protected:
	Img* m_pImg;
	CCloudPoint* m_pCloud;
	int m_nCloudPoints;
	Ivl* m_pIvl;
	int m_nRadius;
};

template <class Tni>
CPointCloudProjection_2<Tni>::CPointCloudProjection_2()
{	
	m_pImg = NULL;
	m_pIvl = NULL;
	m_nRadius = 3;
	m_pCloud = new CCloudPoint[2*pow(2*m_nRadius+1,2)];
}	

template <class Tni>
CPointCloudProjection_2<Tni>::~CPointCloudProjection_2()
{	delete m_pCloud; }

template <class Tni>
void CPointCloudProjection_2<Tni>::Init(Img* pImg, Ivl* pIvl)
{	m_pImg = pImg;	m_pIvl = pIvl; }


template <class Tni>
CPointCloudProjection_2<Tni>::Point CPointCloudProjection_2<Tni>::Project(Point& p)
{
	MakeCloud(p);
	WriteCloud(p,p);
	return p;
}

template <class Tni>
void CPointCloudProjection_2<Tni>::MakeCloud(Point& pp)
{
	Coord p = FI::FtoI(pp);
	int i,j, k = m_nRadius, v1, v2;
	m_nCloudPoints = 0;
	for ( i = p.x()-k; i <= p.x()+k; i++ )
		for ( j = p.y()-k; j < p.y()+k; j++ )
	{
		v1 = (*m_pImg)(i,j); v2 = (*m_pImg)(i,j+1);
		if ( (*m_pIvl)(v1, v2) )
		{
			m_pCloud[m_nCloudPoints].x() = i; 
			m_pCloud[m_nCloudPoints].y() = j + 0.5;
			m_nCloudPoints++;
		}
	}

	for ( j = p.y()-k; j <= p.y()+k; j++ )
		for ( i = p.x()-k; i < p.x()+k; i++ )
	{
		v1 = (*m_pImg)(i,j); v2 = (*m_pImg)(i+1,j);
		if ( (*m_pIvl)(v1, v2) )
		{
			m_pCloud[m_nCloudPoints].x() = i + 0.5; 
			m_pCloud[m_nCloudPoints].y() = j;
			m_nCloudPoints++;
		}
	}
}

template <class Tni>
void CPointCloudProjection_2<Tni>::WriteCloud(Point& p, Point& pp)
{
	ofstream os;
	float k = m_nRadius;
	
	os.open("out\\box.psg", ofstream::out ); 
	assert(os.is_open()); 
	{
		os <<"x	y z	r res\n";
		os<<p.x()+k<<" "<<p.y()-k<<" 0.0 0.15 15\n";
		os<<p.x()+k<<" "<<p.y()+k<<" 0.0 0.15 15\n";
		os<<p.x()-k<<" "<<p.y()-k<<" 0.0 0.15 15\n";
		os<<p.x()-k<<" "<<p.y()+k<<" 0.0 0.15 15\n";
	}
	os.close();
		
	os.open("out\\cloudpoint.pcg", ofstream::out ); 
	assert(os.is_open()); 
	{
		os <<"x	y	z	r	res\n";
		for ( int i = 0; i < m_nCloudPoints; i++ )
			os<<m_pCloud[i].x()<<" "<<m_pCloud[i].y()<<" 0.0 0.15 15\n";
	}
	os.close();

	os.open("out\\point.psg", ofstream::out ); assert(os.is_open()); 
	{
		os <<"x	y	z	r	res\n";
		os<<p.x()<<" "<<p.y()<<" 0.0 0.3 15\n";
	}
	os.close();

	os.open("out\\ppoint.pcg", ofstream::out ); assert(os.is_open()); 
	{
		os <<"x	y	z	r	res\n";
		os<<pp.x()<<" "<<pp.y()<<" 0.0 0.3 15\n";
	}
	os.close();


	os.open("out\\cloud.vtkg", ofstream::out ); assert(os.is_open()); 
	{
		os <<"FileName  r g b op shrink tube\n";
		os<<"cloudpoint.pcg "<<"1.0	0.0	0.0	1.0	1 0\n";
		os<<"point.psg "<<"1.0 1.0 0.0 0.2	1 0\n";
		os<<"box.psg "<<"0.0 1.0 1.0 1.0 1 0\n";
		os<<"ppoint.pcg "<<"1.0 0.0 1.0 0.2 1 0\n";
	}
	os.close();

	os.open("out\\cloud.updt", ofstream::out ); assert(os.is_open()); 
		os <<"nothing";
	os.close();
}

#endif // !defined(AFX_PointCloudProjection_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)



  