#pragma once

#include <CGAL/basic.h>
#include <CGAL/Cartesian.h>
#include <CGAL/Simple_cartesian.h>
#include <CGAL/Filtered_kernel.h>
#include <CGAL/Delaunay_triangulation_2.h>

#include "TriangulationWithInfo.h"
#include "MeshInfo_2.h"

struct CDelaunay_triangulation_Imesh_2
{
	typedef CGAL::Cartesian<double>										CK;
	typedef CGAL::Filtered_kernel<CK>									_Gt;
		struct Gt : public _Gt{};
	typedef Gt::FT														FT;
	typedef CFaceInfo_2<Gt>												CInf;
	typedef CVertexInfo_2<Gt>												VInf;
	typedef CVertexWithInfo<VInf>										_VertexB;
	typedef CFaceWithInfo<CInf>											_FaceB;
		struct FaceB : public _FaceB{};
		struct VertexB : public _VertexB{};
	typedef CGAL::Triangulation_data_structure_2<VertexB,FaceB>			Tds;
	typedef CGAL::Delaunay_triangulation_2<Gt,Tds>						_Triangulation;	
		struct Tn : public _Triangulation{};
};



