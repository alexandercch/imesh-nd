// VerteEdgeNode.h: interface for the CVerteEdgeNode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VERTEEDGENODE_H__5A001033_6A82_4624_8A75_FC29F75DE0F9__INCLUDED_)
#define AFX_VERTEEDGENODE_H__5A001033_6A82_4624_8A75_FC29F75DE0F9__INCLUDED_

#endif // !defined(AFX_VERTEEDGENODE_H__5A001033_6A82_4624_8A75_FC29F75DE0F9__INCLUDED_)
