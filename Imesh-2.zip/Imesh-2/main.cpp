#include "Imesh_2.h"

class main{}; 
int main(void)
{
	CImesh_2<> im;
		im.SetIO("H:\\ImeshIO\\");
		//im.SetIO("E:\\Users\\ImeshIO\\");
		im.Execute();
	return 0;
}
	
