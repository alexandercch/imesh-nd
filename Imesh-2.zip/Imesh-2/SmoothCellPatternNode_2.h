// SmoothPatternNode_d.h: interface for the CSmoothPatternNode class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SmoothPatternNode_d_H__EE7E8582_2CAB_47A3_B403_BB35FC3A1728__INCLUDED_)
#define AFX_SmoothPatternNode_d_H__EE7E8582_2CAB_47A3_B403_BB35FC3A1728__INCLUDED_

template <class Tni>
struct CSmoothPatternNode_d
{
public:
typedef typename Tni::FT FT;
typedef typename Tni::Ch Ch;
public:
	CSmoothPatternNode_d(Ch ch)
	{
		m_ch = ch;
		m_fact = 0;
	}
	FT m_sum, m_fact;
	Ch m_ch;
};

#endif // !defined(AFX_SmoothPatternNode_d_H__EE7E8582_2CAB_47A3_B403_BB35FC3A1728__INCLUDED_)
