// SmoothIsoSurfProj_2.h: interface for the CSmoothIsoSurfProj_2 class.
///////////////////////////////////////////////////////////////////////

#if !defined(AFX_SmoothIsoSurfProj_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)
#define AFX_SmoothIsoSurfProj_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_

#include "SmoothIsoSurfProj_d.h"

template <class Tni>
class CSmoothIsoSurfProj_2 : public CSmoothIsoSurfProj_d<Tni>
{
public:
	inline Point Project(PrePoint& p);
};

template <class Tni>
inline CSmoothIsoSurfProj_2<Tni>::Point CSmoothIsoSurfProj_2<Tni>::Project(PrePoint& p)
{
	FT percent	= ThreeTwoInterpolation_1(p.m_Scalar_a, p.m_Scalar_iv, p.m_Scalar_b);
	
	FT  cax = p.m_Coord_a.x(), cay = p.m_Coord_a.y(),
		cbx = p.m_Coord_b.x(), cby = p.m_Coord_b.y();
	
	FT  rx = ThreeTwoInterpolation_2(cax, cbx, percent),
		ry = ThreeTwoInterpolation_2(cay, cby, percent);

	//FT  mx = (cax + cbx)/2.0, my = (cay + cby)/2.0;
	//Point m( mx, my );
	Point r(rx,ry);
	//FT dist = ::sqrt( squared_distance(m, r) );	

	return r;
//	return Point(p.x(), p.y());
}

#endif // !defined(AFX_SmoothIsoSurfProj_2_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)

