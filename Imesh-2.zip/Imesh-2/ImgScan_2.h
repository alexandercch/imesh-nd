//	: interface for the CImgScan_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TniScans_2_H__052DE00B_4A38_4FB6_9CD5_D395A5F7A611__INCLUDED_)
#define AFX_TniScans_2_H__052DE00B_4A38_4FB6_9CD5_D395A5F7A611__INCLUDED_

#include "TniScan_d.h"

template <class Tni, class Op>
class CImgScan_2 : public CTniScan_d<Tni, Op>>
{
public:	int Run(Op* pOp);
};

template <class Tni, class Op>
int CImgScan_2<Tni,Op>::Run(Op* pOp)
{
	IT::RectangleI_2 r = m_pImg->RectI();
	int i, j;
	for ( i = r.xmin(); i <= r.xmax(); i++ )
		for ( j = r.ymin(); j <= r.ymax(); j++ )
			(*pOp)(Coord(i,j));
	return 1;
}

#endif // !defined(AFX_TniScans_2_H__052DE00B_4A38_4FB6_9CD5_D395A5F7A611__INCLUDED_)
