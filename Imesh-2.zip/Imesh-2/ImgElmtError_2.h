// ImgElmtError_2.h: interface for the CImgElmtError_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ImgElmtError_2_H__B80E9754_26E7_4649_8DFE_AACEB8DF9B14__INCLUDED_)
#define AFX_ImgElmtError_2_H__B80E9754_26E7_4649_8DFE_AACEB8DF9B14__INCLUDED_

#include "ImgElmtError_d.h"

template <class Tni>
class CImgElmtError_2  : public CImgElmtError_d<Tni>
{
public:
	CImgElmtError_2();
	bool PointError(Point coord, FT& ft);
};

template <class Tni>
CImgElmtError_2<Tni>::CImgElmtError_2()
					: CImgElmtError_d<Tni>()
{}

template <class Tni>
bool CImgElmtError_2<Tni>::PointError(Point pp, FT& ft)
{
	Gt::Point_2 p0 = m_CurrCell->vertex(0)->point(), 
				p1 = m_CurrCell->vertex(1)->point(), 
				p2 = m_CurrCell->vertex(2)->point();
	Gt::Triangle_2	t0(p1,p2,pp), t1(p0,p2,pp), t2(p0,p1,pp), t(p0,p1,p2);

	if ( t.oriented_side(pp) != ON_POSITIVE_SIDE )
		return false;

	FT a0 = fabs(t0.area()), a1 = fabs(t1.area()), a2 = fabs(t2.area()), a = fabs(t.area());

	FT	c0	= (*m_pImg)(FI::FtoI(p0)), c1 = (*m_pImg)(FI::FtoI(p1)),
		c2	= (*m_pImg)(FI::FtoI(p2)), cpp = (*m_pImg)(FI::FtoI(pp)),
		pc;
	pc = c0*a0/a + c1*a1/a + c2*a2/a; 
	ft = fabs(cpp - pc);
	return true;
}

#endif // !defined(AFX_ImgElmtError_2_H__B80E9754_26E7_4649_8DFE_AACEB8DF9B14__INCLUDED_)
