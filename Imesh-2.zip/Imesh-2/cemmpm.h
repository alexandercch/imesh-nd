/**
  cemmpm.h
  EM/MPM "element" segmentation class library
  nov/2005
**/



#define TWOPI 6.2831852
#define GRAYLEVELS 256
#define RANDS 14121977
#define RANDOM ((rands *= 134775813)/4294967296.0)
#define SIGMA2 700
#define MAXNEIGHBORS 8



static unsigned int rands = RANDS;  // for linear randomize



/** structure for one pixel, triangule or whatever **/
struct CEMMPMElem
{
  int y; // graylevel (0..GRAYLEVELS-1)
  int x; // label (0..L-1)
  
  CEMMPMElem **neighbor; // array of neighbors index
  int nn;            // number of neighbors
  
  // auxiliar variables
  int *time; // time that the element was on label k after one iteration
};


/** class for the label parameters **/
class CLabelParameters
{
  public:
    /** Parameters **/
    float mu;     // mean
    float sigma2; // variance
    
    
    /** Auxiliar variables **/
    float term1;             // 1/sqrt(2*PI*sigma2)
    float term2[GRAYLEVELS]; // -(y-mu)^2/2*sigma2, (y=0..GRAYLEVELS-1)
    
    
    /** Methods **/
    // CLabel - constructor
    // (mu. sigma)
    CLabelParameters(float, float);
    CLabelParameters(){};
    
    // set - set parameters
    // (mu. sigma)
    void set(float, float);
};


/** class for the element segmentation **/
class CEMMPM
{
  public:
    /** Elements **/
    CEMMPMElem *element; // array of elements
    int    N;       // number of elements
    
    
    /** Parameters **/
    int               T;     // number of visits for each element
    int               L;     // number of labels
    CLabelParameters *theta; // parameters for each label
    float             beta;  // spacial interaction parameter (1.5)
    
    
    /** Methods **/
    // CEMMPM - constructor
    // (Elem*, N, L, beta)
    CEMMPM(CEMMPMElem *, int, int, float);
    
    // run - iterates once
    void run();
    
  private:
    /** Auxiliar variables **/
    int     *dnn;      // number of different neighbors if element class is k
    float   *cpmf;     // condicional probability mass function
    float ***cpmf_arr; // cpmf[k][y][ddn]
    
    /** Methods **/
    // MPM - Maximization of the Posterior Marginal: segment the elements
    void MPM();
    
    // EM - Expectation Maximization: estime label parameters
    void EM();
};


/** class that helps to mount a CEMMPMElem structure **/
class CElements
{
  public:
    /** Elements **/
    CEMMPMElem * element; // array of elements
    int     N;       // number of elements
    
    
    /** Auxiliar variables - Image **/
    unsigned char *img_labels;
    int           *img_elem;
    int           *elem_img;
    int            img_N;
    
    /** Methods - Image **/
    // constructor by image
    // (*img, w, h, g, L, min, max)
    CElements(unsigned char *, int, int, int, int, int, int);
    
    // getLabels - get pixels label
    unsigned char *getLabels();
};
