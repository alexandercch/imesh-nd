// ImageElement.h: interface for the CPixel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PIXEL_H__DD92123B_0A7C_4806_8B75_F1FF13FB8C0B__INCLUDED_)
#define AFX_PIXEL_H__DD92123B_0A7C_4806_8B75_F1FF13FB8C0B__INCLUDED_

struct CGrayImageElement
{
typedef unsigned char Pixel;	
	CGrayImageElement(int nGray = 0)	{	m_nGray = nGray;						}
	static int Dim() 					{	return 1;/*one gray*/					}	
	inline operator Pixel&()			{	return m_nGray;							}
	inline operator=(int v)				{	m_nGray = v;							}
//	inline void*& PVoid()				{	return m_pVoid;							}
	inline operator color()				{	return color(m_nGray,m_nGray,m_nGray);  }
private:
	Pixel m_nGray;
//	void* m_pVoid;
};

#endif // !defined(AFX_PIXEL_H__DD92123B_0A7C_4806_8B75_F1FF13FB8C0B__INCLUDED_)
