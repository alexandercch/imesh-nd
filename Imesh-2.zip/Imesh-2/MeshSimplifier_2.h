// MeshSimplifier_2.h: interface for the CMeshSimplifier_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MeshSimplifier_2_H__0C6CFB7F_5844_45A2_B54B_6B19B1BDD9E0__INCLUDED_)
#define AFX_MeshSimplifier_2_H__0C6CFB7F_5844_45A2_B54B_6B19B1BDD9E0__INCLUDED_

#include "MeshSimplifier_d.h"
#include "VBe_2.h"

template <class BeG>
class CMeshSimplifier_2 : public CMeshSimplifier_d<BeG>  
{
public:
typedef CMeshSimplifier_d<BeG>	Parent;
typedef CVertexEdgeNode_2<Tn>	VENode;
typedef CVBe_2<Tn>				VBe;
typedef Tnd::Gt					Gt;
typedef Tnd::CK					CK;
typedef Tnd::Point				Point;
typedef Tnd::Vh					Vh;
typedef Tnd::VInf				VInf;
typedef Tnd::FT					FT;
typedef Line_2<CK>				Line;
typedef Circle_2<CK>			Circle;

	CMeshSimplifier_2();
	void BorderSim(bool bBBoxSim = true);
	bool TreatPoint(Vh vh);
	bool IsInternBorderSimplificablePoint(Vh v, Vh va, Vh vb);
	void RemoveBorderVertex(Vh vh, Vh va, Vh vb);
	void LeftRightNearestToCenterVertices(Vertex_list* vl, Vh va, Vh vb, Vh& vLeft, Vh& vRight);
	bool EmptyCirclesTest(Vertex_list* vl, Vh va, Vh vb, Vh& vLeft, Vh& vRight);

private:
	bool m_bBBoxSim;
	int m_nBBoxSimCount, m_nSurfSimCount;
	int m_bDebugTemp;
};

template <class BeG>
CMeshSimplifier_2<BeG>::CMeshSimplifier_2() 
{
	m_bBBoxSim = true;
	m_nBBoxSimCount = m_nSurfSimCount = 0;
	m_bDebugTemp = 0;
}

template <class BeG>
void CMeshSimplifier_2<BeG>::BorderSim(bool bBBoxSim)
{
	m_bBBoxSim = bBBoxSim;
	if ( !U_E_BEGIN_SUB_PROC_ASK(Surface-Simplification)	)
		return;
	U_START_DEF_TIME_;
	m_nBBoxSimCount = m_nSurfSimCount = 0;
	for ( VIt vi = m_Tnd.vertices_begin(); vi != m_Tnd.vertices_end(); ++vi )
		TreatPoint(vi);

	cout<<"[BBoxSim = "<<m_nBBoxSimCount<<" SurfSim = "<<m_nSurfSimCount<<"] ";
	U_END_SUB_PROC_T_E;
}

template <class BeG>
bool CMeshSimplifier_2<BeG>::TreatPoint(Vh vh)
{
	if ( vh->info().VType() == VInf::VtBBoxCorner )
		return false;
	VENode* pn = VENode::GetVENode(vh);
	if ( !pn || pn->size() != 2 )
		return false;

	//bbox points
	VENode::iterator vei;
	Vh va, vb;
	vei = pn->begin();
	va = *vei;	vei++;	vb = *vei;
	if ( m_bBBoxSim && vh->info().VType() == VInf::VtBBoxSide )
	{	
		m_nBBoxSimCount++;
		RemoveBorderVertex(vh, va, vb);
		return true;
	}

	//surf points
	if ( IsInternBorderSimplificablePoint(vh, va, vb) )
	{	
		m_nSurfSimCount++;
		RemoveBorderVertex(vh, va, vb);
		return true;
	}
	return false;
}

template <class BeG>
bool CMeshSimplifier_2<BeG>::IsInternBorderSimplificablePoint(Vh vh, Vh va, Vh vb)
{
	Line line(va->point(), vb->point());
	Oriented_side os = line.oriented_side(vh->point());
	if ( os != ON_ORIENTED_BOUNDARY )
		return false;

	bool bEmpty;
	Vertex_list vl;
	Vh vLeft, vRight;

	m_Tnd.incident_vertices(vh, &vl);
	LeftRightNearestToCenterVertices(&vl, va, vb, vLeft, vRight);
	bEmpty = EmptyCirclesTest(&vl, va,vb, vLeft, vRight);

	return bEmpty;
}

template <class BeG> //Testing empty circles
bool CMeshSimplifier_2<BeG>::EmptyCirclesTest(Vertex_list* vl, Vh va, Vh vb, Vh& vLeft, Vh& vRight)
{
	Circle cirRight = TniU::RCircle<Gt>(va->point(), vb->point(), vRight->point()), 
			cirLeft = TniU::RCircle<Gt>(vLeft->point(), va->point(), vb->point()), *pCir;
	Line line(va->point(), vb->point());	
	Oriented_side os, osc;
	Vh vPP;
	
	Vertex_list::iterator vli;
 	for ( vli = vl->begin(); vli != vl->end(); ++vli )
	{
		vPP = *vli;
		if ( vPP == va || vPP == vb )
			continue;
		os = line.oriented_side(vPP->point());
		assert( os != ON_ORIENTED_BOUNDARY );
		
		pCir = &(( os == ON_NEGATIVE_SIDE )? cirRight : cirLeft);
		osc = pCir->oriented_side(vPP->point());

		if ( osc != ON_NEGATIVE_SIDE )	
			return false;
	}
	return true;
}

template <class BeG> //Left|Right nearest-to-center vertices	
void CMeshSimplifier_2<BeG>::LeftRightNearestToCenterVertices(Vertex_list* vl, Vh va, Vh vb, Vh& vLeft, Vh& vRight)
{	
	Point pcen( (va->point().x() + vb->point().x())/2.0, (va->point().y() + vb->point().y())/2.0 );
	Line line(va->point(), vb->point());
	Oriented_side os;
	Vh vPP;
	FT dist, dLeft, dRight;
	dLeft = dRight = TniU::MaxDouble();
	vLeft = vRight = NULL;
	Vertex_list::iterator vli;
 
	for ( vli = vl->begin(); vli != vl->end(); ++vli ) 
	{//here we'd take off the colinear points to avoid future querys...
		vPP = *vli;
		os = line.oriented_side(vPP->point());
		if ( os == ON_ORIENTED_BOUNDARY )
			continue;
		dist = squared_distance(pcen, vPP->point());
		if ( os == ON_NEGATIVE_SIDE )
		{	if ( dist < dLeft )			
			{	dLeft = dist; vLeft = vPP; }
		}
		else //assert ( os == ON_POSITIVE_SIDE );
		{	if ( dist < dRight )			
			{	dRight = dist; vRight = vPP; }
		}
	}
	assert(vLeft != NULL && vRight != NULL);
}

template <class BeG>
void CMeshSimplifier_2<BeG>::RemoveBorderVertex(Vh v, Vh va, Vh vb)
{
	VBe cena(v,va), cenb(v,vb), ab(va,vb);
	cena.Unmount();	cenb.Unmount();
	m_Tnd->remove(v);
	assert(m_Tnd->is_edge(va,vb));
	ab.Mount();
//	if (m_bDebugTemp) w->Refresh();
}

#endif // !defined(AFX_MeshSimplifier_2_H__0C6CFB7F_5844_45A2_B54B_6B19B1BDD9E0__INCLUDED_)


/*	if (m_bDebugTemp)
	{
		w->UnselectAll();
		w->SelCircleSphere(cirRight);	w->SelCircleSphere(cirLeft);
		w->SelectPoint(pa, 0.3);		w->SelectPoint(pb, 0.3);
	//	w->SelectPoint(vRight->point(), 0.3);	w->SelectPoint(vLeft->point(), 0.3);
		w->Refresh();
		w = w;
	}
*/
