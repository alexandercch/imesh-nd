// mg_io.h

#if !defined(AFX_MG_IO_H__40572867_D02F_4ADE_983F_F28929BB9A77__INCLUDED_)
#define AFX_MG_IO_H__40572867_D02F_4ADE_983F_F28929BB9A77__INCLUDED_

#include <CGAL/basic.h>
#include <CGAL/IO/Window_stream.h>
#include <CGAL/Timer.h>

using namespace CGAL;
using namespace std;

class U_Macros{};//

ofstream		U_outf, U_oftmp;
stringstream*	U_ss;
char			U_out_file_name[512], U_strtmp[512];

#define U_MAKE_OUT_FILE_NAME(n)		sprintf(U_out_file_name, "%s_.out", n); 
#define U_OPEN_OUT					U_outf.open(U_out_file_name);
#define U_OPEN_OUT_ATE				U_outf.open(U_out_file_name, ofstream::out | ofstream::app);	
#define U_CLOSE_OUT					U_outf.close();
#define U_BEGIN(n)					U_MAKE_OUT_FILE_NAME(n);	U_OPEN_OUT; U_ss = NULL;
#define U_END						U_CLOSE_OUT;
#define U_SYSTEM(d)					system(d);	
#define U_CPY_OUT_TO(d)				::sprintf(U_strtmp, "copy %s %s", U_out_file_name, d); U_SYSTEM(U_strtmp);
#define U_CPY_OUT_REOPEN(d)			U_outf.close(); U_outf.flush(); U_CPY_OUT_TO(d); U_OPEN_OUT_ATE;
#define U_CPY_OUT_REOPEN_2(d)		U_CPY_OUT_REOPEN(d); U_CPY_SS(d);
#define U_CPY_SS(d)					if ( U_ss )	{	::sprintf(U_strtmp, "%s%s", d, U_out_file_name);		\
													U_oftmp.open(U_strtmp, ofstream::out | ofstream::app);	\
													U_oftmp<<U_ss->str(); U_oftmp.close();					}	

#define U_ss_or_out(t)				(( U_ss )? ((*U_ss) << t) : (U_outf << t) ) 						
#define U_COUT(t)					(cout << t,	U_ss_or_out(t))
#define U_TCIN(t,v)					(cout << t, cin >> v, U_ss_or_out(t << v << endl))
#define U_TMP_SS_ON					U_TMP_SS_FREE; U_ss = new stringstream;
#define U_TMP_SS_FREE				if (U_ss) delete U_ss; U_ss = NULL;
#define U_TMP_SS_OFF				string U_str = U_ss->str();  U_TMP_SS_FREE; U_COUT(U_str);
#define U_SCOUT(t)					(cout << t)
#define U_STCIN(t)					(cout << t, cin >> v)
#define U_TCIN_ASK_DEF(t,v,d)		(cout << t<<"?",(_getch() == 'k')? (cout<<":",cin>>v,1):(cout<<"\n",v=d) , U_ss_or_out(t << v << endl))

#define U_ENT						U_COUT("\n");
#define U_PRINT_OS_TIME				printf("time="); ::system("time /t"); 
#define U_DEF_TIME(t)				Timer _time##t;
#define U_TAKE_TIME(t,s)			_time##t.start(); s; _time##t.stop();
#define U_START_TIME(t)				_time##t.start();
#define U_STOP_TIME(t)				_time##t.stop();
#define U_PRINT_TIME(t)				U_COUT("{" #t); U_COUT(_time##t.time()); U_COUT("} ");
#define U_PRINT_TIME_E(t)			U_PRINT_TIME(t); U_ENT;
#define U_PRINT_TIME_2(t)			U_COUT("{"); U_COUT(_time##t.time()); U_COUT("}");

#define U_START_DEF_TIME(t)			U_DEF_TIME(t); U_START_TIME(t);
#define U_START_DEF_TIME_			U_START_DEF_TIME(_);
#define U_STOP_PRINT_TIME(t)		U_STOP_TIME(t); U_PRINT_TIME(t);
#define U_STOP_PRINT_TIME_2(t)		U_STOP_TIME(t); U_PRINT_TIME_2(t);
#define U_E_STOP_PRINT_TIME(t)		U_ENT; U_STOP_PRINT_TIME(t);

#define U_BEGIN_PROC(s)				U_COUT("\n\n--- " #s " ---" )
#define U_BEGIN_PROC_E(s)			U_BEGIN_PROC(s); U_ENT;
#define U_BEGIN_PROC_ASK(s)			(U_BEGIN_PROC(s), U_OK_ASK)

#define U_BEGIN_SUB_PROC(s)			U_COUT(" [" #s );
#define U_BEGIN_SUB_PROC_T(s,t)		U_BEGIN_SUB_PROC(s); U_START_DEF_TIME(t); 
#define U_BEGIN_SUB_PROC_T_(s)		U_BEGIN_SUB_PROC_T(s,_);
#define U_E_BEGIN_SUB_PROC_T_(s)	U_ENT; U_BEGIN_SUB_PROC_T_(s);
#define U_E_BEGIN_SUB_PROC_ASK(s)	(U_COUT(" [" #s ), (U_OK_ASK?1:(U_COUT("-no-]"),0)) )  

#define U_END_SUB_PROC				U_COUT("] ");
#define U_END_SUB_PROC_N(n)			U_COUT("-"); U_COUT(n); U_Pe; U_END_SUB_PROC;
#define U_END_SUB_PROC_T(t)			U_STOP_PRINT_TIME_2(t); U_END_SUB_PROC;
#define U_END_SUB_PROC_T_			U_END_SUB_PROC_T(_);
#define U_END_SUB_PROC_T_E			U_END_SUB_PROC_T_;	U_ENT;
#define U_END_SUB_PROC_N_T(n, t)	U_COUT("-"); U_COUT(n); U_STOP_PRINT_TIME_2(t); U_END_SUB_PROC;
#define U_END_SUB_PROC_N_T_E_(n)	U_END_SUB_PROC_N_T(n, _);
#define U_END_SUB_PROC_N_T_(n)		U_END_SUB_PROC_N_T(n,_);
#define U_OK_ASK					(U_COUT("?"), (_getch() == 'k'))
#define U_OK_ASK2(txt)				(U_COUT(txt "?"), (_getch() == 'k'))
#define U_WAIT_S(s)					U_COUT(#s); _getch();
#define U_WAIT						_getch();
#define U_IF_COUNTER(k,t,tx)		if ( ++k%t == 0 ) if ( k%(t*tx) != 0 ) U_SCOUT("."); else

#endif // !defined(AFX_MG_IO_H__40572867_D02F_4ADE_983F_F28929BB9A77__INCLUDED_)