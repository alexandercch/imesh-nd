// MIsoValue_d.h: interface for the CMIsoValue_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MIsoValue_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
#define AFX_MIsoValue_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_

#include "IsoValueList_d.h"

template <class Tni>
class CMIsoValue_d  : public CIsoValueList_d<Tni> 
{
public:
typedef typename CIsoValueList_d<Tni>	IParent;
typedef typename Tni					Tni;
typedef typename Tni::Tn				Tn;
typedef typename Tni::FT				FT;
typedef typename Tn::Point				Point;
typedef typename Tni::Ch				Ch;
typedef typename Tni::Img				Img;
typedef typename Img::Coord				Coord;
typedef typename float					Iv;
typedef typename list<Iv>				IvList;
typedef typename Tni::FI				FI;
public:
	CMIsoValue_d();
	virtual ~CMIsoValue_d();
	void Init(Img* m, Window_stream* ws = NULL);
	inline bool operator()(Coord c);
	inline void begin();
	inline void end();
	inline bool HasBorder();
private:
	Img* m_pImg;
	Iv m_CurrSing, m_LastSing, m_CurrScalar, m_LastScalar, m_GreaterValue;
	int m_nTime;
	Coord m_LastCoord;
	IvList m_ivl;
	bool m_bIsoValue;
	Window_stream* m_ws;
};

template <class Tni>
CMIsoValue_d<Tni>::CMIsoValue_d()
{	m_pImg = NULL;	begin(); }

template <class Tni>
CMIsoValue_d<Tni>::~CMIsoValue_d()
{}

template <class Tni>
void CMIsoValue_d<Tni>::Init(Img* m, Window_stream* ws)
{	m_pImg = m;	m_ws = ws; }

template <class Tni>
inline void CMIsoValue_d<Tni>::begin()	{ m_nTime = 0;	m_bIsoValue = false;}
template <class Tni>
inline void CMIsoValue_d<Tni>::end()	{}

template <class Tni>
inline bool CMIsoValue_d<Tni>::HasBorder()	{ return m_bIsoValue; }

template <class Tni>
inline bool CMIsoValue_d<Tni>::operator()(Coord _CurrCoord)
{
	if ( m_bIsoValue )
		return true;
	m_CurrScalar = (*m_pImg)(_CurrCoord);
	bool bRet = false;
	switch(m_nTime)
	{
	case 0:
		m_LastScalar = m_CurrScalar;
		m_LastCoord = _CurrCoord;
		m_nTime++;
		return bRet;
	default:
		m_bIsoValue |= (*(IParent*)this)(m_LastScalar, m_CurrScalar); 
		m_LastScalar = m_CurrScalar;
		m_LastCoord = _CurrCoord;
		return m_bIsoValue;
	}
}

#endif // !defined(AFX_MIsoValue_d_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
