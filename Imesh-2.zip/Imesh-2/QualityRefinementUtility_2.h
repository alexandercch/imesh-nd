// VVEdge_2.h: interface for the BreakingEdge_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BREAKINGEDGE_2_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_)
#define AFX_BREAKINGEDGE_2_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tn>
class CVertexEdgeNode_2 : public list<Tn::Vertex_handle>
{
typedef CVertexEdgeNode_2<Tn>	Self;
typedef Tn::Vertex_handle		Vh;
public:
	inline void AddEdgeWith(Vh vh);
	inline bool IsEdgeWith(Vh vh);
	static inline Self* GetAllocVENode(Vh vh);
	static inline Self* GetVENode(Vh vh);
};

template<class Tn>
void CVertexEdgeNode_2<Tn>::AddEdgeWith(Vh vh)
{	push_back(vh);	}

template<class Tn>
bool CVertexEdgeNode_2<Tn>::IsEdgeWith(Vh vh)
{
	for ( iterator i = begin(); i != end(); ++i )
		if ( *i == vh )
			return true;
	return false;
}

template<class Tn>
CVertexEdgeNode_2<Tn>::Self* CVertexEdgeNode_2<Tn>::GetAllocVENode(Vh vh)
{
	void*& vp =	vh->Info().VoidPtr();
	if ( !vp )
		vp = new Self;
	return (Self*)vp;
}

template<class Tn>
CVertexEdgeNode_2<Tn>::Self* CVertexEdgeNode_2<Tn>::GetVENode(Vh vh)
{	return (Self*)(vh->Info().VoidPtr());	}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tn>
class CVVEdge_2
{
typedef Tn::Geom_traits			Gt;
typedef Tn::Point				Point;
typedef Tn::Edge				Edge;
typedef Tn::Vertex_handle		Vh;
typedef CVertexEdgeNode_2<Tn>	VENode;
public:
	CVVEdge_2(Vh vh1, Vh vh2);
	CVVEdge_2(Edge e);

	inline bool IsViolated(Point cc);
	inline bool IsBorderEdge();

	Vh vh0, vh1;
};

template <class Tn>
CVVEdge_2<Tn>::CVVEdge_2(Vh _vh0, Vh _vh1)
{
	vh0 = _vh0;	vh1 = _vh1;
}

template <class Tn>
CVVEdge_2<Tn>::CVVEdge_2(Edge e)
{			 
	vh0 = e.first->vertex(e.first->cw(e.second)); vh1 = e.first->vertex(e.first->ccw(e.second));
}

template <class Tn>
bool CVVEdge_2<Tn>::IsViolated(Point cc)
{
	Gt::Circle_2 c(vh0->point(), vh1->point());
	return c.oriented_side(cc) == ON_POSITIVE_SIDE;
}

template <class Tn>
bool CVVEdge_2<Tn>::IsBorderEdge()
{
	VENode *ven0 = VENode::GetVENode(vh0), *ven1 = VENode::GetVENode(vh1);
	return ven0 && ven1 ? ven0->IsEdgeWith(vh1) : false;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tn>
class CBVVEdge_2  
{
public:
typedef CBVVEdge_2<Tn>	Self;
typedef Tn::Vertex_handle		Vertex_handle;
typedef Tn::Point				Point;
typedef pair<Point, double>		Middle_point;
typedef list<Middle_point>		Middle_point_list;

	CBVVEdge_2(Vertex_handle _vh0 = NULL, Vertex_handle _vh1 = NULL);

	bool operator< (const Self& mr) const;	
	typedef /*const*/ Self*	SCPtr;
	struct PLessCPtr 
	{		bool operator() (const SCPtr& c1, const SCPtr& c2) const {	return (*c1 < *c2);	}	};

	void Insert(Point p);

private:
	Vertex_handle vh0, vh1;
	Middle_point_list	middle_points;
};

template<class Tn>
CBVVEdge_2<Tn>::CBVVEdge_2(Vertex_handle _vh0, Vertex_handle _vh1)
{
	assert(_vh0 != _vh1);
	if ( _vh0->Info().ID() < _vh1->Info().ID() )	{	vh0 = _vh0; vh1 = _vh1;	}
	else											{	vh0 = _vh1; vh1 = _vh0;	}
}

template<class Tn>
bool CBVVEdge_2<Tn>::operator< (const Self& r) const
{
	if ( vh0->Info().ID() == r.vh0->Info().ID() )
		return vh1->Info().ID() < r.vh1->Info().ID();
	return vh0->Info().ID() < r.vh0->Info().ID();
}

template<class Tn>
void CBVVEdge_2<Tn>::Insert(Point p)
{
	//assert(p is colinear and is on the segment vh0_vh1);
	Middle_point new_middle(p, CGAL::squared_distance(p, vh0->point()));
	
	if ( !middle_points.size() )
	{
		middle_points.push_back(new_middle);
		return;
	}

	Middle_point_list::iterator it;
	for( it = middle_points.begin(); it != middle_points.end(); ++it )
		if ( new_middle.second < it->second )
			break;
	middle_points.insert(it, new_middle);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_BREAKINGEDGE_2_H__C479B077_A690_4F13_A46A_29988D2116DD__INCLUDED_)
