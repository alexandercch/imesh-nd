// Gradient_d.h: interface for the CGradient_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRADIENT_D_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)
#define AFX_GRADIENT_D_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_

#include "PointDetector_d.h"

template <class Mask, class Err>
class CGradient_d : public CPointDetector_d<Err::Tni>
{
public:
typedef typename Err::Tni				Tni;
typedef typename CGradient_d<Mask,Err>	Self;
typedef typename CPointDetector_d<Tni>	Father;
typedef typename Tni::Tn				Tn;
typedef typename Tni::FT				FT;
typedef typename Tn::Point				Point;
typedef typename Tni::Ch				Ch;
typedef typename Tni::Img				Img;
typedef typename Img::Coord				Coord;
typedef typename Tni::FI				FI;
public:
	CGradient_d();
	virtual ~CGradient_d();
	void Init(Img* m, Tn* pTn, Ws* pWs);
	void ReadParams();
	inline bool operator()(Coord c);
	inline bool PointError(Point c, FT& error);
	inline Self* MeshBorderDetector();
private:
	inline double CoordGradient(Coord c);
protected:
	Mask* m_pMask;
private:
	Err* m_pError;
	double m_fThreshold, m_CurrSing, m_LastSing, 
		   m_CurrScalar, m_LastScalar, m_GreaterValue;
	Coord m_LastCoord;
};

template <class Mask, class Err>
CGradient_d<Mask,Err>::CGradient_d()
{
	m_pMask = NULL;
	m_pError = NULL;
	m_fThreshold = -1;
}

template <class Mask, class Err>
CGradient_d<Mask,Err>::~CGradient_d()
{
	delete m_pMask;	delete m_pError;
}

template <class Mask, class Err>
void CGradient_d<Mask,Err>::Init(Img* pImg, Tn* pTn, Ws* pWs)
{	
	Father::Init(pImg, pTn, pWs);
	m_pMask = new Mask(pImg);
	m_pError = new Err;
}

template <class Mask, class Err>
void CGradient_d<Mask,Err>::ReadParams()
{
	U_TCIN("Gradient-Threshold: ", m_fThreshold);
	m_pError->ReadParams();
}

template <class Mask, class Err>
inline CGradient_d<Mask,Err>::Self* CGradient_d<Mask,Err>::MeshBorderDetector()
{	return NULL;	}

template <class Mask, class Err>
inline bool CGradient_d<Mask,Err>::PointError(Point c, FT& error)
{
	return (*m_pError)(c, m_CurrCell, error);
}

template <class Mask, class Err>
inline double CGradient_d<Mask,Err>::CoordGradient(Coord c)
{
//	double &g = (*m_pImg)(c).Gradient();
//	if ( g != -1 )
//		return g;
//	g = m_pMask->Convolution(c);
//	return g;

	return m_pMask->Convolution(c);
}

template <class Mask, class Err>
inline bool CGradient_d<Mask,Err>::operator()(Coord c)
{
	m_CurrScalar = CoordGradient(c);
	bool bRet = false;
	switch(m_nTime)
	{
	case 0:
		m_LastScalar = m_CurrScalar;
		m_nTime++;
		return bRet;
	case 1:
		m_LastSing = m_CurrScalar - m_LastScalar;
		m_LastScalar = m_CurrScalar;
		m_LastCoord = c;
		m_nTime++;
		return bRet;
	default:
		m_CurrSing = m_CurrScalar - m_LastScalar;
		if ( ( m_LastSing > 0 && m_CurrSing <= 0 ) ||		/* + /\ - */
			 ( m_LastSing = 0 && m_CurrSing < 0 )		)	/* 0 -\ - */
		{
			if ( m_LastScalar > m_fThreshold )
			{	m_LastDetectedCoord = FI::ItoF(m_LastCoord);	bRet = true;	}
			else bRet = false;
		}
		m_LastSing = m_CurrSing;
		m_LastScalar = m_CurrScalar;
		m_LastCoord = c;
		return bRet;
	}
}

#endif // !defined(AFX_GRADIENT_D_H__578BAFFD_3844_470D_AA15_B1C78FF17145__INCLUDED_)


