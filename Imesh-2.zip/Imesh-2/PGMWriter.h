// PGMWriter.h: interface for the CPGMWriter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PGMWRITER_H__083E9CE2_7BE8_4EBF_A6F8_63E8BC43DD64__INCLUDED_)
#define AFX_PGMWRITER_H__083E9CE2_7BE8_4EBF_A6F8_63E8BC43DD64__INCLUDED_

template <class Img>
class CPGMWriter  
{
public:
typedef typename Img::IntTraits		IT;
typedef typename IT::RectangleI_2	RectangleI_2;
public:
	CPGMWriter(Img* m);
	virtual ~CPGMWriter();
	void Write(string name);
private:
	Img* m_pImg;
};

template <class Img>
CPGMWriter<Img>::CPGMWriter(Img* m)
{
	m_pImg = m;
}

template <class Img>
CPGMWriter<Img>::~CPGMWriter()
{}

template <class Img>
void CPGMWriter<Img>::Write(string name)
{
	RectangleI_2 r = m_pImg->RectI();
	int i, j;

	FILE* pf = ::fopen(name.c_str(), "w");
	
	::fprintf(pf, "P2\n");
	::fprintf(pf, "# Created by Imesh::CPGMWriter\n");
	::fprintf(pf, "%d %d\n", r.xmax()-r.xmin()+1, r.ymax()-r.ymin()+1);
	::fprintf(pf, "255\n");
	
	for ( j = r.ymax(); j >= r.ymin(); --j )
	{	
		for ( i = r.xmin(); i <= r.xmax(); ++i )
			::fprintf(pf, "%d ", (*m_pImg)(i,j) );
		::fprintf(pf, "\n");
	}

	::fclose(pf);
}


#endif // !defined(AFX_PGMWRITER_H__083E9CE2_7BE8_4EBF_A6F8_63E8BC43DD64__INCLUDED_)
