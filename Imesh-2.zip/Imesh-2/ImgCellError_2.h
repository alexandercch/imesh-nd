// ImgCellError_2.h: interface for the CImgCellError_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ImgCellError_2_H__2775539F_92CB_40C2_AD90_59B4B3B4B6FA__INCLUDED_)
#define AFX_ImgCellError_2_H__2775539F_92CB_40C2_AD90_59B4B3B4B6FA__INCLUDED_

template <class Traits>
class CImgCellError_2
{
public:
typedef typename Traits::Img						Img;
typedef typename Img::Coord							Coord;
typedef typename Img::IntTraits						IT;
typedef typename IT::PointI_2						PointI;
typedef typename Traits::Tn							Tn;
typedef typename Tn::Geom_traits					Gt;
typedef typename Gt::FT								FT;
typedef typename FT									Key;
typedef typename Tn::Face_handle					Cell_handle;
typedef typename Tn::Point							Point;
typedef typename Traits::PtErr						PtErr;		
typedef typename Traits::PointDetector				PointDetector;
typedef typename PointDetector::PrePoint			PrePoint;
typedef typename Traits::PointSelector				PointSelector;
typedef typename Traits::InCellPointSelector		InCellPointSelector;
typedef typename Traits::Ls							Ls;
typedef typename Traits::FI							FI;

public:
	CImgCellError_2();
	virtual ~CImgCellError_2();
	void Init(Img* pImg, Tn* pTn, Window_stream* ws);
	inline bool operator()(Cell_handle& ch, PrePoint& bp, FT& error);
	void ReadParams();
	void TestImg();
	inline Point FinalPoint(PrePoint& p);

private:
	Img* m_pImg;
	Tn* m_pTn;
	Window_stream* m_ws;

	Ls m_ls;	
	PointDetector m_pd;
	PointSelector m_ps;
	InCellPointSelector m_icps;
};

template <class Traits>
CImgCellError_2<Traits>::CImgCellError_2()
{
	m_pImg = NULL;
	m_pTn = NULL;
}

template <class Traits>
CImgCellError_2<Traits>::~CImgCellError_2()
{}

template <class Traits>
void CImgCellError_2<Traits>::Init(Img* pImg, Tn* pTn, Window_stream* ws)
{
	m_pImg = pImg;
	m_pTn = pTn;
	m_ws = ws;
	m_pd.Init(m_pImg, m_pTn, m_ws);
	m_ps.Init(m_pTn);
	m_icps.Init(&m_pd, &m_ps);
}

template <class Traits>
void CImgCellError_2<Traits>::ReadParams()
{
	m_icps.ReadParams();
}

template <class Traits>
void CImgCellError_2<Traits>::TestImg()
{	m_pd.TestImg();	}

template <class Traits>
inline CImgCellError_2<Traits>::Point
CImgCellError_2<Traits>::FinalPoint(PrePoint& p)
{	return m_pd.FinalPoint(p);	}

template <class Traits> //DivisionTest
bool CImgCellError_2<Traits>::operator()(Cell_handle& ch, PrePoint& bp, FT& error)
{
	Tn::Triangle t = m_pTn->triangle(ch);
	Point 	c0p( FI::Median(t[1], t[2]) ),
			c1p( FI::Median(t[2], t[0]) ),
			c2p( FI::Median(t[1], t[0]) );

	SegmentI_2	l0( FI::FtoI(t[0]), FI::FtoI(c0p) ), 
				l1( FI::FtoI(t[1]), FI::FtoI(c1p) ), 
				l2( FI::FtoI(t[2]), FI::FtoI(c2p) );
	
	m_icps.SetCurrCell(ch);
	m_icps.begin(); m_ls(&l0, &m_icps); m_icps.end();
	m_icps.begin(); m_ls(&l1, &m_icps); m_icps.end();
	m_icps.begin(); m_ls(&l2, &m_icps); m_icps.end();
	
	return m_icps.IsSelectedPoint(bp,error);
}



#endif // !defined(AFX_ImgCellError_2_H__2775539F_92CB_40C2_AD90_59B4B3B4B6FA__INCLUDED_)
