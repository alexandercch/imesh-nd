// TnCellList_2.h: interface for the CTnCellList_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TNCELLLIST_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)
#define AFX_TNCELLLIST_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_


template <class Tn, class Ord>
class CTnCellList_2
{
public:
typedef typename Tn::Geom_traits	Gt;
typedef typename Gt::FT				FT;
typedef typename Tn::Face_handle	Ch;
typedef typename Tn::Vertex_handle	Vh;
typedef typename Tn::Point			Point;
typedef typename list<Ch>			Cl;

public:
	CTnCellList_2();
	virtual ~CTnCellList_2();
	void Init(Tn* pTn, Ord* pOrd);
	inline bool PopFront(Ch& ch, Point& bp);
	inline void FirstRegCell(Ch ch);
	inline void UpdateStar(Vh& vh, long last_face_id);
	inline int	Size();
private:
	inline void TryRegCell(Ch ch);
private:
	Cl m_cl;
	Tn* m_pTn;
	Ord* m_pOrd;
};

template <class Tn, class Ord>
CTnCellList_2<Tn,Ord>::CTnCellList_2()
{
	m_pTn = NULL;	m_pOrd = NULL;
}

template <class Tn, class Ord>
CTnCellList_2<Tn,Ord>::~CTnCellList_2()
{}

template <class Tn, class Ord>
void CTnCellList_2<Tn,Ord>::Init(Tn* pTn, Ord* pOrd)
{
	m_pTn = pTn; m_pOrd = pOrd;
}

template <class Tn, class Ord>
int	CTnCellList_2<Tn,Ord>::Size()
{	return m_cl.size();	}

template <class Tn, class Ord>
bool CTnCellList_2<Tn,Ord>::PopFront(Ch& ch, Point& bp)
{
	if ( m_cl.empty() )
		return false;;
	ch = m_cl.front(); m_cl.pop_front();
	ch->Info().Flag() = 1;
	void*& vp = ch->Info().VoidPtr();
	assert(!!vp);
	bp = *((Point*)vp);
	delete vp;
	vp = NULL;
	return true;
}

template <class Tn, class Ord>
void CTnCellList_2<Tn,Ord>::FirstRegCell(Ch ch)
{
	TryRegCell(ch);// the first cell registration affair can be optimized
}

template <class Tn, class Ord>
void CTnCellList_2<Tn,Ord>::TryRegCell(Ch ch)
{
	Point bp;
	FT error;
	bool b = (*m_pOrd)(ch, bp, error);
	ch->Info().Flag() = !b;
	if ( b )
	{	
		void*& vp = ch->Info().VoidPtr();
		assert(!vp);
		vp = new Point(bp);
		m_cl.push_back(ch);
	}
}

template <class Tn, class Ord>
void CTnCellList_2<Tn,Ord>::UpdateStar(Vh& vh, long last_face_id)
{//In CGAL Delaunay triangulation no cell is eliminated at this time -- only at the beginning.
	Tn::Face_circulator sc, done;
	done = sc = vh->incident_faces();
	do
	{	
		if ( m_pTn->is_infinite(sc) )
			continue;
		if ( sc->Info().ID() >= last_face_id ||		//new faces
			 sc->Info().Flag() == 1 )				//old tested faces
		{	
			TryRegCell(sc);	
		}
	} while(--sc != done);
}

#endif // !defined(AFX_TNCELLLIST_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)