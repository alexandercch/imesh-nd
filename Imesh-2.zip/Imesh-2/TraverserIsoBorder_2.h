// TraverserIsoBorder_2.h: interface for the CTraverserIsoBorder_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TraverserIsoBorder_2_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_)
#define AFX_TraverserIsoBorder_2_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_

#include "LineScan.h"
#include "MIsoValue_d.h"
#include "MeshBorderDetector_d.h"

template <class Tni>
class CTraverserIsoBorder_2  : public CMeshBorderDetector_d<Tni> 
{
public:
typedef typename CMeshBorderDetector_d<Tni> BParent;
typedef typename Tni						Tni;
typedef typename Tni::Ch					Ch;
typedef typename Tni::Be					Be;
typedef typename Tni::Tn					Tn;
typedef typename Tni::IT					IT;
typedef typename Tni::FI					FI;
typedef typename Tn::Point					Point;
typedef typename Tni::Img					Img;
typedef typename CMIsoValue_d<Tni>			Miv;
typedef typename CLineScan<Miv,IT>			Sline;
public:
	void Init(Tn* pTn, Img* pImg, Window_stream* ws);
	void ReadParams();
	inline void Clear();
	inline EMeshBorder operator()(Be be);
	inline operator string();
private:
	Sline m_sl;
	Miv m_miv;
};
template <class Tni>
void CTraverserIsoBorder_2<Tni>::Init(Tn* pTn, Img* pImg, Window_stream* ws)
{	
	BParent::Init(pTn, pImg, ws);	
	m_miv.Init(m_pImg, m_ws);
}

template <class Tni>
inline void CTraverserIsoBorder_2<Tni>::Clear()
{	m_miv.Clear();	}

template <class Tni>
CTraverserIsoBorder_2<Tni>::operator string()
{	
	string s = (string)m_miv;
	return s.empty() ?	string("Mbd: off") : 
						string("Mbd: CTraverserIsoBorder_2: ") + s;
}

template <class Tni>
void CTraverserIsoBorder_2<Tni>::ReadParams()
{	m_miv.ReadParams();	}

template <class Tni>
inline CTraverserIsoBorder_2<Tni>::EMeshBorder CTraverserIsoBorder_2<Tni>::operator()(Be be)
{
	Ch ch1, ch2; 
	int i;
	bool b1, b2, bBorder;
	Point facet_cen, ch1_cen, ch2_cen;
	Tn::Triangle tt;
	
	ch1	= be.first;
	i = be.second;
	b1 = m_pTn->is_infinite(ch1);
	ch2 = ch1->neighbor(i);
	b2 = m_pTn->is_infinite(ch2);

	if ( (b1 && !b2) || (!b1 && b2) )	return be_extern_border;
	if ( b1 && b2 )						return be_no_border;

	Point p1, p2;
	p1 = ch1->vertex((i+1)%3)->point();
	p2 = ch1->vertex((i+2)%3)->point();
	if ( ( p1.x() == 145.5 && p1.y() == 284.5 && 
		  p2.x() == 152.5 && p2.y() == 275.5 )   ||
		 ( p2.x() == 145.5 && p2.y() == 284.5 && 
		  p1.x() == 152.5 && p1.y() == 275.5 )			)
		  p1 = p1;

	facet_cen = FI::Median(p1, p2);
	tt = m_pTn->triangle(ch1);	ch1_cen = centroid(tt[0], tt[1], tt[2]);
	tt = m_pTn->triangle(ch2);	ch2_cen = centroid(tt[0], tt[1], tt[2]);
	IT::SegmentI_2	seg1(FI::FtoI(ch1_cen),	  FI::FtoI(facet_cen)), 
					seg2(FI::FtoI(facet_cen), FI::FtoI(ch2_cen));
	
	m_miv.begin(); m_sl(&seg1, &m_miv); 
	bBorder = m_miv.HasBorder();
	if ( !bBorder )
	{	m_sl(&seg2, &m_miv); 
		bBorder = m_miv.HasBorder();				
	}
	
	return bBorder ? be_border : be_no_border;
}

#endif // !defined(AFX_TraverserIsoBorder_2_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_)
