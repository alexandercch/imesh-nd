// EdgeFilter.h: interface for the CEdgeFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDGEFILTER_H__C529D117_6DF7_4F6D_AA0C_BDB3F907173F__INCLUDED_)
#define AFX_EDGEFILTER_H__C529D117_6DF7_4F6D_AA0C_BDB3F907173F__INCLUDED_

template <class _Image, class _Mask>
class CEdgeFilter  
{
public:
	typedef typename _Image::IndexType IndexType;
	CEdgeFilter(_Image* m, _Mask* _mask);
	virtual ~CEdgeFilter();
	inline void operator()(IndexType x, IndexType y);
	void Make255();
	void MakeThreshold(int ts = 255/5);
	_Image* EdgeImage();
	double MaxValue() const;

private:
	_Image* matrix, *edge_image;
	_Mask* mask;
	double max_value;
	int threshold;
};

template <class _Image, class _Mask>
CEdgeFilter<_Image,_Mask>::CEdgeFilter(_Image* m, _Mask* _mask)
{
	matrix = m;
	mask = _mask;
	edge_image = new _Image(matrix->XMax(), matrix->YMax());
	max_value = 0;

	RectangleI_2 r(0,0, matrix->XMax()-1, matrix->YMax()-1);
	CMedian<_Image> median(matrix);
	CRectScan<CMedian<_Image > > rs;
		rs(&r, &median);
	threshold = 2*::sqrt(median.Result());
}

template <class _Image, class _Mask>
CEdgeFilter<_Image,_Mask>::~CEdgeFilter()
{	delete edge_image;	}

template <class _Image, class _Mask>
_Image* CEdgeFilter<_Image,_Mask>::EdgeImage()
{	return edge_image;	}

template <class _Image, class _Mask>
double CEdgeFilter<_Image,_Mask>::MaxValue() const
{	return max_value;	}

template <class _Image, class _Mask>
void CEdgeFilter<_Image,_Mask>::MakeThreshold(int ts)
{
	_Image::iterator i;
	for ( i = edge_image->begin(); i != edge_image->end(); ++i )
		*i = *i*(*i>ts);
}

template <class _Image, class _Mask>
void CEdgeFilter<_Image,_Mask>::Make255()
{
	_Image::iterator i;
	for ( i = edge_image->begin(); i != edge_image->end(); ++i )
		*i = *i*255/max_value;
}

template <class _Image, class _Mask>
inline void CEdgeFilter<_Image,_Mask>::operator()(IndexType x, IndexType y)
{
	double r = mask->Convolution(x,y);
	(*edge_image)(x,y) = r;
	if ( r > max_value )
		max_value = r;
}

#endif // !defined(AFX_EDGEFILTER_H__C529D117_6DF7_4F6D_AA0C_BDB3F907173F__INCLUDED_)
