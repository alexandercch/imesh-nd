// Statistics.h: interface for the CStatistics class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STATISTICS_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_)
#define AFX_STATISTICS_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_

#include <math.h>
#include <list>
#include "Primitives_2.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////

template <class _Matrix>
class CVariance
{
	double sum, result, median;	
	int N;	
	_Matrix* matrix;
public:
	CVariance(_Matrix* m, double med) 
	{
		sum = 0; N = 0;
		matrix = m;
		median = med;
	}
	inline void operator()(_Matrix::IndexType x, _Matrix::IndexType y)
	{	
		N++;
		int xi = (*matrix)(x,y); 		
		sum += pow(xi-median, 2);
	}
	double Result()
	{		return ::sqrt(double(sum)/(N+0.0));	}
	int Area()
	{		return N;	}
};

////////////////////////////////////////////////////////////////////////////////

template <class _Matrix>
class CHistogram
{
	struct SCount
	{
		SCount(int v = -1, int c = 0){value = v; count = c;}
		int value, count;
	};

	std::list<SCount> values;
	_Matrix* matrix;
	int N, maxcount, maxvalue; 

public:
	CHistogram(_Matrix* m) 	{		matrix = m;		N = 0;		maxcount = 1; 	}

	inline void operator()(_Matrix::IndexType x, _Matrix::IndexType y)
	{	
		N++;
		int xi = (*matrix)(x,y); 
		list<SCount>::iterator li;
		for ( li = values.begin(); li != values.end(); ++li )
		{
			if ( (*li).value == xi )
			{	
				(*li).count++;
				if ( (*li).count > maxcount )
				{
					maxcount = (*li).count;
					maxvalue = (*li).value;
				}
				return;
			}
		}
		values.push_back(SCount(xi, 1));
	}

	inline int PredominantValueArea()		{	return maxcount;		}
	inline int PredominantValue()			{	return maxvalue;		}
	inline int NonPredominantValueArea()	{	return N - maxcount;	}
	inline int Area()						{	return N;				}
};

////////////////////////////////////////////////////////////////////////////////
template <class _Matrix, class _Mask>
class CEdgeDetector
{
private:
	_Matrix* m_pMatrix;
	_Mask m_mask;
	double m_fThreshold;
	bool m_bEdge;
public:	
	CEdgeDetector(_Matrix* m, double fThreshold) : m_mask(m)
	{		m_pMatrix = m;		m_fThreshold = fThreshold;		m_bEdge = false;	}

	inline void operator()(unsigned long x, unsigned long y)
	{		m_bEdge |= (m_mask.Convolution(x,y) >= m_fThreshold);		}
	
	inline bool EdgeFound()	
	{		return m_bEdge;											}
};

////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_STATISTICS_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_)


