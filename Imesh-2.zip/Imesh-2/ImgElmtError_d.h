// ImgElmtError_d.h: interface for the CImgElmtError_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ImgElmtError_d_H__B80E9754_26E7_4649_8DFE_AACEB8DF9B14__INCLUDED_)
#define AFX_ImgElmtError_d_H__B80E9754_26E7_4649_8DFE_AACEB8DF9B14__INCLUDED_

#include "PointDetector_d.h"

template <class Tni>
class CImgElmtError_d  : public CPointDetector_d<Tni>
{
public:
typedef typename CImgElmtError_d<Tni>	Self;
typedef typename Tni::Tn				Tn;
typedef typename Tni::Gt				Gt;
typedef typename Tni::FT				FT;
typedef typename Tn::Point				Point;
typedef typename Tni::Ch				Ch;
typedef typename Tni::Img				Img;
typedef typename Img::Coord				Coord;
typedef typename Tni::FI				FI;

public:
	CImgElmtError_d();
	virtual ~CImgElmtError_d();
	void ReadParams();	
	inline bool operator()(Coord c);
	virtual bool PointError(Point coord, FT& ft) = 0;
private:
	FT m_fThreshold;
};

template <class Tni>
CImgElmtError_d<Tni>::CImgElmtError_d()
{
	m_fThreshold = -1;
}

template <class Tni>
CImgElmtError_d<Tni>::~CImgElmtError_d()
{}

template <class Tni>
void CImgElmtError_d<Tni>::ReadParams()
{
	U_TCIN("ImgElmt-Threshold: ", m_fThreshold);			
}	

template <class Tni>
inline bool CImgElmtError_d<Tni>::operator()(Coord coord)
{
	FT ft;
	Point pp = FI::ItoF(coord);
	if ( !PointError(pp, ft) )
		return false;
	if ( ft > m_fThreshold ) 
	{
		m_LastDetectedCoord = pp;
		return true;
	}
	return false;
}

#endif // !defined(AFX_ImgElmtError_d_H__B80E9754_26E7_4649_8DFE_AACEB8DF9B14__INCLUDED_)
