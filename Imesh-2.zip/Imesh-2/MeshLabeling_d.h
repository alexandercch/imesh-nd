// MeshLabeling_d.h: interface for the CMeshLabeling_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MESHLABELING_D_H__78580078_BB4B_4576_B00A_D50054CCEADD__INCLUDED_)
#define AFX_MESHLABELING_D_H__78580078_BB4B_4576_B00A_D50054CCEADD__INCLUDED_

#include WRITER_H
#include "MeshRegion_d.h"

template <class Tni>
class CMeshLabeling_d  
{
typedef WRITER_CLASS<Tni>				Writer;
typedef Tni::Tnd						Tnd;
typedef Tnd::Tn							Tn;
typedef Tnd::FT							FT;
typedef Tnd::Point						Point;
typedef Tnd::Ch							Ch;	
typedef Tnd::Be							Be;
typedef Tnd::Cell_list					Cell_list;
typedef Tnd::CIt						CIt;
typedef pair<Point,int>					MeshRgnSeed;
typedef list<MeshRgnSeed>				MeshRgnSeed_list;
typedef Tnd::VBe						VBe;
typedef CMeshRegion_d<Tni>				MeshRegion;
typedef MeshRegion::MeshRegionVector	Mrv;

public:
	CMeshLabeling_d();
	virtual ~CMeshLabeling_d();
	void Init(Tn* pTn, Mrv* pMrv = NULL, Writer* _w = NULL);
	void LoadLabeling();
	MeshRgnSeed GenerateMeshRgnSeed(Ch sh);
	void UnloadLabeling();
	void PropagateMeshRgnSeed(Point point, int idRgn);
	void SRefresh();

private:
	Tnd m_Tnd;
	Tn*	m_pTn;
	Writer* w;
	MeshRgnSeed_list m_MRSeedList;
	bool m_bLabelsLoaded;
	Mrv* m_pMrv;
};

template <class Tni>
CMeshLabeling_d<Tni>::CMeshLabeling_d()		{	m_pTn = NULL; m_pMrv = 0; w = 0; m_bLabelsLoaded = false; };
template <class Tni>
CMeshLabeling_d<Tni>::~CMeshLabeling_d()	{};
template <class Tni>
void CMeshLabeling_d<Tni>::Init(Tn* pTn, Mrv* pMrv, Writer* _w)	
{	
	w = _w;
	m_Tnd.Init(m_pTn = pTn);	
	m_bLabelsLoaded = false;
	m_pMrv = pMrv;
}

template <class Tni>
void CMeshLabeling_d<Tni>::SRefresh()	
{	
	m_pMrv->FixCellsToRegions(true); 	
	w->Refresh();
}

template <class Tni>
void CMeshLabeling_d<Tni>::LoadLabeling()
{
	U_BEGIN_SUB_PROC_T_(LoadLabeling);

	CIt ci;
	MeshRgnSeed mrs;
	m_MRSeedList.clear();
	for ( ci = m_Tnd.cells_begin(); ci != m_Tnd.cells_end(); ++ci )	
		ci->info().Flag() = -1;
	for ( ci = m_Tnd.cells_begin(); ci != m_Tnd.cells_end(); ++ci )	
	{
		if ( ci->info().Flag() == -1 )
		{
			mrs = GenerateMeshRgnSeed(ci);
			m_MRSeedList.push_back(mrs);
			//w->SelectPoint(mrs.first);
		}
	}

	m_bLabelsLoaded = true;
	U_END_SUB_PROC_N_T_(m_MRSeedList.size());
}

template <class Tni>
CMeshLabeling_d<Tni>::MeshRgnSeed CMeshLabeling_d<Tni>::GenerateMeshRgnSeed(Ch sh)
{
	Cell_list sl;
	Ch ni, s;
	int i, idRgn = sh->info().Region();
	Point seed_point = m_Tnd.Centroid(sh);
	FT area, seed_area = m_Tnd.Aread(sh);
	
	sl.push_back(sh);
	while( !sl.empty() )
	{
		s = sl.front(); sl.pop_front();
		s->info().Flag() = 2;
		
		area = m_Tnd.Aread(s);
		if ( area > seed_area )
		{
			seed_area = area;
			seed_point = m_Tnd.Centroid(s);
		}

		for ( i = 0; i < Tnd::NCellSides; i++ )
		{
			if ( VBe(Be(s,i)).IsBorderElement() )
				continue;
			ni = s->neighbor(i);
			if ( m_Tnd->is_infinite(ni) || ni->info().Flag() != -1 )
				continue;
			sl.push_back(ni);
			ni->info().Flag() = 1;
		}
	}
	return MeshRgnSeed(seed_point, idRgn);
}

template <class Tni>
void CMeshLabeling_d<Tni>::UnloadLabeling()
{
	U_BEGIN_SUB_PROC_T_(UnloadLabeling);
	assert(m_bLabelsLoaded == true);
	
	for ( CIt ci = m_Tnd.cells_begin(); ci != m_Tnd.cells_end(); ++ci )	
		ci->info().Region() = -7;
	
	for ( MeshRgnSeed_list::iterator si = m_MRSeedList.begin(); si != m_MRSeedList.end(); ++si )
		PropagateMeshRgnSeed(si->first, si->second);
	
	U_END_SUB_PROC_T_E;
}

template <class Tni>
void CMeshLabeling_d<Tni>::PropagateMeshRgnSeed(Point point, int idRgn)
{
	Ch sh, ni, s;
	Cell_list sl;
	int i;
	sh = m_Tnd->locate(point);
	assert(sh != NULL);
	sl.push_back(sh);
	
	while( ! sl.empty() )
	{
		s = sl.front(); sl.pop_front();
		s->info().Region() = idRgn;
		for ( i = 0; i < Tnd::NCellSides; i++ )
		{
			if ( VBe(Be(s,i)).IsBorderElement() )
				continue;
			ni = s->neighbor(i);
			if ( m_Tnd->is_infinite(ni) )
				continue;
			if ( ni->info().Region() == -7 )
			{
				ni->info().Region() = -8;
				sl.push_back(ni);
			}
		}
	}
}

#endif // !defined(AFX_MESHLABELING_D_H__78580078_BB4B_4576_B00A_D50054CCEADD__INCLUDED_)
