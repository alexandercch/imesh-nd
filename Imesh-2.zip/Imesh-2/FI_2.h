// FI_2.h: interface for the CFI_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FI_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)
#define AFX_FI_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_

#include "Mat_d.h"

template <class Tn, class IT>
class CFI_2
{
public:
typedef typename Tn::Geom_traits	Gt;
typedef typename Gt::FT				FT;
typedef typename Gt::Point_2		Point;
typedef typename Tn::Face_handle	Ch;
typedef typename IT::PointI_2		PointI;
typedef typename IT::TriangleI_2	TriangleI;	
typedef typename IT::INT			INT;
typedef typename CMat_d<FT,INT>		Mat;

	static inline Point ItoF(PointI c)		
	{	return Point(c.x(), c.y());	}
	
	static inline PointI FtoI(Point p)		
	{	return PointI( Mat::Round(p.x()), Mat::Round(p.y()) );	}
	
	static inline Point Median(Point c1, Point c2)	
	{	return Point( (c1.x()+c2.x())/2.0, (c1.y()+c2.y())/2.0 );	}

	static inline TriangleI_2 FtoI(Ch c)
	{	return TriangleI( FtoI(c->vertex(0)->point()),
						  FtoI(c->vertex(1)->point()),
						  FtoI(c->vertex(2)->point()) );
	}

	static inline FT CArea(Tn* pTn, Ch c)
	{	return pTn->triangle(c).area();	}

	static inline FT MaxEdge(Ch c)
	{
		Point p0 = c->vertex(0)->point(), p1 = c->vertex(1)->point(), p2 = c->vertex(2)->point();
		FT max, tt;
		max = squared_distance(p0, p1); 
		tt  = squared_distance(p1, p2);	if ( tt > max )	 max = tt;
		tt  = squared_distance(p2, p0);	if ( tt > max )	 max = tt; 
		max = ::sqrt(max);
		return max;
	}
};

#endif // !defined(AFX_FI_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)