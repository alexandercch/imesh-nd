// PointFarest_d.h: interface for the CPointFarest_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PointFarest_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_)
#define AFX_PointFarest_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_

#include "PointSelector_d.h" 

template <class PD>
class CPointFarest_d  : public CPointSelector_d<PD>  
{
public:
typedef typename CPointSelector_d<PD>	Parent;
typedef typename PD::Tni				Tni;
typedef typename Tni::Tn				Tn;
typedef typename Tni::Ch				Ch;
typedef typename Tni::Vh				Vh;
typedef typename Tni::FT				FT;
typedef typename Tn::Point				Point;

public:
	inline void SetCurrCell(Ch ch);
	inline bool operator()(Point c);
private:	
	FT m_GreaterDistance;
};


template <class PD>
void CPointFarest_d<PD>::SetCurrCell(Ch ch)
{
	Parent::SetCurrCell(ch);
	m_GreaterDistance = 0; 
}

template <class PD>
inline bool CPointFarest_d<PD>::operator()(Point c)
{
	Vh nvh = m_pTn->nearest_vertex(c);
	double dist = ::sqrt(squared_distance(c, nvh->point()));	
	if ( dist > m_GreaterDistance )
	{
		m_bSelectedCoord = true;		
		m_GreaterDistance = dist;
		m_SelectedCoord = c;			
		return true;
	}
	return false;
}

#endif // !defined(AFX_PointFarest_d_H__0C63765A_E6FB_46DC_B933_A1DE452C5AD0__INCLUDED_)
