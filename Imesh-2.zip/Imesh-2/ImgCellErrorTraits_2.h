// ImgCellErrorTraits_2.h: interface for the CImgCellErrorTraits_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMGCELLERRORTRAITS_2_H__0EFB5201_8F5B_4F27_A304_8DEF9110BFDE__INCLUDED_)
#define AFX_IMGCELLERRORTRAITS_2_H__0EFB5201_8F5B_4F27_A304_8DEF9110BFDE__INCLUDED_

#include "InCellPointSelector_d.h"
#include "PointNearest_d.h"
#include "PointFarest_d.h"
#include "Gradient_2.h"
#include "ImgElmtError_2.h"
#include "IsoValue_2.h"
#include "ThreeAreasTest_2.h"
#include "ImgScan_2.h"
#include "FDMIOp_d.h"
#include "GOp_d.h"
#include "NullProjection_d.h"
#include "PointCloudProjection_2.h"
#include "JProjection_2.h"
#include "SmoothIsoSurfProj_2.h"

template <class Tni>
class CImgCellErrorTraits_2  
{
public:
typedef typename Tni														Tni;	
typedef typename Tni::Img													Img;	
typedef typename Tni::FI													FI;
typedef typename Img::IntTraits												IT;
typedef typename Tni::Tn													Tn;
typedef typename Tn::Geom_traits											Gt;
typedef typename Gt::FT														FT;
typedef typename Tn::Point													Point;
typedef typename pair<Point, FT>											PtErr;
typedef typename CThreeAreasTest_2<Tni>										AError;	
typedef typename CSobel33<Img>												GradientMask;

//typedef typename CLaplacian33<Img>											IvMask;
//typedef typename CFDMIOp_d<IvMask>											AIvOp;
typedef typename CSobel33<Img>												IvMask;
typedef typename CGOp_d<IvMask>												AIvOp;

typedef typename CImgScan_2<Tni,AIvOp>										AIvScanner;
//typedef typename CCellMediansScan_2<Tni,AIvOp>								AIvScanner;

//typedef typename CJProjection_2<Tni>										Pro;
//typedef typename CPointCloudProjection_2<Tni>								Pro;
//typedef typename CNullProjection_d<Tni>										Pro;
typedef typename CSmoothIsoSurfProj_2<Tni>									Pro;

typedef typename CIsoValue_2<AError,AIvScanner,Pro>							PointDetector;
//typedef typename CGradient_2<GradientMask,AError>							PointDetector;
//typedef typename CImgElmtError_2<Tni>										PointDetector;

typedef typename CPointNearest_d<PointDetector>								PointSelector;
//typedef typename CPointFarest_d<PointDetector>								PointSelector;	
typedef typename CInCellPointSelector_d<PointDetector, PointSelector>		InCellPointSelector;
typedef typename CLineScan<InCellPointSelector, IT>							Ls;
typedef typename PointDetector												MeshBorderDetector;
};

#endif // !defined(AFX_IMGCELLERRORTRAITS_2_H__0EFB5201_8F5B_4F27_A304_8DEF9110BFDE__INCLUDED_)
