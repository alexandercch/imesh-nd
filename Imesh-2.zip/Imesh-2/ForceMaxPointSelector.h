// ForceMaxPointSelector.h: interface for the CStatistics class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ForceMaxPointSelector_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_)
#define AFX_ForceMaxPointSelector_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_

#include <math.h>

template <class Tn, class Image, class Mask>
class CForceMaxPointSelector
{
public:
typedef typename Image::Coord		Coord;
typedef typename Tn::Vertex_handle	Vh;
typedef typename Tn::Point			Point;
	CForceMaxPointSelector(Tn* pTn, Image* m, double fThreshold);
	inline void operator()(Coord c);
	inline double CoordGradient(Coord c);
	inline bool TestLastHighScalar();
	Coord GreaterCoord();
	double 	GreaterValue();
	int WalkedArea();
	void begin();
	void end();
	bool NoAction();
private:
	Tn* m_pTn;
	Image* m_pImage;
	Mask m_Mask;
	Coord m_GreaterCoord, m_LastCoord, m_BeginPoint;
	double m_CurrSing, m_LastSing, m_CurrScalar, m_LastScalar, m_GreaterValue, m_fThreshold, m_GreaterDistance;
	int m_nTime;
	int m_nWalkedArea;
};

template <class Tn, class Image, class Mask>
CForceMaxPointSelector<Tn,Image,Mask>::
CForceMaxPointSelector(Tn* pTn, Image* m, double fThreshold)
				:m_Mask(m)
{
	m_pTn = pTn;
	m_pImage = m;
	m_nTime = 0;
	m_GreaterValue = 0;
	m_GreaterDistance = 0;
	m_fThreshold = fThreshold;
	m_nWalkedArea = 0;
}

template <class Tn, class Image, class Mask>
void CForceMaxPointSelector<Tn,Image,Mask>::begin()
{		
	m_nTime = 0;
}

template <class Tn, class Image, class Mask>
void CForceMaxPointSelector<Tn,Image,Mask>::end()
{		
	if ( m_LastSing > 0 )		/* /+ */
		TestLastHighScalar();
}

template <class Tn, class Image, class Mask>
bool CForceMaxPointSelector<Tn,Image,Mask>::TestLastHighScalar()
{
	if ( m_LastScalar > m_fThreshold )
	{
		Point plc(m_LastCoord.x(), m_LastCoord.y()); 
		Vh nvh = m_pTn->nearest_vertex(plc);
		double dist = ::sqrt(squared_distance(plc, nvh->point()));	
		if ( dist > m_GreaterDistance )
		{
			m_GreaterDistance = dist;
			m_GreaterCoord = m_LastCoord;
			m_GreaterValue = m_LastScalar;
			return true;
		}
	}
	return false;
}

template <class Tn, class Image, class Mask>
int CForceMaxPointSelector<Tn,Image,Mask>::WalkedArea()
{	return m_nWalkedArea;	}

template <class Tn, class Image, class Mask>
inline double CForceMaxPointSelector<Tn,Image,Mask>::CoordGradient(Coord c)
{
	double &g = (*m_pImage)(c).Gradient();
	if ( g != -1 )
		return g;
	g = m_Mask.Convolution(c);
	return g;
}

template <class Tn, class Image, class Mask>
inline void CForceMaxPointSelector<Tn,Image,Mask>::operator()(Coord c)
{
	m_nWalkedArea++;
	m_CurrScalar = CoordGradient(c);
	switch(m_nTime)
	{
	case 0:
		m_LastScalar = m_CurrScalar;
		m_nTime++;
		return;
	case 1:
		m_LastSing = m_CurrScalar - m_LastScalar;
		m_LastScalar = m_CurrScalar;
		m_LastCoord = c;
		m_nTime++;
		return;
	default:
		m_CurrSing = m_CurrScalar - m_LastScalar;
		if ( ( m_LastSing > 0 && m_CurrSing <= 0 ) ||		/* + /\ - */
			 ( m_LastSing = 0 && m_CurrSing < 0 )		)	/* 0 -\ - */
		{
			TestLastHighScalar();			
		}
		m_LastSing = m_CurrSing;
		m_LastScalar = m_CurrScalar;
		m_LastCoord = c;
	}
}

template <class Tn, class Image, class Mask>
inline CForceMaxPointSelector<Tn,Image,Mask>::Coord CForceMaxPointSelector<Tn,Image,Mask>::GreaterCoord()
{	return m_GreaterCoord;			}

template <class Tn, class Image, class Mask>
inline double CForceMaxPointSelector<Tn,Image,Mask>::GreaterValue()
{	return m_GreaterValue;			}

template <class Tn, class Image, class Mask>
bool CForceMaxPointSelector<Tn,Image,Mask>::NoAction()
{	return !m_GreaterValue;			}

////////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_ForceMaxPointSelector_H__4A0E373E_C891_46F1_A069_8684ED235D92__INCLUDED_)

