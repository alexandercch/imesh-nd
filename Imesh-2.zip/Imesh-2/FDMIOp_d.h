// FDMIOp_d.h: interface for the CFDMIOp_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FDMIOp_d_H__7D68DA52_C6A9_4190_BADC_78E0A75F618B__INCLUDED_)
#define AFX_FDMIOp_d_H__7D68DA52_C6A9_4190_BADC_78E0A75F618B__INCLUDED_

//////////////////////////////////////////////////////////////////////////////////////////

/*----------------------------------------------------------------------------------------
Fast Detection of Meaningful Isosurfaces for Volume Data Visualization
Vladimir Pekar1;2 Rafael Wiemker1 Daniel Hempel1
1Philips Research Laboratories, Hamburg, Germany
2Institute for Signal Processing, Medical University of L�ubeck, Germany
fvladimir.pekar, rafael.wiemker, daniel.hempelg@philips.com
*///--------------------------------------------------------------------------------------

template<class Mask>
class CFDMIOp_d  
{
public:
typedef typename Mask::Img		Img;
typedef typename Img::Coord		Coord;
typedef typename list<float>	FList;
typedef typename vector<float>	FVector;

public:
	CFDMIOp_d();	
	virtual ~CFDMIOp_d();
	void Init(Img* pImg);
	inline void operator()(Coord c);
	void GetValues(FList* pIvl);
	void FPrint();
private:
	Img* m_pImg;
	FList m_IvList;
	FVector m_CHisto; //Cumulative Histogram
	Mask* m_pMask;
};

template<class Mask>
CFDMIOp_d<Mask>::CFDMIOp_d()	
{	m_pImg = NULL;	m_pMask = NULL; }

template<class Mask>
CFDMIOp_d<Mask>::~CFDMIOp_d()	
{	
	m_pImg = NULL;	
	if ( m_pMask ) delete m_pMask;
}

template<class Mask>
void CFDMIOp_d<Mask>::GetValues(FList* pIvl)	
{	
	pIvl->clear();
	for ( int T = 0; T <= 255; T++ )
		pIvl->push_back( -m_CHisto[T] );
}

template<class Mask>
void CFDMIOp_d<Mask>::Init(Img* pImg)			
{	
	m_pImg = pImg;	
	m_CHisto.clear();
	m_CHisto.resize(255);
	m_pMask = new Mask(m_pImg);
}

template<class Mask>
void CFDMIOp_d<Mask>::operator()(Coord c)
{
	float grad = m_pMask->Convolution(c);
	int T, gray = (*m_pImg)(c);

	for ( T = 0; T <= 255; T++ )
		if ( gray >= T )
			m_CHisto[T] += grad;
}

template<class Mask>
void CFDMIOp_d<Mask>::FPrint()
{
	ofstream os;
	os.open("histo.txt", ofstream::out );	
	for ( int T = 0; T <= 255; T++ )
		os << -m_CHisto[T] << endl;
	os.close();
}


#endif // !defined(AFX_FDMIOp_d_H__7D68DA52_C6A9_4190_BADC_78E0A75F618B__INCLUDED_)
