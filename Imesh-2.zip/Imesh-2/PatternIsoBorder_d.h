// PatternIsoBorder_d.h: interface for the CPatternIsoBorder_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PatternIsoBorder_d_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_)
#define AFX_PatternIsoBorder_d_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_

#include "IsoValueList_d.h"
#include "MeshBorderDetector_d.h"

template <class Tni>
class CPatternIsoBorder_d  : public CIsoValueList_d<Tni>, public CMeshBorderDetector_d<Tni> 
{
public:
typedef typename CIsoValueList_d<Tni>	IParent;
typedef typename Tni::Ch				Ch;
typedef typename Tni::Be				Be;

public:
	inline EMeshBorder operator()(Be be);
	inline operator string();
};

template <class Tni>
CPatternIsoBorder_d<Tni>::operator string()
{	
	string s = IParent::operator string();
	return s.empty() ?	string("Mbd: off") : 
						string("Mbd: PatternIsoBorder_d: ") + s;
}

template <class Tni>
inline CPatternIsoBorder_d<Tni>::EMeshBorder CPatternIsoBorder_d<Tni>::operator()(Be be)
{
	Ch ch1, ch2; 
	int i;
	bool b1, b2;
	float v1,v2;
	
	ch1	= be.first;
	i = be.second;
	b1 = m_pTn->is_infinite(ch1);
	ch2 = ch1->neighbor(i);
	b2 = m_pTn->is_infinite(ch2);

	if ( (b1 && !b2) || (!b1 && b2) )	return be_extern_border;
	if ( b1 && b2 )						return be_no_border;

	v1 = ch1->Info().Pattern();
	v2 = ch2->Info().Pattern();
	return (*(IParent*)this)(v1,v2) ? be_border : be_no_border;
}

#endif // !defined(AFX_PatternIsoBorder_d_H__E62A65CD_F6EC_4EE3_882A_62A85897FB77__INCLUDED_)
