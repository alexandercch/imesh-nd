// CSmoothIsoSurfProj_d.h: interface for the CSmoothIsoSurfProj_d class.
///////////////////////////////////////////////////////////////////////

#if !defined(AFX_SmoothIsoSurfProj_d_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)
#define AFX_SmoothIsoSurfProj_d_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_

#include "IsoValue_d.h"

template <class Tni>
class CSmoothIsoSurfProj_d
{
public:
typedef typename Tni::Img					Img;
typedef typename Tni::Tn					Tn;
typedef typename Tni::FT					FT;
typedef typename Img::Coord					Coord;
typedef typename Tn::Point					Point;
typedef typename CIsoValueList_d<Tni>		Ivl;
typedef typename CIsoValuePrePoint_d<Tni>	PrePoint;
public:
	void Init(Img*, Ivl*){};
	virtual inline Point Project(PrePoint& p) = 0;
	inline FT ThreeTwoInterpolation_1(FT a, FT x, FT b);
	inline FT ThreeTwoInterpolation_2(FT c, FT d, FT percent);
	inline FT ThreeTwoInterpolation(FT a, FT x, FT b, FT c, FT d);
};

template <class Tni>
inline CSmoothIsoSurfProj_d<Tni>::FT 
CSmoothIsoSurfProj_d<Tni>::ThreeTwoInterpolation_1(FT a, FT x, FT b)
{
	FT  abmin = a < b ? a : b,
		ababs = fabs(a-b),
		xabminabs = fabs(x-abmin),
		percent = xabminabs/ababs;
	return percent;
}

template <class Tni>
inline CSmoothIsoSurfProj_d<Tni>::FT 
CSmoothIsoSurfProj_d<Tni>::ThreeTwoInterpolation_2(FT c, FT d, FT percent)
{
	FT  cdmin = c < d ? c : d,
		cdabs = fabs(c-d),
		r = cdmin + cdabs*percent;
	return r;
}

#endif // !defined(AFX_SmoothIsoSurfProj_d_H__E01E4EFE_9E49_4C9C_9359_536D70E48CDA__INCLUDED_)

/*
	FT percent	= ThreeTwoInterpolation_1(9, 15, 16);
	FT ret		= ThreeTwoInterpolation_2(210, 100, percent);
*/