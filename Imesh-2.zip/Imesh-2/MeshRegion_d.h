// MeshRegion_d.h: interface for the CMeshRegion_d class.
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MeshRegion_d_H__94A0255D_C28F_4C5E_90DB_E806C029617B__INCLUDED_)
#define AFX_MeshRegion_d_H__94A0255D_C28F_4C5E_90DB_E806C029617B__INCLUDED_

#include "MeshRgnVector_d.h"

template <class Tni>
class CMeshRegion_d
{
public:
typedef typename CMeshRegion_d<Tni>				Self;
typedef typename CMeshRgnVector_d<Tni,Self*> 	MeshRegionVector;
typedef typename Tni							Tni;
typedef typename Tni::Tnd						Tnd;
typedef typename Tnd::Tn						Tn;			
typedef typename Tnd::Ch						Ch;
typedef typename Tnd::Be						Be;
typedef typename pair<double,unsigned long>		PattScanArea;
typedef typename list<Ch>						CellList;
typedef typename list<Be>						BeList;
typedef typename list<int>						IdList;
typedef typename set<int>						NeighborsSet; 

	CMeshRegion_d(){};
	void Init(Tn* pTn, MeshRegionVector* pMeshRegionVector, CGAL::Color c);
	virtual ~CMeshRegion_d(){};
//	inline bool MeshBorder(Ch a, Ch b);	
	void Incorporate(Ch x);
	void Incorporate(Self* mr);
	void Store(Ch x);
	void Update(double pattern_b, double s_area_b, double area_b);
	void IncorporateCells();

	CellList&		CList();
	IdList&			IList();
	BeList&			BList();
	NeighborsSet&	NSet();
	long			NElements();
	double Pattern();
	double ScanArea();
	double RealArea();
	CGAL::Color& Color();
	void MakeIdxDist(double major_area, double major_nelmts);
	int& Id() ;
	double IdxDist();

	double operator-(const Self& mr) const;	//distance based on m_Pattern 
	bool operator< (const Self& mr) const;	//distance based on m_IdxDist 
	typedef /*const*/ Self*						SCPtr;
	struct PLessCPtr 
	{		bool operator() (const SCPtr& c1, const SCPtr& c2) const {	return (*c1 < *c2);	}	};

private:	
	MeshRegionVector* m_pMeshRegionVector;
	int m_nRegion, m_nElements;	
	IdList m_IdRegionList;
	double m_Pattern, m_ScanArea, m_RealArea;
	CGAL::Color m_Color;
	CellList m_CellList;
	BeList m_BeList;
	NeighborsSet m_NeighborsSet;
	Tn* m_pTn;
	Tnd m_Tnd;	
	bool m_bNeighbors;
	double m_IdxDist;
};

template <class Tni>
void CMeshRegion_d<Tni>::Init(Tn* pTn, MeshRegionVector* pMeshRegionVector, CGAL::Color c)
{
	m_pTn = pTn;
	m_Tnd.Init(pTn);
	m_pMeshRegionVector = pMeshRegionVector;
	m_nRegion = m_pMeshRegionVector->NewId();
	(*m_pMeshRegionVector)[m_nRegion] = this;

	m_Color = c;
	m_Pattern =  m_ScanArea = m_RealArea = 0;
	m_IdRegionList.push_back(m_nRegion);
	m_bNeighbors = true;
	m_nElements = 0;
}

template <class Tni> //distance based on m_Pattern 
double CMeshRegion_d<Tni>::operator-(const Self& mr) const
{	return fabs(m_Pattern - mr.m_Pattern);	}

template <class Tni> //distance based on m_IdxDist
bool CMeshRegion_d<Tni>::operator< (const Self& mr) const
{
	if ( m_IdxDist == mr.m_IdxDist )
		return m_nRegion < mr.m_nRegion;
	return m_IdxDist < mr.m_IdxDist;
}

template <class Tni>
inline CMeshRegion_d<Tni>::CellList& CMeshRegion_d<Tni>::CList()		{	return m_CellList;	}
template <class Tni>
inline CMeshRegion_d<Tni>::IdList& CMeshRegion_d<Tni>::IList()			{	return m_IdRegionList;	}
template <class Tni>
inline CMeshRegion_d<Tni>::BeList& CMeshRegion_d<Tni>::BList()			{	return m_BeList;	}
template <class Tni>
inline CMeshRegion_d<Tni>::NeighborsSet& CMeshRegion_d<Tni>::NSet()		{	return m_NeighborsSet;	}
template <class Tni>
inline double CMeshRegion_d<Tni>::Pattern()		{	return m_Pattern;	}
template <class Tni>
inline long CMeshRegion_d<Tni>::NElements()		{	return m_nElements;	}
template <class Tni>
inline double CMeshRegion_d<Tni>::ScanArea()	{	return m_ScanArea;		}
template <class Tni>
inline double CMeshRegion_d<Tni>::RealArea()	{	return m_RealArea;		}
template <class Tni>
CGAL::Color& CMeshRegion_d<Tni>::Color()		{	return m_Color;		}
template <class Tni>
int& CMeshRegion_d<Tni>::Id()					{	return m_nRegion;	}
template <class Tni>
inline 	double	CMeshRegion_d<Tni>::IdxDist()	{	return m_IdxDist;	}

template <class Tni>
inline void CMeshRegion_d<Tni>::MakeIdxDist(double major_area, double major_nelmts) 	
{
	double x,y;
	x = major_area / m_RealArea;		//0..1
	y = major_nelmts / m_nElements;		//0..1
	m_IdxDist = ::sqrt(x*x + y*y); 
}

/*template <class Tni>
inline bool CMeshRegion_d<Tni>::MeshBorder(Ch a, Ch b)
{
	if ( !m_pMbd ) return true;
	return (*m_pMbd)(a->info().Pattern(), b->info().Pattern());
}*/

template <class Tni>
void CMeshRegion_d<Tni>::Incorporate(Ch ch)
{
	double real_area = m_Tnd.Aread(ch);
	m_nElements++;
	ch->info().Region() = m_nRegion;	
	Update(ch->info().Pattern(), ch->info().ScanArea(), real_area);
	
	if ( m_bNeighbors )
	{
		int i, nRgn;
		Ch ni;
		for ( i = 0; i <= Tni::Dim; i++ )
		{
			ni = ch->neighbor(i);
			if ( !m_pTn->is_infinite(ni) )
			{
				nRgn = ni->info().Region();
				if ( nRgn >= 0 && nRgn != m_nRegion /*&& !MeshBorder(ch, ni)*/ )
				{
					m_NeighborsSet.insert(nRgn);
					(*m_pMeshRegionVector)[nRgn]->NSet().insert(m_nRegion);
				}
			}
		}
	}
}

template <class Tni>
void CMeshRegion_d<Tni>::Incorporate(Self* ar)
{
	m_nElements	+= ar->NElements();
	int &ar_id = ar->Id(); 
	Update(ar->Pattern(), ar->ScanArea(), ar->RealArea() );
	list<int>::iterator ii;
	list<int>& ar_idlist = ar->IList();
	int size = ar_idlist.size();
	for ( ii = ar_idlist.begin(); ii != ar_idlist.end(); ++ii )
		m_IdRegionList.push_back(*ii);

	if ( m_bNeighbors )
	{
		NeighborsSet *arNSet, *nnNSet;
		NeighborsSet::iterator ni;
		
		//1
		m_NeighborsSet.erase(ar_id);

		arNSet = &((*m_pMeshRegionVector)[ar_id]->NSet());
		for ( ni = arNSet->begin(); ni != arNSet->end(); ++ni )
		{
			if ( *ni == m_nRegion )	
				continue;
			//2
			m_NeighborsSet.insert(*ni);
			//3
			nnNSet = &((*m_pMeshRegionVector)[*ni]->NSet());
			nnNSet->erase(ar_id);
			nnNSet->insert(m_nRegion);
		}
	}
	
	ar_id = -1; //Incorporateed Mesh region 
}

template <class Tni>
void CMeshRegion_d<Tni>::Store(Ch ch)
{
	m_CellList.push_back(ch);
}

template <class Tni>
void CMeshRegion_d<Tni>::Update(double pattern_b, double s_area_b, double r_area_b)
{
	double	TotalScanArea = m_ScanArea + s_area_b,
			percentage_a = m_ScanArea/TotalScanArea, percentage_b = s_area_b/TotalScanArea;
	m_Pattern	= m_Pattern*percentage_a + pattern_b*percentage_b;
	m_ScanArea	= TotalScanArea;
	m_RealArea += r_area_b;
}

template <class Tni>
void CMeshRegion_d<Tni>::IncorporateCells()
{
	CellList::iterator si;
	for ( si = m_CellList.begin(); si != m_CellList.end(); ++si )
		(*si)->info().Region() = m_nRegion;
	m_IdRegionList.clear();
	m_IdRegionList.push_back(m_nRegion);
}

#endif // !defined(AFX_MeshRegion_d_H__94A0255D_C28F_4C5E_90DB_E806C029617B__INCLUDED_)
