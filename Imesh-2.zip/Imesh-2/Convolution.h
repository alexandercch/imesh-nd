// SpatialGradientMeasurementXY.h: interface for the CConvolution class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SpatialGradientMeasurementXY_H__6E1EB856_7D6B_49BA_925A_4705BD5D91C9__INCLUDED_)
#define AFX_CONVOLUTION_H__6E1EB856_7D6B_49BA_925A_4705BD5D91C9__INCLUDED_

class SpatialGradientMeasurementXY{};


#endif // !defined(AFX_SpatialGradientMeasurementXY_H__6E1EB856_7D6B_49BA_925A_4705BD5D91C9__INCLUDED_)
