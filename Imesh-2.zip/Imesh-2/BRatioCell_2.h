// BRatioCell_2.h: interface for the CCellBRatioCmp_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CELLBRATIOCMP_2_H__9A043256_3BB6_477A_B755_4B6514EF85CC__INCLUDED_)
#define AFX_CELLBRATIOCMP_2_H__9A043256_3BB6_477A_B755_4B6514EF85CC__INCLUDED_

template<class Tn>
class CBRatioCell_2
{
typedef CBRatioCell_2<Tn>		Self;
typedef Tn::Face_handle			Cell_handle;
public:	
	CBRatioCell_2(Cell_handle _ch)	{ m_ch = _ch; }

	bool operator< (Self& c)
	{	return m_ch->info().B() < (*c)->info().B();		}
	typedef /*const*/ Self*		SCPtr;
	struct LessPtrCmp
	{		bool operator() (const SCPtr& c1, const SCPtr& c2) const {	return (*c1 < *c2);	}	};
	Cell_handle operator*() { return m_ch; }
private:
	Cell_handle m_ch;
};


#endif // !defined(AFX_CELLBRATIOCMP_2_H__9A043256_3BB6_477A_B755_4B6514EF85CC__INCLUDED_)
