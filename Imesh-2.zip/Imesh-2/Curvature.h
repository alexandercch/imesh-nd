// Curvature.h: interface for the CCurvature class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CURVATURE_H__750B2D56_6E13_4A03_9CA3_46CDE3EF4904__INCLUDED_)
#define AFX_CURVATURE_H__750B2D56_6E13_4A03_9CA3_46CDE3EF4904__INCLUDED_

template<class _Matrix, class _NearestVertexQuery>
class CCurvature  
{
public:
typedef typename _Matrix::IndexType					MatrixIndexType;
	CCurvature(_Matrix* _m, _NearestVertexQuery* _nvq);
	virtual ~CCurvature();
	double Convolution(MatrixIndexType _x, MatrixIndexType _y);
private:
	void CalcFs();
	void CalcLams();

	MatrixIndexType i, j;
	double m_fxx, m_fyy, m_fxy, m_l1, m_l2; 
	double m_const, m_max_curvature_value, m_max_edge;
	_Matrix* m;
	_NearestVertexQuery* nvq;
};

template<class _Matrix, class _NearestVertexQuery>
CCurvature<_Matrix, _NearestVertexQuery>::CCurvature(_Matrix* _m, _NearestVertexQuery* _nvq)
{
	m = _m;
	nvq = _nvq;
	m_const = 1;
	m_max_curvature_value = 636;//315.605;//463.218;
	m_max_edge = 622.615;//810.151;//390.323;
}

template<class _Matrix, class _NearestVertexQuery>
CCurvature<_Matrix, _NearestVertexQuery>::~CCurvature()
{}

template<class _Matrix, class _NearestVertexQuery>
double CCurvature<_Matrix, _NearestVertexQuery>::Convolution(MatrixIndexType _x, MatrixIndexType _y)
{
	i = _x; j = _y;
	CalcFs();
	CalcLams();
	//..
	double	max, min, edge_size;
	if ( m_l1 < m_l2 )	{	min = m_l1; max = m_l2; }
	else				{	min = m_l2; max = m_l1; }

	max /= m_max_curvature_value;
	min /= m_max_curvature_value;

	_NearestVertexQuery::Vertex_handle vh = nvq->nearest_vertex(_NearestVertexQuery::Point(_x, _y));
	if ( vh != NULL)
		edge_size = ::sqrt( ::pow(vh->point().x()-_x, 2) + ::pow(vh->point().y()-_y, 2) );
	else
		edge_size = 1;

	edge_size /= m_max_edge;

	return m_const*(max-min)*edge_size + max;
}

template<class _Matrix, class _NearestVertexQuery>
inline void CCurvature<_Matrix, _NearestVertexQuery>::CalcFs()
{
	m_fxx = (*m)(i+1,j) - 2*(*m)(i,j) + (*m)(i-1,j);
	m_fyy = (*m)(i,j+1) -2*(*m)(i,j) + (*m)(i,j-1);
	m_fxy = ( (*m)(i+1,j+1) - (*m)(i-1,j+1) - (*m)(i+1,j-1) + (*m)(i-1,j-1) ) / 2;
}

template<class _Matrix, class _NearestVertexQuery>
inline void CCurvature<_Matrix, _NearestVertexQuery>::CalcLams()
{
	double	//a = 1,
			b = -(m_fxx+m_fyy),
			c = -m_fxy*m_fxy + m_fxx*m_fyy,
			delta = b*b -4*c;
	assert(delta >= 0);
	double sdelta = ::sqrt(delta);

	m_l1 = ( -b + sdelta ) / 2.0;
	m_l2 = ( -b - sdelta ) / 2.0; 
}

#endif // !defined(AFX_CURVATURE_H__750B2D56_6E13_4A03_9CA3_46CDE3EF4904__INCLUDED_)
