// TnCellMultimap_2.h: interface for the CTnCellMultimap_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TnCellMultimap_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)
#define AFX_TnCellMultimap_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_

#include "TnCellMultimap_d.h"

template <class Tnx, class Ord>
class CTnCellMultimap_2 : public CTnCellMultimap_d<Tnx,Ord>
{
public:
	inline void UpdateStar(Vh& vh, long last_cell_id);
};

template <class Tnx, class Ord>
void CTnCellMultimap_2<Tnx,Ord>::UpdateStar(Vh& vh, long last_cell_id)
{
	Tn::Face_circulator cc, done;
	done = cc = vh->incident_faces();
	do
	{	UpdateStarOp(cc, last_cell_id);
	} while(--cc != done);
}

#endif // !defined(AFX_TnCellMultimap_2_H__7981757C_EB26_4176_B03D_37D4623DB6C7__INCLUDED_)

