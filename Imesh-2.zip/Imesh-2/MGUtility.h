// mgUtility.h: interface for the mgUtility class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MGUTILITY_H__40572867_D02F_4ADE_983F_F28929BB9A77__INCLUDED_)
#define AFX_MGUTILITY_H__40572867_D02F_4ADE_983F_F28929BB9A77__INCLUDED_

#include "UMacros_d.h"

#include<assert.h>
using namespace std;

class CMGUtility
{
public:
	static void	SplitFileExt(string file, string* sfile, string* sext);
	static string MakeFileName(string dir, string file, string ext, int i, int number_size);
	static void GetImageSliceNames(list<string>* files, string strDir, string strImageName);
	static string GetDirName(string path);
	static void CreateDirectory(string s);
	static void WriteUpdateFile(string s);
	static string GetFileName(string s);
	static string ReplaceExt(string s, string ext);
	static string GetFunctionCode(string file, string s, int nTime = 2);
	static string SelectFileFromIndex(string strIndex);
	static string TrimRight(string str);
	static string GetFirstWord(string str);
};

string CMGUtility::GetDirName(string path)
{
	char str[1024];
	int pos;
	strcpy(str, path.c_str());
	for ( pos = strlen(str); pos >= 0; pos-- )
		if ( str[pos] == '\\' )
			break;
	str[pos+1] = 0;
	return str;
}

/*string CMGUtility::GetDirName(string path)
{
	char str[1024], dir[1024];
	int pos;
	strcpy(str, path.c_str());
	for ( pos = strlen(str); pos >= 0; pos-- )
		if ( str[pos] == '\\' )
			break;
	strcpy(dir, &(str[pos]));
	return dir;
}*/

void CMGUtility::SplitFileExt(string file, string* sfile, string* sext)
{
	char ext[10], t[1024];
	int pos = -1, i, size = file.size();
	for ( i = size - 1; i >= 0; i-- )
		if ( file[i] == '.')
		{	pos = i;	break;		}
	assert(pos != -1);
	strcpy(t, file.c_str());

	::strcpy(ext, &(t[pos]) );
	*sext = ext;
	t[pos] = 0;
	*sfile = t;
}

string CMGUtility::MakeFileName(string dir, string file, string ext, int i, int number_size)
{
	char file_name[1024], number[10], t[10];
	::sprintf(number, "%d", i);
	while(strlen(number) < number_size)
	{
		::strcpy(t, "0");
		::strcat(t, number);
		::strcpy(number, t);
	}
	::sprintf(file_name, "%s\\%s%s%s", dir.c_str(), file.c_str(), number, ext.c_str());
	return file_name;
}

void CMGUtility::GetImageSliceNames(list<string>* files, string strDir, string strImageName)
{
	string file, ext, str_j;
	SplitFileExt(strImageName, &file, &ext);

	int j, i, n_size = 3, sizes[] = {2, 0,3}, size,
		n_errors, c_errors;
	bool bSomeLoad = false;

	FILE* pf;
	for ( i = 0; i < n_size && !bSomeLoad; i++ )
	{
		files->clear();
		n_errors = 2; c_errors = 0;		
		size = sizes[i];
		j = 0;
		while ( c_errors < n_errors )
		{
			str_j = MakeFileName(strDir, file, ext, j++, size);
			pf = ::fopen(str_j.c_str(), "r");
			if ( pf == NULL )
				c_errors++;
			else
			{	
				::fclose(pf);
				files->push_back(str_j);
				bSomeLoad = true;
			}
		}
	}
}	

void CMGUtility::WriteUpdateFile(string s)
{
	char strUpdt[512];
	int pos;
	pos = s.find_last_of(".");
	::strcpy(strUpdt, s.c_str());
	strUpdt[pos] = 0;
	::strcat(strUpdt, ".updt");
	FILE* pf = ::fopen(strUpdt,"w");
	::fclose(pf);
}

string CMGUtility::GetFileName(string s)
{
	char str[255];
	int i, ppos = s.find_last_of(".");
	for ( i = ppos-1; i>=0; i-- )
	{
		char c = s[i];
		if ( c == '/' || c == '\\' || c == '.')
			break;
	}
	strcpy(str, s.c_str());
	str[ppos] = 0;
	strcpy(str, &str[i+1]);
	return string(str);
}

string CMGUtility::ReplaceExt(string s, string ext)
{
	char str[255];
	strcpy(str, s.c_str());
	int pos = s.find_last_of(".");
	str[pos] = 0;
	strcat(str, ext.c_str());
	return string(str);
}

void CMGUtility::CreateDirectory(string s)
{
	string create, remove, cd;
	remove	= string("rd /S /Q ") + s;
	create	= string("mkdir ") + s;
	cd		= string("cd ") + s;
	
	::system(remove.c_str());
	::system(create.c_str());
	::system(cd.c_str());
}

string CMGUtility::GetFunctionCode(string file, string s, int nMatch)
{
	FILE* pf = fopen(file.c_str(), "r");
		char line[1024];
		char ch;
		bool bFound = 0;
		string code;
		int count = 0, time = 0, nMatchCount = 0;
		while(!feof(pf))
		{
			fgets(line, 1024, pf);
			nMatchCount += strstr( line, s.c_str() ) != NULL;
			if ( nMatchCount == nMatch )
			{
				code += line;
				while ( !( count == 0 && time != 0 ) )
				{
					ch = fgetc(pf);
					time = count += ch == '{';
					count -= ch == '}';
					code += ch;
				}
				break;
			}
		}
	fclose(pf);
	return code;
}

string CMGUtility::SelectFileFromIndex(string strIndex)
{
	char line[1024];
	string dir;
	vector<string> files;
	
	dir = GetDirName(strIndex);

	FILE* pIndex = ::fopen(strIndex.c_str(), "r");
	assert(pIndex != NULL);
	int kk= 0, i = 0;
	::printf("Image list\n");
	while( !feof(pIndex) )
	{
		::fgets(line, 1024, pIndex);	
		if ( !strcmp(line, "_") )
			break;
		::printf("%d-%s\t", i++, GetFirstWord(line).c_str() );
		if ( ++kk%2 == 0 )
			::printf("\n");
		files.push_back(line);
	}
	::fclose(pIndex);

	int idx;
	cout<<"\nIdx: ";cin>>idx;
	string ss = dir + files[idx].c_str();
	return 	TrimRight(ss);
}

string CMGUtility::GetFirstWord(string str)
{
	char strt[512];
	int i, sz;

	strcpy(strt, str.c_str());
	sz = strlen(strt);

	for ( i = 0; i < sz; i++ )
		if ( strt[i] == '.' || strt[i] == ' ' )
			break;
	assert(i != sz);
	strt[i] = 0;
	return 	strt;
}

string CMGUtility::TrimRight(string str)
{
	char strt[512];
	strcpy(strt, str.c_str());
	strt[strlen(strt)-1] = 0;
	return strt; 
}


#endif // !defined(AFX_MGUTILITY_H__40572867_D02F_4ADE_983F_F28929BB9A77__INCLUDED_)
