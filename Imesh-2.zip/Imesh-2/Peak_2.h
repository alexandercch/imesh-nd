// Peak_2.h: interface for the CPeak_2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PEAK_2_H__5EF8C225_DA71_4C09_BF28_5602AA68C132__INCLUDED_)
#define AFX_PEAK_2_H__5EF8C225_DA71_4C09_BF28_5602AA68C132__INCLUDED_

#include "Writer_2.h"
#include "VBe_2.h"

template<class Tni>
class CPeak_2  
{
public:
typedef Tni::Tn						Tn;
typedef CWriter_2<Tni>	Writer;
typedef CPeak_2<Tni>				Self;
typedef Tn::Geom_traits				Gt;
typedef Gt::FT						FT;
typedef Tn::Vertex_handle			Vh;
typedef CBVBe_2<Tni>				BVBe;
typedef CBVBeGroup_2<Tni>			BVBeGroup;
typedef CVertexEdgeNode_2<Tn>		VENode;
typedef Tn::Edge_circulator			Edge_circulator;
typedef Tn::Face_handle				Cell_handle;

	CPeak_2();
	bool Create_step_one(Vh _vh, Vh _vh1, Vh _vh2, FT _radius, BVBeGroup* pBEdgeGroup);
	bool Create_step_two(Tn* pTn, Writer* w = NULL);
	operator Cell_handle() { return m_cell; }

private:
	Vh m_vhcenter, m_vh1, m_vh2;
	BVBe	*m_e1, *m_e2;
	FT m_radius;
	Cell_handle m_cell;
public:
	static int m_nPeakIdentifierCount;
};

template<class Tni>
int CPeak_2<Tni>::m_nPeakIdentifierCount = 0;

template<class Tni>
CPeak_2<Tni>::CPeak_2()
{
	m_vhcenter = m_vh1 = m_vh2 = NULL;
	m_e1 = m_e2 =NULL;
}

template<class Tni>
bool CPeak_2<Tni>::Create_step_one(Vh _vh, Vh _vh1, Vh _vh2, FT _radius, BVBeGroup* pBEdgeGroup)
{
	m_vhcenter = _vh;
	m_vh1 = _vh1; m_vh2= _vh2;
	m_e1 = pBEdgeGroup->GetAllocBEdge(m_vhcenter, m_vh1);
	m_e2 = pBEdgeGroup->GetAllocBEdge(m_vhcenter, m_vh2);
	m_e1->Insert_radius_point(m_vhcenter, _radius);
	m_e2->Insert_radius_point(m_vhcenter, _radius);
	return true;
}

template<class Tni>
bool CPeak_2<Tni>::Create_step_two(Tn* pTn, Writer* w)
{
	m_vh1 = m_e1->GetFirstMiddleVertexFrom(m_vhcenter);
	m_vh2 = m_e2->GetFirstMiddleVertexFrom(m_vhcenter);

	if ( !pTn->is_face(m_vhcenter, m_vh1, m_vh2, m_cell) )
	{
		printf("!p");
		return false;
	}

	int &id0 = VENode::GetVENode(m_vhcenter)->PeakIdentifier(),
		&id1 = VENode::GetVENode(m_vh1)->PeakIdentifier(),
		&id2 = VENode::GetVENode(m_vh2)->PeakIdentifier(),
		id;

	if		( id0 != -1 )	id = id0;
	else if ( id1 != -1 )	id = id1;
	else if ( id2 != -1 )	id = id2;
	else					id = m_nPeakIdentifierCount++;

	id0 = id1 = id2 = id;

	return true;	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template<class Tni>
class CPeakGroup_2 : public list<CPeak_2<Tni>* >
{
public:
typedef Tni::Tn						Tn;
typedef CWriter_2<Tni>	Writer;
typedef CPeakGroup_2<Tni>			Self;
typedef Tn::Geom_traits				Gt;
typedef Gt::FT						FT;
typedef Tn::Point					Point;
typedef Tn::Vertex_handle			Vh;
typedef Tn::Face_handle				Cell_handle;
typedef Tn::Edge_circulator			Edge_circulator;
typedef CPeak_2<Tni>				Peak;
typedef CBVBeGroup_2<Tni>		BVBeGroup;

	CPeakGroup_2();
	~CPeakGroup_2();
	void Create(Tn* pTn, FT fMinPeakAngle, Writer* _w = NULL);
	void Destroy();
	bool ComputePeaks();
	bool IsolatePeaks();
	void SelectAllPeaks();

private:
	bool VerifyPeaks(Vh vh);
	bool VariationInStartEdge(Vh vh, Edge_circulator* _ec);
	bool CreatePeaks(Vh vh, Edge_circulator* _ec);

	BVBeGroup m_BVBeGroup;
	Tn* m_pTn;
	FT m_fMinPeakAngle;
	Writer* m_w;
};

template<class Tni>
CPeakGroup_2<Tni>::CPeakGroup_2()
{
	m_pTn = NULL;	m_fMinPeakAngle = 0;
}

template<class Tni>
CPeakGroup_2<Tni>::~CPeakGroup_2()
{
	Destroy();
}

template<class Tni>
void CPeakGroup_2<Tni>::Create(Tn* pTn, FT fMinPeakAngle, Writer* _w)
{
	m_w = _w;
	m_pTn = pTn;
	m_fMinPeakAngle = fMinPeakAngle;
	m_BVBeGroup.Create(m_pTn, m_w);
}

template<class Tni>
void CPeakGroup_2<Tni>::Destroy()
{
	for ( iterator i = begin(); i != end(); ++i )
		delete *i;
}

template<class Tni>
bool CPeakGroup_2<Tni>::ComputePeaks()
{
	Tn::Finite_vertices_iterator fvi;
	for ( fvi = m_pTn->finite_vertices_begin(); fvi != m_pTn->finite_vertices_end(); ++fvi )
		VerifyPeaks(fvi);
	return 	!!m_BVBeGroup.size();
}

template<class Tni>
bool CPeakGroup_2<Tni>::VerifyPeaks(Vh vh)
{
	Edge_circulator ec;	
	if ( !VariationInStartEdge(vh, &ec) )
		return false;
	return CreatePeaks(vh, &ec);
}

template<class Tni>
bool CPeakGroup_2<Tni>::VariationInStartEdge(Vh vh, Edge_circulator* _ec)
{//this method detect/set the beginning of some region's variation in the vertex star

	Edge_circulator ec, last_ec, ecdone, int_ec, rect_border_ec;	
	Cell_handle sfh, fh1, fh2;
	Vh last_svh, start_svh;
	int iv, r1, r2, bif1, bif2, bRect_border_edge, bInfiniteEdge = true;
	rect_border_ec = int_ec = Tn::Edge_circulator(NULL);
	ecdone = ec = m_pTn->incident_edges(vh);
	do
	{
		if ( m_pTn->is_infinite(ec) )
		{	bInfiniteEdge = true; continue; }

		iv = ec->second;
		fh1 = ec->first;
		fh2 = fh1->neighbor(iv);

		//Division edge
		r1 = fh1->info().Region(); r2 = fh2->info().Region();
		if ( ( !bif1 && !bif2 ) &&	( r1 != r2 ) )
			int_ec = ec;

		//Rect border edge 
		bif1 = m_pTn->is_infinite(fh1); bif2 = m_pTn->is_infinite(fh2);
		bRect_border_edge =  (bif1 && !bif2) || (!bif1 && bif2);
		if ( bRect_border_edge && bInfiniteEdge )
		{
			bInfiniteEdge = false;
			rect_border_ec = ec;
		}

	} while(--ec != ecdone);
	
	if ( int_ec == NULL  )			{ return false; }
	if ( rect_border_ec != NULL )	{ *_ec = rect_border_ec; return true; }

	*_ec = int_ec; 
	return true;
}

template<class Tni>
bool CPeakGroup_2<Tni>::CreatePeaks(Vh vh, Edge_circulator* _ec)
{//This method try to create peaks around a vertex handle

	//Creating pre-peaks
	Vh svh, last_svh, start_svh;	
	Edge_circulator ec = *_ec, last_ec, ecdone;
	Cell_handle sfh;
	Gt::Triangle_2 tri;
	FT angle, sum_angle = 0;
	int nRegion = -2, nLastRegion = -1;
	bool bFirstTime = true;
	last_ec = ec; ecdone = --ec;
	start_svh = last_svh = TniU::StarVertexFromStarEdge<Tn>(last_ec, vh);
	
	list<pair<Vh,Vh> > pre_peaks;
	for (int k = 2; k && nRegion != -1; k -= last_ec == ecdone)
	{
		svh = TniU::StarVertexFromStarEdge<Tn>(ec, vh);
		sfh = TniU::StarFaceFromStarEdge<Tn>(ec, last_svh);
		if ( !m_pTn->is_infinite(sfh) )
		{
			nRegion = sfh->info().Region();
			tri = m_pTn->triangle(sfh);
			angle = TniU::GetAngle<Gt>(tri, vh->point());
		}
		else	nRegion = -1;
		
		if ( !bFirstTime && nRegion != nLastRegion )
		{
			if ( sum_angle < m_fMinPeakAngle )
				pre_peaks.push_back( pair<Vh,Vh>(start_svh, last_svh) );
			sum_angle = 0;
			start_svh = last_svh;
		}
		sum_angle += angle;

		last_svh = svh;
		nLastRegion = nRegion;
		last_ec = ec;
		--ec;
		bFirstTime = false;
	}
	
	if ( ! pre_peaks.size() )	return false;
	
	//min edge calc -- in the vertex start
	
	FT dist, min_dist;
	Tn::Vertex_circulator vc, vcdone;
	vcdone = vc = m_pTn->incident_vertices(vh);
	min_dist = ::sqrt(squared_distance(vh->point(), vc->point()));
	--vc;
	do
	{	dist = ::sqrt(squared_distance(vh->point(), vc->point()));
		if ( dist < min_dist )
			min_dist = dist;
	}while(--vc != vcdone);
	
	//creating peaks...
	list<pair<Vh,Vh> >::iterator pi;
	FT peak_radius = min_dist/4.0; //log(min_dist)/log(2.0);
	for( pi = pre_peaks.begin(); pi != pre_peaks.end(); ++pi )
	{
		Peak* pNewPeak = new Peak;
		pNewPeak->Create_step_one(vh, pi->first, pi->second, peak_radius, &m_BVBeGroup);
		push_back(pNewPeak);
	}

	return true;
}

template<class Tni>
bool CPeakGroup_2<Tni>::IsolatePeaks()
{
//	m_BVBeGroup.ComputeAllMiddlePointsViolations();
	m_BVBeGroup.SelectAllBreakPoints();
//	m_w->Refresh();
	
	m_BVBeGroup.CommitBreaks();

	bool b = 1;
	iterator i;
	for ( i = begin(); i != end(); i++ )
		b |= (*i)->Create_step_two(m_pTn, m_w);
	return b;
}

template<class Tni>
void CPeakGroup_2<Tni>::SelectAllPeaks()
{
	m_w->UnselectAll();
	for ( iterator i = begin(); i != end(); ++i )
		m_w->SelectCell(**i);
}

#endif // !defined(AFX_PEAK_2_H__5EF8C225_DA71_4C09_BF28_5602AA68C132__INCLUDED_)
