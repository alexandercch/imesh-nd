// LineScan.h: interface for the CLineScan class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINESCAN_H__E403C8BC_E225_412C_838E_06C0119E93CB__INCLUDED_)
#define AFX_LINESCAN_H__E403C8BC_E225_412C_838E_06C0119E93CB__INCLUDED_

/*
COMMENT :
Extremely Fast Line Algorithm Var E (Addition Fixed Point PreCalc)
Copyright 2001-2, By Po-Han Lin
Freely useable in non-commercial applications as long as credits 
to Po-Han Lin and link to http://www.edepot.com is provided in 
source code and can been seen in compiled executable.  
Commercial applications please inquire about licensing the algorithms.
Lastest version at http://www.edepot.com/phl.html
This version is for standard displays (up to 65536x65536)
For small display version (256x256) visit http://www.edepot.com/lineex.html

http://www.edepot.com/algorithm.html
Benchmark data: Pentium III 450Mhz, Visual C++ 6.0 Release Build, Default Maximum Speed Optimization...
--------------------------------------------------------------------
Algorithm			Lines Drawn (x1000) Seconds		Lines Per Second 
--------------------------------------------------------------------
DDA					1600				504.476		3171.608 
Bresenham			1600				80.446		19889.117 
Wu					1600				72.895		21949.378 
EFLA Variation E	1600				63.801		25077.976 

*/

template <class _FO, class IT>
class CLineScan  
{
public:
typedef typename IT::PointI_2	PointI_2;
typedef typename IT::SegmentI_2	SegmentI_2;
	void operator()(SegmentI_2* pLine, _FO* fo);
};

//Extremely Fast Line Algorithm Variation E (Addition Fixed Point With Precalculations)
template <class _FO, class IT>
inline void CLineScan<_FO, IT>::operator()(SegmentI_2* line, _FO* fo)
{
	int x = (*line)[0].x(), y = (*line)[0].y(),
		x2 = (*line)[1].x(), y2 = (*line)[1].y();

   	bool yLonger=false;
	int shortLen=y2-y;
	int longLen=x2-x;
	if (abs(shortLen)>abs(longLen)) 
	{
		int swap=shortLen;
		shortLen=longLen;
		longLen=swap;				
		yLonger=true;
	}
	int decInc;
	if (longLen==0) decInc=0;
	else decInc = (shortLen << 16) / longLen;

	if (yLonger) 
	{
		if (longLen>0) 
		{
			longLen+=y;
			for (int j=0x8000+(x<<16);y<=longLen;++y) 
			{
				(*fo)(PointI_2(j >> 16,y));	
				j+=decInc;
			}
			return;
		}
		longLen+=y;
		for (int j=0x8000+(x<<16);y>=longLen;--y) 
		{
			(*fo)(PointI_2(j >> 16,y));	
			j-=decInc;
		}
		return;	
	}

	if (longLen>0) 
	{
		longLen+=x;
		for (int j=0x8000+(y<<16);x<=longLen;++x) 
		{
			(*fo)(PointI_2(x,j >> 16));
			j+=decInc;
		}
		return;
	}
	longLen+=x;
	for (int j=0x8000+(y<<16);x>=longLen;--x) 
	{
		(*fo)(PointI_2(x,j >> 16));
		j-=decInc;
	}

}

#endif // !defined(AFX_LINESCAN_H__E403C8BC_E225_412C_838E_06C0119E93CB__INCLUDED_)